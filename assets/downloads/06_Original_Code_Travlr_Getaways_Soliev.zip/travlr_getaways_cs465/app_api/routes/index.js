const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens

// This is where we import the controllers we will route to
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Method to authenticate our JWT
function authenticateJWT(req, res, next) {
    const authHeader = req.headers['authorization'];
    if (authHeader == null) {
        console.log('Auth Header Required but NOT PRESENT!');
        return res.sendStatus(401);
    }
    let headers = authHeader.split(' ');
    if (headers.length < 1) {
        console.log('Not enough tokens in Auth Header: ' + headers.length);
        return res.sendStatus(501);
    }
    const token = authHeader.split(' ')[1];
    if (token == null) {
        console.log('Null Bearer Token');
        return res.sendStatus(401);
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            return res.status(401).json({ message: 'Token Validation Error!' });
        }
        req.auth = verified; // Set the auth param to the decoded object
        next(); // We need to continue or this will hang forever
    });
}

// Define route for registration endpoint
router.route('/register')
    .post(authController.register);

// Define route for login endpoint
router.route('/login')
    .post(authController.login);

// Define routes for our trips endpoints
// GET is public (used by both the customer site and the admin listing).
// POST/PUT/DELETE all change data, so they require a valid JWT.
router.route('/trips')
    .get(tripsController.tripsList)                          // GET method routes tripsList
    .post(authenticateJWT, tripsController.tripsAddTrip);     // POST method adds a new trip

router.route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)                       // GET method routes tripsFindByCode
    .put(authenticateJWT, tripsController.tripsUpdateTrip)      // PUT method updates a trip
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);  // DELETE method removes a trip

module.exports = router;
