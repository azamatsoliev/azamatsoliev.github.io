const mongoose = require('mongoose');
require('../models/travlr'); // Register the 'trips' schema with Mongoose
const Model = mongoose.model('trips');

// GET: /api/trips - lists all the trips
// Regardless of outcome, response must include an HTTP status code
// and a JSON message to the requesting client
const tripsList = async (req, res) => {
    try {
        const q = await Model
            .find({}) // No filter, return all records
            .exec();

        if (!q || q.length === 0) {
            // Database returned no data
            return res
                .status(404)
                .json({ message: 'No trips found' });
        }

        // Return the resulting trip list
        return res
            .status(200)
            .json(q);
    } catch (err) {
        // Database or server error
        return res
            .status(500)
            .json({ message: 'Error retrieving trips', error: err.message });
    }
};

// GET: /api/trips/:tripCode - lists a single trip matching the given code
const tripsFindByCode = async (req, res) => {
    try {
        const q = await Model
            .find({ code: req.params.tripCode }) // Return single matching record
            .exec();

        if (!q || q.length === 0) {
            // No trip matched the requested code
            return res
                .status(404)
                .json({ message: 'Trip not found' });
        }

        // Return the resulting trip
        return res
            .status(200)
            .json(q);
    } catch (err) {
        return res
            .status(500)
            .json({ message: 'Error retrieving trip', error: err.message });
    }
};

// POST: /api/trips - Adds a new trip
// Regardless of outcome, response must include an HTTP status code
// and a JSON message to the requesting client
const tripsAddTrip = async (req, res) => {
    try {
        const newTrip = new Model({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        const q = await newTrip.save();

        if (!q) {
            // Database did not save the record
            return res
                .status(400)
                .json({ message: 'Trip not saved' });
        }

        // Return the newly created trip
        return res
            .status(201)
            .json(q);
    } catch (err) {
        if (err.name === 'ValidationError') {
            // Client sent invalid/incomplete data - this is a bad request, not a server failure
            return res
                .status(400)
                .json({ message: 'Trip validation failed', error: err.message });
        }
        return res
            .status(500)
            .json({ message: 'Error adding trip', error: err.message });
    }
};

// PUT: /api/trips/:tripCode - Updates an existing trip
// Regardless of outcome, response must include an HTTP status code
// and a JSON message to the requesting client
const tripsUpdateTrip = async (req, res) => {
    try {
        const q = await Model
            .findOneAndUpdate(
                { code: req.params.tripCode },
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                {
                    new: true,          // return the updated document, not the original
                    runValidators: true, // enforce schema validation on updates too (off by default)
                    context: 'query'    // required for some validators to work correctly on updates
                }
            )
            .exec();

        if (!q) {
            // No trip matched the requested code
            return res
                .status(404)
                .json({ message: 'Trip not found' });
        }

        return res
            .status(200)
            .json(q);
    } catch (err) {
        if (err.name === 'ValidationError') {
            return res
                .status(400)
                .json({ message: 'Trip validation failed', error: err.message });
        }
        return res
            .status(500)
            .json({ message: 'Error updating trip', error: err.message });
    }
};

// DELETE: /api/trips/:tripCode - Deletes a trip
// Regardless of outcome, response must include an HTTP status code
// and a JSON message to the requesting client
const tripsDeleteTrip = async (req, res) => {
    try {
        const q = await Model
            .findOneAndDelete({ code: req.params.tripCode })
            .exec();

        if (!q) {
            // No trip matched the requested code
            return res
                .status(404)
                .json({ message: 'Trip not found' });
        }

        return res
            .status(200)
            .json({ message: 'Trip deleted', trip: q });
    } catch (err) {
        return res
            .status(500)
            .json({ message: 'Error deleting trip', error: err.message });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};
