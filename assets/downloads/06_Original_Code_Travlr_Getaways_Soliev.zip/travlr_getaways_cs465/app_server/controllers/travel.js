// var fs = require('fs');
// var trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
    method: 'GET',
    headers: { 'Accept': 'application/json' }
};

/* GET travel view */
const travel = async (req, res) => {
    let message = null;

    await fetch(tripsEndpoint, options)
        .then(response => response.json())
        .then(json => {
            if (!Array.isArray(json)) {
                // API did not return the expected shape of data
                message = 'API did not return an array of trips.';
                json = [];
            } else if (json.length === 0) {
                // API responded correctly, but there is no data yet
                message = 'No trips exist in our database!';
            }
            res.render('travel', { title: 'Travlr Getaways', trips: json, message });
        })
        .catch(err => res.status(500).send(err.message));
};

module.exports = {
    travel
};
