import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoginComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show a form error and not attempt login when fields are empty', () => {
    component.credentials = { name: '', email: '', password: '' };
    component.onLoginSubmit();
    expect(component.formError).toContain('All fields are required');
  });

  it('should not show a form error when mock credentials are fully filled in', () => {
    component.credentials = { name: 'Mock User', email: 'mock@travlr.test', password: 'mockpassword123' };
    component.onLoginSubmit();
    expect(component.formError).toBe('');
  });
});
