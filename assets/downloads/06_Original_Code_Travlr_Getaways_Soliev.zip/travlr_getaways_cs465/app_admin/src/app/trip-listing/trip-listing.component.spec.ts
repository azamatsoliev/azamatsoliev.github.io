import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';

import { TripListingComponent } from './trip-listing.component';
import { trips as mockTrips } from '../data/trips';

describe('TripListingComponent', () => {
  let component: TripListingComponent;
  let fixture: ComponentFixture<TripListingComponent>;
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripListingComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    })
    .compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(TripListingComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should create', () => {
    fixture.detectChanges();
    const req = httpMock.expectOne('http://localhost:3000/api/trips');
    req.flush(mockTrips);
    expect(component).toBeTruthy();
  });

  it('should populate trips from mock API data instead of the real backend', () => {
    fixture.detectChanges();

    // Intercept the HTTP call the component makes and respond with our mock trips
    const req = httpMock.expectOne('http://localhost:3000/api/trips');
    expect(req.request.method).toBe('GET');
    req.flush(mockTrips);

    expect(component.trips.length).toBe(mockTrips.length);
    expect(component.message).toContain(`${mockTrips.length} trips available`);
  });
});
