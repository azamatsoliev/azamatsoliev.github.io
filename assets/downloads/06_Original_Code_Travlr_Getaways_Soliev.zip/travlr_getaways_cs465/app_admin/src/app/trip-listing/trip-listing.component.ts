import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { TripCardComponent } from '../trip-card/trip-card.component';
import { TripDataService } from '../services/trip-data.service';
import { AuthenticationService } from '../services/authentication.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrl: './trip-listing.component.css'
})
export class TripListingComponent implements OnInit {

  trips: Trip[] = [];
  message: string = '';

  constructor(
    private tripDataService: TripDataService,
    private authenticationService: AuthenticationService,
    private router: Router
  ) {
    console.log('trip-listing constructor');
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.getTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  private getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: any) => {
        this.trips = value;
        if (value.length > 0) {
          this.message = `There are ${value.length} trips available.`;
        } else {
          this.message = 'There were no trips retrieved from the database.';
        }
        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
        this.message = 'There was a problem contacting the API to retrieve trips.';
      }
    });
  }

  // Navigate to the add-trip form
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  // Called when a trip-card emits a delete event
  public onDeleteTrip(trip: Trip): void {
    this.tripDataService.deleteTrip(trip.code).subscribe({
      next: () => {
        // Remove the trip from the local list so the UI updates immediately
        this.trips = this.trips.filter(t => t.code !== trip.code);
        this.message = `"${trip.name}" was deleted.`;
      },
      error: (error: any) => {
        console.log('Error deleting trip: ' + error);
        this.message = `There was a problem deleting "${trip.name}".`;
      }
    });
  }
}
