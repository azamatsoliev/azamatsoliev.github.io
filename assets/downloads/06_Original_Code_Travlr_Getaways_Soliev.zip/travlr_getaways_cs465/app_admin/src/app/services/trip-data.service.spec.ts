import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';

import { TripDataService } from './trip-data.service';
import { trips as mockTrips } from '../data/trips';

describe('TripDataService', () => {
  let service: TripDataService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(TripDataService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getTrips() should return mock trip data from the API endpoint', () => {
    service.getTrips().subscribe(trips => {
      expect(trips.length).toBe(mockTrips.length);
    });

    const req = httpMock.expectOne('http://localhost:3000/api/trips');
    expect(req.request.method).toBe('GET');
    req.flush(mockTrips);
  });

  it('addTrip() should POST the new trip to the API endpoint', () => {
    const newTrip: any = mockTrips[0];

    service.addTrip(newTrip).subscribe(result => {
      expect(result).toEqual(newTrip);
    });

    const req = httpMock.expectOne('http://localhost:3000/api/trips');
    expect(req.request.method).toBe('POST');
    req.flush(newTrip);
  });

  it('deleteTrip() should DELETE the trip by its code', () => {
    const code = mockTrips[0].code;

    service.deleteTrip(code).subscribe();

    const req = httpMock.expectOne(`http://localhost:3000/api/trips/${code}`);
    expect(req.request.method).toBe('DELETE');
    req.flush({ message: 'Trip deleted' });
  });
});
