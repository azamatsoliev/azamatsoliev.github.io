import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  baseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) { }

  // GET: retrieve the full list of trips
  getTrips(): Observable<Trip[]> {
    let url = `${this.baseUrl}/trips`;
    return this.http.get<Trip[]>(url);
  }

  // POST: add a new trip
  addTrip(formData: Trip): Observable<Trip> {
    let url = `${this.baseUrl}/trips`;
    return this.http.post<Trip>(url, formData);
  }

  // PUT: update an existing trip, identified by its trip code
  updateTrip(formData: Trip): Observable<Trip> {
    let url = `${this.baseUrl}/trips/${formData.code}`;
    return this.http.put<Trip>(url, formData);
  }

  // GET: retrieve a single trip by its trip code
  getTrip(tripCode: string): Observable<Trip[]> {
    let url = `${this.baseUrl}/trips/${tripCode}`;
    return this.http.get<Trip[]>(url);
  }

  // DELETE: remove a trip by its trip code
  deleteTrip(tripCode: string): Observable<any> {
    let url = `${this.baseUrl}/trips/${tripCode}`;
    return this.http.delete(url);
  }

  // Call to our /login endpoint, returns JWT
  login(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('login', user, passwd);
  }

  // Call to our /register endpoint, creates user and returns JWT
  register(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('register', user, passwd);
  }

  // Helper method to process both login and register calls
  handleAuthAPICall(endpoint: string, user: User, passwd: string): Observable<AuthResponse> {
    let formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };
    return this.http.post<AuthResponse>(`${this.baseUrl}/${endpoint}`, formData);
  }
}
