import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { AuthenticationService } from './authentication.service';

describe('AuthenticationService', () => {
  let service: AuthenticationService;

  beforeEach(() => {
    localStorage.removeItem('travlr-token');
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(AuthenticationService);
  });

  afterEach(() => {
    localStorage.removeItem('travlr-token');
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should report not logged in when no token is stored', () => {
    expect(service.isLoggedIn()).toBeFalse();
  });

  it('should report logged in when a valid (non-expired) mock JWT is stored', () => {
    // Build a fake, unsigned JWT with a future expiration — good enough to test
    // our own isLoggedIn() logic, which only reads the payload, not the signature.
    const header = btoa(JSON.stringify({ alg: 'none', typ: 'JWT' }));
    const payload = btoa(JSON.stringify({
      email: 'mock@travlr.test',
      name: 'Mock User',
      exp: Math.floor(Date.now() / 1000) + 3600
    }));
    const mockToken = `${header}.${payload}.mocksignature`;

    service.saveToken(mockToken);

    expect(service.isLoggedIn()).toBeTrue();
    expect(service.getCurrentUser().email).toBe('mock@travlr.test');
  });

  it('should report logged out after logout() clears the token', () => {
    service.saveToken('irrelevant.mock.token');
    service.logout();
    expect(service.getToken()).toBe('');
    expect(service.isLoggedIn()).toBeFalse();
  });
});
