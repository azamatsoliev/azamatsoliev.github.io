import { AppStorage } from './storage';

describe('AppStorage', () => {
  it('should create an instance', () => {
    expect(new AppStorage()).toBeTruthy();
  });
});
