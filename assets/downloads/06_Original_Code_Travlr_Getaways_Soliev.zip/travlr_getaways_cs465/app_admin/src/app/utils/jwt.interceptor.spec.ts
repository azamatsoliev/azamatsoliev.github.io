import { TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';

import { jwtInterceptor } from './jwt.interceptor';
import { AuthenticationService } from '../services/authentication.service';

describe('jwtInterceptor', () => {
  let httpClient: HttpClient;
  let httpMock: HttpTestingController;
  let authenticationService: AuthenticationService;

  beforeEach(() => {
    localStorage.removeItem('travlr-token');
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([jwtInterceptor])),
        provideHttpClientTesting()
      ]
    });
    httpClient = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    authenticationService = TestBed.inject(AuthenticationService);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.removeItem('travlr-token');
  });

  it('should NOT attach an Authorization header when the user is not logged in', () => {
    httpClient.get('http://localhost:3000/api/trips').subscribe();
    const req = httpMock.expectOne('http://localhost:3000/api/trips');
    expect(req.request.headers.has('Authorization')).toBeFalse();
    req.flush([]);
  });

  it('should attach a Bearer Authorization header when logged in with a mock token', () => {
    const header = btoa(JSON.stringify({ alg: 'none', typ: 'JWT' }));
    const payload = btoa(JSON.stringify({ email: 'mock@travlr.test', name: 'Mock', exp: Math.floor(Date.now() / 1000) + 3600 }));
    authenticationService.saveToken(`${header}.${payload}.mocksig`);

    httpClient.post('http://localhost:3000/api/trips', {}).subscribe();
    const req = httpMock.expectOne('http://localhost:3000/api/trips');
    expect(req.request.headers.get('Authorization')).toBe(`Bearer ${header}.${payload}.mocksig`);
    req.flush({});
  });

  it('should NOT attach a token to the /login endpoint even when logged in', () => {
    const header = btoa(JSON.stringify({ alg: 'none', typ: 'JWT' }));
    const payload = btoa(JSON.stringify({ email: 'mock@travlr.test', name: 'Mock', exp: Math.floor(Date.now() / 1000) + 3600 }));
    authenticationService.saveToken(`${header}.${payload}.mocksig`);

    httpClient.post('http://localhost:3000/api/login', {}).subscribe();
    const req = httpMock.expectOne('http://localhost:3000/api/login');
    expect(req.request.headers.has('Authorization')).toBeFalse();
    req.flush({});
  });
});
