// Mock trip data used for initial component development and testing,
// before wiring the component up to the live TripDataService/API.
export const trips = [
    {
        "code": "GLR010",
        "name": "Gale Reef",
        "length": "4 nights / 5 days",
        "start": "2027-02-14T08:00:00Z",
        "resort": "Emerald Bay Resort, 3 stars",
        "perPerson": "799.00",
        "image": "reef1.jpg",
        "description": "<p>Gale Reef: Sed et augue lorem. In sit amet placerat arcu. Mauris volutpat ipsum ac justo mollis vel vestibulum orci gravida. Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis.</p><p>Sed consequat libero ut turpis venenatis ut aliquam risus semper. Etiam convallis mi vel risus pretium sodales. Etiam nunc lorem ullamcorper vitae laoreet.</p>"
    },
    {
        "code": "DWR040",
        "name": "Dawson's Reef",
        "length": "5 nights / 6 days",
        "start": "2027-03-19T08:00:00Z",
        "resort": "Nautical Manor, 4 stars",
        "perPerson": "1099.00",
        "image": "reef2.jpg",
        "description": "<p>Dawson's Reef: Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a metus nec magna placerat volutpat. Nunc nisi mi, elementum sit amet aliquet quis, tristique quis nisl. Curabitur odio lacus, blandit ut hendrerit.</p><p>vulputate, vulputate at est. Morbi aliquet viverra metus eu consectetur. In lorem dui, elementum sit amet convallis ac, tincidunt vel sapien.</p>"
    },
    {
        "code": "CLR620",
        "name": "Claire's Reef",
        "length": "6 nights / 7 days",
        "start": "2027-06-21T08:00:00Z",
        "resort": "Coral Crest Resort, 5 stars",
        "perPerson": "1499.00",
        "image": "reef3.jpg",
        "description": "<p>Claire's Reef: Donec sed felis risus. Nulla facilisi. Donec a orci tellus, et auctor odio. Fusce ac orci nibh, quis semper arcu. Cras orci neque, euismod et accumsan ac, sagittis molestie lorem. Proin odio sapien, elementum at tempor non.</p><p>Vulputate eget libero. In hac habitasse platea dictumst. Integer purus justo, egestas eu consectetur eu, cursus in tortor. Quisque nec nunc ac mi ultrices iaculis.</p>"
    },
    {
        "code": "KYK150",
        "name": "Kayak Cove Adventure",
        "length": "3 nights / 4 days",
        "start": "2027-04-10T08:00:00Z",
        "resort": "Driftwood Lodge, 3 stars",
        "perPerson": "649.00",
        "image": "kayak.jpg",
        "description": "<p>Kayak Cove Adventure: Aliquam erat volutpat. Praesent ac sem eget est egestas volutpat. Curabitur blandit tempus porttitor. Vestibulum id ligula porta felis euismod semper.</p><p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Maecenas faucibus mollis interdum.</p>"
    },
    {
        "code": "SSD230",
        "name": "Sea Sound Getaway",
        "length": "5 nights / 6 days",
        "start": "2027-08-02T08:00:00Z",
        "resort": "Tidewater Inn, 4 stars",
        "perPerson": "1249.00",
        "image": "sea-sound.jpg",
        "description": "<p>Sea Sound Getaway: Donec ullamcorper nulla non metus auctor fringilla. Cras mattis consectetur purus sit amet fermentum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p><p>Nullam quis risus eget urna mollis ornare vel eu leo. Etiam porta sem malesuada magna mollis euismod.</p>"
    },
    {
        "code": "GSE880",
        "name": "Grand Suite Escape",
        "length": "7 nights / 8 days",
        "start": "2027-11-15T08:00:00Z",
        "resort": "The Regency Suites, 5 stars",
        "perPerson": "2199.00",
        "image": "suite.jpg",
        "description": "<p>Grand Suite Escape: Maecenas sed diam eget risus varius blandit sit amet non magna. Donec id elit non mi porta gravida at eget metus. Cum sociis natoque penatibus et magnis dis parturient montes.</p><p>Nascetur ridiculus mus. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>"
    }
];
