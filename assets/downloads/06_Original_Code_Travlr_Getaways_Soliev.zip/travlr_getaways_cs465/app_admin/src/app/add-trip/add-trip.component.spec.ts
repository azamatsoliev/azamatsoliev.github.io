import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { AddTripComponent } from './add-trip.component';

describe('AddTripComponent', () => {
  let component: AddTripComponent;
  let fixture: ComponentFixture<AddTripComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddTripComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddTripComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should mark the form invalid when required fields are empty', () => {
    expect(component.addForm.valid).toBeFalse();
  });

  it('should mark the form valid when mock data fills every required field', () => {
    component.addForm.setValue({
      code: 'MOCK001',
      name: 'Mock Reef',
      length: '4 nights / 5 days',
      start: '2027-01-01',
      resort: 'Mock Resort, 3 stars',
      perPerson: '999.00',
      image: 'reef1.jpg',
      description: 'A mock trip used for testing.'
    });
    expect(component.addForm.valid).toBeTrue();
  });
});
