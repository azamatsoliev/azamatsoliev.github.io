import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-trip.component.html',
  styleUrl: './add-trip.component.css'
})
export class AddTripComponent implements OnInit {

  public addForm!: FormGroup;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) { }

  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required],
    });
  }

  // Convenience getter for easy access to form fields in the template
  get f() { return this.addForm.controls; }

  onSubmit(): void {
    this.submitted = true;

    // Stop here if the form is invalid
    if (this.addForm.invalid) {
      return;
    }

    this.saveTrip(this.addForm.value);
  }

  cancel(): void {
    this.router.navigate(['']);
  }

  saveTrip(formValues: Trip): void {
    this.tripDataService.addTrip(formValues).subscribe({
      next: (value) => {
        console.log('Trip added: ', value);
        this.router.navigate(['']);
      },
      error: (error: any) => {
        console.log('Error adding trip: ' + error);
      }
    });
  }
}
