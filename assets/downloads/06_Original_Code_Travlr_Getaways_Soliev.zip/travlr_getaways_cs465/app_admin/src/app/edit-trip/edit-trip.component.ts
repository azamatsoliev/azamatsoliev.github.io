import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.component.html',
  styleUrl: './edit-trip.component.css'
})
export class EditTripComponent implements OnInit {

  public editForm!: FormGroup;
  submitted = false;
  tripCode: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) { }

  ngOnInit(): void {
    console.log('EditTripComponent::ngOnInit');

    this.editForm = this.formBuilder.group({
      _id: [''],
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required],
    });

    // Retrieve the trip code that trip-card stashed in localStorage before navigating here
    this.tripCode = localStorage.getItem('tripCode') || '';
    console.log('tripCode: ' + this.tripCode);

    if (this.tripCode) {
      this.getTrip(this.tripCode);
    }
  }

  // Convenience getter for easy access to form fields in the template
  get f() { return this.editForm.controls; }

  getTrip(tripCode: string): void {
    this.tripDataService.getTrip(tripCode).subscribe({
      next: (value: any) => {
        // The API returns an array (find by code); grab the first match
        const trip = Array.isArray(value) ? value[0] : value;
        console.log('Trip retrieved: ' + JSON.stringify(trip));

        this.editForm.setValue({
          _id: trip._id,
          code: trip.code,
          name: trip.name,
          length: trip.length,
          start: this.formatDateForInput(trip.start),
          resort: trip.resort,
          perPerson: trip.perPerson,
          image: trip.image,
          description: trip.description
        });
      },
      error: (error: any) => {
        console.log('Error retrieving trip: ' + error);
      }
    });
  }

  // The date input control expects "yyyy-MM-dd"; Mongo returns a full ISO timestamp
  private formatDateForInput(dateValue: string): string {
    if (!dateValue) return '';
    return new Date(dateValue).toISOString().substring(0, 10);
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.editForm.invalid) {
      return;
    }

    this.saveTrip(this.editForm.value);
  }

  saveTrip(formValues: Trip): void {
    this.tripDataService.updateTrip(formValues).subscribe({
      next: (value) => {
        console.log('Trip updated: ', value);
        this.router.navigate(['']);
      },
      error: (error: any) => {
        console.log('Error updating trip: ' + error);
      }
    });
  }

  cancel(): void {
    this.router.navigate(['']);
  }
}
