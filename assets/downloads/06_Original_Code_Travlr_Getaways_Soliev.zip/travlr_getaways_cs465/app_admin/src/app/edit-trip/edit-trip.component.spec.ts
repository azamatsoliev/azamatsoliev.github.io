import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';

import { EditTripComponent } from './edit-trip.component';
import { trips as mockTrips } from '../data/trips';

describe('EditTripComponent', () => {
  let component: EditTripComponent;
  let fixture: ComponentFixture<EditTripComponent>;
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    // edit-trip reads the selected trip's code from localStorage before it loads
    localStorage.setItem('tripCode', mockTrips[0].code);

    await TestBed.configureTestingModule({
      imports: [EditTripComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    })
    .compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(EditTripComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.removeItem('tripCode');
  });

  it('should create', () => {
    fixture.detectChanges();
    const req = httpMock.expectOne(`http://localhost:3000/api/trips/${mockTrips[0].code}`);
    req.flush([mockTrips[0]]);
    expect(component).toBeTruthy();
  });

  it('should pre-fill the form from mock trip data', () => {
    fixture.detectChanges();

    const req = httpMock.expectOne(`http://localhost:3000/api/trips/${mockTrips[0].code}`);
    req.flush([mockTrips[0]]);

    expect(component.editForm.value.name).toBe(mockTrips[0].name);
    expect(component.editForm.value.code).toBe(mockTrips[0].code);
  });
});
