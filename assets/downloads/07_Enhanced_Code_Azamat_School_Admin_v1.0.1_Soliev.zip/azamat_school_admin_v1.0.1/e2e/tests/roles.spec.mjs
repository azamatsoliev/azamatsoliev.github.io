/**
 * End-to-end tests: each role, through the real system.
 *
 * Signs in as the owner, the accountant and a teacher, checks what each is
 * offered and can do, and saves the screenshots used in the ePortfolio. The
 * double-booking test proves that the conflict check runs on the server and
 * reaches the screen as a readable message.
 *
 * Requires the API on port 3000 against the demo school ("npm run seed:demo",
 * then "npm run start:demo"), and the built interface on port 4200
 * ("npm run serve" in this folder).
 *
 * @file    e2e/tests/roles.spec.mjs
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { test, expect } from '@playwright/test';
import { ACCOUNTS, DEMO_MONTH, mainNav, openSection, selectMonth, shot, signIn } from './support.mjs';

test.describe.configure({ mode: 'serial' });

test('a signed-out visitor is taken to the sign-in screen', async ({ page }) => {
  await page.goto('/reports');
  await expect(page).toHaveURL(/\/login\?returnUrl=%2Freports/);
  await expect(page.getByRole('heading', { name: 'Sign in' })).toBeVisible();
  await shot(page, '01-sign-in');
});

test('a wrong password is explained in plain words', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email address').fill(ACCOUNTS.owner.email);
  await page.getByLabel('Password').fill('not-the-password');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('alert')).toHaveText('Email or password is incorrect.');
});

test('owner: every section, the class summary, and a refused double booking', async ({ page }) => {
  await signIn(page, ACCOUNTS.owner);
  await expect(mainNav(page).getByRole('link')).toHaveText(
    ['Azamat School Admin', 'Home', 'Students', 'Teachers', 'Class Sessions', 'Payments', 'Attendance', 'Reports']
  );
  await shot(page, '02-owner-home');

  await openSection(page, 'Reports');
  await selectMonth(page, DEMO_MONTH);
  await expect(page.getByRole('cell', { name: 'Beginner English A1' })).toBeVisible();
  await shot(page, '03-owner-class-summary');

  // Beginner English A1 runs 09:00 to 11:00 on Monday 7 September; this overlaps it.
  await openSection(page, 'Class Sessions');
  await page.getByRole('button', { name: 'Add Class Session' }).click();
  await page.getByLabel('Title').fill('Extra speaking practice');
  await page.getByLabel('Teacher').selectOption({ label: 'Dilnoza Karimova' });
  await page.getByLabel('Starts').fill('2026-09-07T09:30');
  await page.getByLabel('Ends').fill('2026-09-07T10:30');
  await page.getByLabel('Rate').fill('25');
  await page.getByLabel('Room').fill('Room 1');
  await page.getByRole('button', { name: 'Save' }).click();

  await expect(page.getByRole('alert')).toContainText('This teacher is already booked for "Beginner English A1"');
  await shot(page, '04-owner-double-booking-refused');
});

test('accountant: balances and monthly revenue, with no teaching screens', async ({ page }) => {
  await signIn(page, ACCOUNTS.accountant);
  await expect(mainNav(page).getByRole('link')).toHaveText(
    ['Azamat School Admin', 'Home', 'Students', 'Payments', 'Reports']
  );

  await openSection(page, 'Reports');
  await expect(page.getByRole('columnheader', { name: 'Outstanding' })).toBeVisible();
  await shot(page, '05-accountant-balances');

  await page.getByRole('link', { name: 'Monthly Revenue' }).click();
  await selectMonth(page, DEMO_MONTH);
  await expect(page.getByRole('button', { name: 'Export CSV' })).toBeVisible();
  await expect(page.getByRole('columnheader', { name: 'Collected' })).toBeVisible();
  await shot(page, '06-accountant-monthly-revenue');
});

test('teacher: own lessons and attendance, student names only, no money', async ({ page }) => {
  await signIn(page, ACCOUNTS.teacher);
  await expect(mainNav(page).getByRole('link')).toHaveText(
    ['Azamat School Admin', 'Home', 'Class Sessions', 'Attendance', 'Reports']
  );
  await shot(page, '07-teacher-home');

  await openSection(page, 'Reports');
  await selectMonth(page, DEMO_MONTH);
  await expect(page.getByText('Beginner English A1').first()).toBeVisible();
  await expect(page.getByText('Billed')).toHaveCount(0);
  await shot(page, '08-teacher-attendance-sheet');

  await openSection(page, 'Class Sessions');
  await expect(page.getByRole('cell', { name: 'Dilnoza Karimova' }).first()).toBeVisible();
  await expect(page.getByRole('cell', { name: 'Jasur Aliev' })).toHaveCount(0);

  await openSection(page, 'Attendance');
  await page.getByRole('button', { name: 'Add Attendance Record' }).click();
  const student = page.getByLabel('Student');
  await expect(student.locator('option', { hasText: 'Aziza Rahimova' })).toHaveCount(1);
  await expect(student).not.toContainText('@');
  await shot(page, '09-teacher-record-attendance');

  // A teacher cannot open the student records screen, even by typing its address.
  await page.goto('/manage/students');
  await expect(page.getByRole('heading', { name: `Welcome, ${ACCOUNTS.teacher.name}` })).toBeVisible();
});
