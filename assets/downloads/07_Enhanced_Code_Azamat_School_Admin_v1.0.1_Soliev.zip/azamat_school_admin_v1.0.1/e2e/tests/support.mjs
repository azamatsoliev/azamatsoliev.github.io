/**
 * Shared helpers for the end-to-end tests.
 *
 * @file    e2e/tests/support.mjs
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { expect } from '@playwright/test';
import { mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

/** The demo school's accounts, as created by "npm run seed:demo". */
export const ACCOUNTS = {
  owner: { name: 'School Owner', email: 'owner@school.example', password: 'DemoOwner123' },
  accountant: { name: 'Madina Yusupova', email: 'accounts@school.example', password: 'DemoAccounts123' },
  teacher: { name: 'Dilnoza Karimova', email: 'dilnoza@school.example', password: 'DemoTeacher123' }
};

/** A month entirely in the past in the demo data, so results never depend on today's date. */
export const DEMO_MONTH = '2026-09';

const screenshotFolder = fileURLToPath(new URL('../screenshots/', import.meta.url));
mkdirSync(screenshotFolder, { recursive: true });

/** Saves a full-page screenshot for the ePortfolio. */
export const shot = async (page, name) => {
  await page.screenshot({ path: `${screenshotFolder}${name}.png`, fullPage: true });
};

/** The main navigation bar. */
export const mainNav = (page) => page.getByRole('navigation', { name: 'Main' });

/** Signs in through the sign-in screen and waits for the home page. */
export const signIn = async (page, account) => {
  await page.goto('/login');
  await page.getByLabel('Email address').fill(account.email);
  await page.getByLabel('Password').fill(account.password);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page.getByRole('heading', { name: `Welcome, ${account.name}` })).toBeVisible();
};

/** Opens a section from the main navigation. */
export const openSection = async (page, name) => {
  await mainNav(page).getByRole('link', { name, exact: true }).click();
};

/** Chooses the month shown by the reports screen. */
export const selectMonth = async (page, month) => {
  const input = page.getByLabel('Month');
  await input.fill(month);
  await input.dispatchEvent('change');
};
