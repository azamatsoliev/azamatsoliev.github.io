/**
 * Serves the production build of the admin interface.
 *
 * A minimal static file server with one rule a single-page application needs:
 * any path that is not a file returns index.html, so opening /reports directly
 * loads the application and lets its router show the page.
 *
 * Usage: node serve-dist.mjs [port]   (default 4200)
 *
 * @file    e2e/serve-dist.mjs
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('.', import.meta.url)), '../app_admin/dist/azamat-school-admin-web/browser');
const port = Number(process.argv[2] || 4200);

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
  '.txt': 'text/plain; charset=utf-8'
};

/** Resolves a request path to a file inside the build folder, or null. */
const fileFor = async (urlPath) => {
  const relative = normalize(decodeURIComponent(urlPath.split('?')[0])).replace(/^([/\\])+/, '');
  const candidate = resolve(root, relative);
  if (!candidate.startsWith(root)) {
    return null; // a path climbing out of the build folder
  }
  try {
    return (await stat(candidate)).isFile() ? candidate : null;
  } catch {
    return null;
  }
};

createServer(async (req, res) => {
  const file = (await fileFor(req.url || '/')) || join(root, 'index.html');
  try {
    const body = await readFile(file);
    res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream' });
    res.end(body);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Build not found. Run "npm run build" in app_admin first.');
  }
}).listen(port, () => {
  console.log(`Admin interface served from ${root} at http://localhost:${port}`);
});
