/**
 * Playwright configuration for the end-to-end tests.
 *
 * The tests run against the whole system: the API connected to MongoDB and
 * loaded with the demo school, and the production build of the admin
 * interface. They run one at a time because they share that database.
 *
 * @file    e2e/playwright.config.mjs
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  outputDir: './test-results',
  timeout: 60_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  reporter: [['list'], ['html', { open: 'never', outputFolder: 'playwright-report' }]],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:4200',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure'
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'], viewport: { width: 1280, height: 800 } }
    }
  ]
});
