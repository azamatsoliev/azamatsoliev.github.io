# Azamat School Admin

**Management platform for small language schools.** Student records, teaching
staff, class scheduling, attendance, tuition payments and reports, with a
separate view for the owner, the accountant and each teacher.

Built with MongoDB, Express, Angular and Node.js (the MEAN stack) by
**Azamat Soliev** as the capstone of the B.S. in Computer Science at Southern
New Hampshire University.

[![CI](https://github.com/azamatsoliev/azamat-school-admin/actions/workflows/ci.yml/badge.svg)](https://github.com/azamatsoliev/azamat-school-admin/actions/workflows/ci.yml)

- **ePortfolio** (screenshots, narratives, code review): <https://azamatsoliev.github.io>
- **Project history:** began as *Travlr Getaways*, a travel booking site built
  for CS 465. See [Project history](#project-history).

---

## What it does

| Role | Can see and do |
|---|---|
| **Owner** | Everything: students, teachers, class sessions, payments, attendance, and every report. Creates staff accounts. |
| **Accountant** | Students and payments; balances, monthly revenue with CSV export, and the yearly revenue trend. |
| **Teacher** | Their own class sessions and attendance; their monthly attendance sheet. Student names only, never contact details or money. |

Highlights:

- **No double bookings.** A teacher cannot be booked into overlapping lessons.
  The check is an indexed range search, O(log n + k) with k proven to be at
  most 32, so it stays fast however long the teacher's history grows.
- **Exact money.** Balances and revenue are summed in whole cents inside
  MongoDB aggregation pipelines, so a settled balance is exactly zero.
- **Least privilege at every level.** Role checks decide what an account may
  do, scope rules decide which records it may touch, and projections decide
  which fields it may read.

## How it is built

```mermaid
flowchart LR
    Browser["Angular admin app<br/>(app_admin)"] -- "JSON over HTTP<br/>Bearer token" --> API["Express REST API<br/>(app.js, app_api)"]
    API -- Mongoose --> DB[("MongoDB")]
    API --- Auth["Sign-in: Passport + JWT<br/>PBKDF2 password hashing"]
    API --- Factory["Generic CRUD controller<br/>role, scope, field and projection rules"]
    API --- Sched["Conflict detection<br/>bounded index search + per-teacher lock"]
    API --- Reports["Reports<br/>aggregation pipelines, whole-cent money"]
```

More detail: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) ·
[docs/SECURITY.md](docs/SECURITY.md) · [docs/TESTING.md](docs/TESTING.md)

---

## Run it on your computer

### What you need

- **Node.js 22 or 24** (LTS): <https://nodejs.org>
- **MongoDB Community Server 8**, running on the default port 27017
- **Git**

### Steps (Windows PowerShell; the same commands work on macOS and Linux)

1. **Get the code and install the API's packages.**

   ```powershell
   git clone https://github.com/azamatsoliev/azamat-school-admin.git
   cd azamat-school-admin
   npm install
   ```

2. **Create your settings file.** Copy the template, then generate a secret:

   ```powershell
   Copy-Item .env.example .env
   node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
   ```

   Open `.env` and replace the value after `JWT_SECRET=` with the line the
   second command printed. Never commit or share this file.

3. **Build the demo school** (eight students, two teachers, four months of
   lessons, attendance and payments):

   ```powershell
   npm run seed:demo
   ```

4. **Start the API against the demo school.** It prints
   `API listening on http://localhost:3000`. Leave this window open.

   ```powershell
   npm run start:demo
   ```

   Check it at <http://localhost:3000/api/health>: it should show
   `"database": "connected"`.

5. **Start the admin interface** in a second window:

   ```powershell
   cd app_admin
   npm install
   npm start
   ```

6. **Open <http://localhost:4200>** and sign in with a demo account.

### Demo accounts

Local demonstration only. These passwords are published, so never use them
anywhere else.

| Role | Email | Password |
|---|---|---|
| Owner | `owner@school.example` | `DemoOwner123` |
| Accountant | `accounts@school.example` | `DemoAccounts123` |
| Teacher | `dilnoza@school.example` | `DemoTeacher123` |
| Teacher | `jasur@school.example` | `DemoTeacher123` |

### Using your own data instead of the demo

Run `npm start` instead of `npm run start:demo`. The API then uses the
`azamat_school` database. Create the first owner account from the command
line; the owner then creates every other account (`POST /api/users`):

```powershell
npm run create-owner -- owner@yourschool.com "Your Name" YourPassword123
```

### Scripts

| Command | What it does |
|---|---|
| `npm start` | Starts the API on port 3000 |
| `npm run start:demo` | Starts the API against the demo database |
| `npm run seed:demo` | Builds (or rebuilds) the demo school in its own database |
| `npm run create-owner -- <email> "<name>" <password>` | Creates the first owner account |
| `npm test` | Runs the backend test suite |
| `npm run verify:reports` | Checks every report figure on a real MongoDB server |
| `npm run bench` | Conflict-detection benchmark, in memory |
| `npm run bench:mongo` | The same benchmark with MongoDB's own execution statistics |
| `cd app_admin && npm run test:ci` | Runs the Angular tests in a headless browser |

---

## Testing

| Suite | Result |
|---|---|
| Backend (`npm test`) | 214 tests passing |
| Angular (`npm run test:ci`) | 69 specs passing |
| Report verification on MongoDB 8 | Run by GitHub Actions on every push |
| End-to-end, in a real browser against the running system | Run by GitHub Actions on every push |

Every push runs all of these in GitHub Actions, against a real MongoDB server.
How the suites are organized, and how a test is proven able to fail, is in
[docs/TESTING.md](docs/TESTING.md). All figures are listed in
[docs/metrics.md](docs/metrics.md).

## Security

A summary; the full threat-by-threat table is in
[docs/SECURITY.md](docs/SECURITY.md).

- Passwords: PBKDF2-HMAC-SHA512 at 210,000 iterations, compared in constant
  time; older hashes are upgraded at sign-in.
- Accounts: no public sign-up. The owner creates staff accounts; the first
  owner is created from the server's command line.
- Sign-in is rate limited, and every refusal gives the same answer, so a
  response never reveals which addresses are registered.
- Every request is authorized on the server by role, by record ownership and
  by field. A teacher sees only their own lessons, and only students' names.
- Request bodies containing MongoDB operators are refused, and query strings
  are parsed flatly, so neither can inject a query.
- Double bookings are prevented by a server-side check serialized per
  teacher, so two simultaneous requests cannot both pass it.
- CSV exports neutralize spreadsheet formulas; report responses are never
  cached; connection-string passwords are hidden in logs.
- The API refuses to start without a strong signing secret, sends standard
  security headers, and answers errors with JSON that reveals nothing
  internal.

## Known limitations and roadmap

| Limitation | Next step |
|---|---|
| The booking lock and the sign-in limiter hold within one server process. | Move both to the database, for example a transaction on a replica set and a shared rate-limit store, before running several copies of the API. |
| Teachers see every active student's name, not only their own students. | Add an Enrollment entity that assigns students to classes, then return per-class rosters. |
| Lesson months are grouped in the server's time zone. | Add a school time-zone setting and pass it to the date operators. |
| The sign-in token is kept in browser storage. | Move it to an httpOnly cookie with cross-site request forgery protection. |
| The admin interface uses Angular 17, which is past its support period; `npm audit` lists advisories in the framework packages that are fixed only in Angular 20 and later. | Upgrade Angular one major version at a time, using the 69 specs as the safety net. |
| Staff accounts are created through the API, not yet from a screen. | Add an account administration screen for the owner. |

---

## Project history

This repository holds the whole history of the artifact, from the original
CS 465 project to this release. Each stage is tagged; open a tag to browse or
download that version.

| Tag | Stage |
|---|---|
| [`cs465-original`](https://github.com/azamatsoliev/azamat-school-admin/tree/cs465-original) | **Travlr Getaways**, as submitted for CS 465 Full Stack Development (July–August 2026): a travel booking site with an Angular admin app for a single trip catalog. |
| [`enhancement-1-software-design`](https://github.com/azamatsoliev/azamat-school-admin/tree/enhancement-1-software-design) | CS 499 Enhancement One: rebuilt as a role-based school platform with a generic controller factory, a configuration-driven interface, record-level scoping and stronger password hashing. |
| [`enhancement-2-algorithms`](https://github.com/azamatsoliev/azamat-school-admin/tree/enhancement-2-algorithms) | Enhancement Two: scheduling conflict detection as a bounded indexed search, with a per-teacher lock and a benchmark. |
| [`enhancement-3-databases`](https://github.com/azamatsoliev/azamat-school-admin/tree/enhancement-3-databases) | Enhancement Three: aggregation-pipeline reports, exact money and database security. |
| [`v1.0.0`](https://github.com/azamatsoliev/azamat-school-admin/tree/v1.0.0) | Final release, **Azamat School Admin**: the remaining travel features retired, public sign-up closed, sign-in rebuilt, teachers able to take attendance, and continuous integration on a real MongoDB server. |
| [`v1.0.1`](https://github.com/azamatsoliev/azamat-school-admin/tree/v1.0.1) | Patch release: accounts stored at the original password work factor can sign in again, and the documentation states counted figures only. |

The differences between any two stages can be viewed on GitHub, for example
[Enhancement Three to the latest release](https://github.com/azamatsoliev/azamat-school-admin/compare/enhancement-3-databases...v1.0.1).
Changes are summarized in [CHANGELOG.md](CHANGELOG.md).

## Repository layout

```
app.js                  Express application (API only)
bin/                    Server start-up scripts
app_api/
  config/               Roles, entity rules, settings checks, sign-in strategy
  controllers/          Generic CRUD factory, sign-in, accounts, reports
  middleware/           Token verification, role checks, rate limiting
  models/               Mongoose schemas
  reports/              Aggregation pipelines, periods, CSV export
  scheduling/           Conflict detection and edit policies
  utils/                Per-key lock, whole-cent money
  tests/                Backend tests (node --test)
  tools/                Demo seeder, report verifier, benchmark
app_admin/              Angular admin interface
e2e/                    End-to-end browser tests (Playwright)
docs/                   Architecture, security, testing, figures
```

## Author

**Azamat Soliev** · [azamatthefirst1@gmail.com](mailto:azamatthefirst1@gmail.com) ·
[LinkedIn](https://www.linkedin.com/in/azamatsoliev) ·
[ePortfolio](https://azamatsoliev.github.io)

The original CS 465 project's public pages used a website template supplied
with the course; that template was removed in the final release.
