# Changelog

Each release is tagged in this repository. Version 1.0.0 is the first release
under the name Azamat School Admin; the earlier tags are the CS 499 enhancement
milestones and the original CS 465 project they started from.

## [1.0.1] — October 2026 · Patch release

### Fixed

- **Accounts stored at the original password work factor could not sign in.**
  The iteration count added in Enhancement One had a schema default, and
  Mongoose applies defaults when it loads a record, so a hash created before
  the count was stored was checked at 210,000 iterations instead of 1,000, and
  was never upgraded. The default is removed, and the tests now load the
  account the way a database query returns it.

### Documentation

- The architecture guide gave an estimate of the files a new record type would
  otherwise need. It now gives the counted figure from the original project.

## [1.0.0] — October 2026 · Final release

The application now stands on its own as a school platform.

### Removed

- The server-rendered travel website inherited from the original project:
  Handlebars views, static pages, more than fifty travel images, the trip API,
  trip model and seed data, and the Angular trip list, add and edit screens. It
  served the travel business the project began as, not the school, and every
  route it exposed was attack surface the school did not need.
- Public self-registration (`POST /api/register`). Anyone on the network could
  create an account.
- Unused packages: `express-jwt`, `hbs`, `cookie-parser`, `http-errors`,
  `debug`, `jquery`, `@popperjs/core`.

### Added

- Owner-only account creation, `POST /api/users`, with the role and teacher
  link checked at creation.
- Teachers can record attendance from the interface. They may now read the
  student list, but a projection limits them to names.
- Sign-in rate limiting, standard security headers, and a start-up check that
  refuses to run without a strong signing secret.
- `GET /api/health`, reporting whether the API can reach its database.
- A role-aware home page, route guards, a skip link, and a collapsible menu for
  narrow screens.
- `npm run seed:demo` and `npm run start:demo`, one command each on every
  platform.
- Continuous integration: backend tests, Angular tests and the production build
  on every push, plus report verification, the MongoDB benchmark and
  end-to-end browser tests against a real MongoDB server.

### Fixed

- **The API stopped when someone tried to sign in while MongoDB was
  unreachable.** An error in the sign-in lookup became an unhandled promise
  rejection, which ends a Node process. It now answers 503 and keeps running.
- **Sign-in screen:** it required a Name field the server never read, guessed
  the outcome with a three-second timer, showed nothing for a wrong password,
  and printed the token to the browser console. It now waits for the server
  and explains each failure.
- **The token interceptor** attached the sign-in token to every outgoing
  request, including any to another site. It now attaches it to API requests
  only, and opens sign-in when the token expires.
- **Token decoding** failed for some names written in non-English alphabets,
  and garbled others, because the token's base64url and UTF-8 encoding were
  read with `atob()` alone.
- Server shutdown now waits for the database connection to close.
- Errors are answered as JSON; nothing internal is shown.

### Changed

- Renamed from Travlr School Admin to **Azamat School Admin**; the database is
  `azamat_school`.
- Demo accounts use the reserved `school.example` domain.
- Comments and documentation use American English throughout.

## [enhancement-3-databases] — October 2026 · CS 499 Milestone Four

Aggregation-pipeline reporting for each role, exact whole-cent money, and
database security hardening: operator-injection defenses, attendance
ownership, least-privilege connection support, password redaction in logs,
formula-safe CSV export. 167 backend tests.

## [enhancement-2-algorithms] — September 2026 · CS 499 Milestone Three

Scheduling conflict detection as a bounded indexed range search,
O(log n + k) with k proven at most 32, against an O(n) baseline; a per-teacher
lock closing the simultaneous-booking race; teacher edit restrictions; an
in-memory and MongoDB benchmark. 105 backend tests.

## [enhancement-1-software-design] — September 2026 · CS 499 Milestone Two

Five school entities served by a generic controller factory and a
configuration-driven Angular screen; three roles with inheritance and
record-level scoping; field whitelisting; soft delete; PBKDF2 raised from
1,000 to 210,000 iterations with transparent upgrade. Five defects from the
code review corrected, including a stored cross-site scripting flaw. 51
backend tests.

## [cs465-original] — August 2026 · CS 465 Full Stack Development

Travlr Getaways: a travel booking site (Express and Handlebars) with a REST API
and an Angular admin app for a single trip catalog. The baseline every later
version is measured against.

[1.0.1]: https://github.com/azamatsoliev/azamat-school-admin/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/azamatsoliev/azamat-school-admin/compare/enhancement-3-databases...v1.0.0
[enhancement-3-databases]: https://github.com/azamatsoliev/azamat-school-admin/compare/enhancement-2-algorithms...enhancement-3-databases
[enhancement-2-algorithms]: https://github.com/azamatsoliev/azamat-school-admin/compare/enhancement-1-software-design...enhancement-2-algorithms
[enhancement-1-software-design]: https://github.com/azamatsoliev/azamat-school-admin/compare/cs465-original...enhancement-1-software-design
[cs465-original]: https://github.com/azamatsoliev/azamat-school-admin/tree/cs465-original
