/**
 * Scheduling conflict detection.
 *
 * Prevents one teacher from being booked into two overlapping class sessions.
 * The check runs on the server, on both create and update, and it is the
 * authoritative control: a client-side check could be bypassed by sending a
 * request directly, so it would be a convenience rather than a safeguard.
 *
 * ---------------------------------------------------------------------------
 * THE PROBLEM
 * ---------------------------------------------------------------------------
 *
 * Two sessions conflict when their time intervals overlap. Intervals are
 * treated as half-open, [start, end), so a lesson ending at 11:00 and another
 * starting at 11:00 are back to back rather than in conflict. That matches how
 * a school timetable is actually used.
 *
 * Existing session S and proposed session P overlap exactly when
 *
 *     S.start < P.end   and   S.end > P.start
 *
 * ---------------------------------------------------------------------------
 * THREE APPROACHES AND THEIR COST
 * ---------------------------------------------------------------------------
 *
 * Let n be the number of sessions the teacher has ever had, and k the number
 * of candidate sessions the query returns.
 *
 * 1. Naive scan - O(n) time, O(n) memory.
 *    Load every session the teacher has and compare each one to the proposal.
 *    Correct, but the work grows with the teacher's entire history, however far
 *    the proposal is from any existing session. After three years of lessons,
 *    booking next Tuesday reads and transfers three years of records.
 *
 * 2. Indexed but unbounded - still O(n). This is the trap.
 *    Put an index on (teacherId, startTime) and query the overlap condition
 *    directly: startTime < P.end AND endTime > P.start. It looks optimized, but
 *    an index is ordered by startTime and can only use that field. The first
 *    condition gives the scan an upper bound and no lower bound, so the database
 *    walks every entry from the beginning of the teacher's history up to P.end,
 *    then discards most of them against the endTime condition. Adding the index
 *    changed nothing asymptotically.
 *
 * 3. Indexed and bounded on both sides - O(log n + k), with k <= 32.
 *    This module's approach. The missing lower bound comes from the schema: no
 *    session may last longer than MAX_SESSION_DURATION_MS. Since S.end is at
 *    most S.start + MAX, the requirement S.end > P.start forces
 *
 *        S.start > P.start - MAX
 *
 *    So every session that could possibly overlap P starts inside the open
 *    window (P.start - MAX, P.end). Both ends of that window apply to startTime,
 *    which the index can serve. The database seeks to the window in O(log n)
 *    through the B-tree and walks only the k entries inside it. Each candidate
 *    is then tested exactly with intervalsOverlap in O(1), so the whole check
 *    costs O(log n + k).
 *
 * ---------------------------------------------------------------------------
 * WHY k IS BOUNDED BY A CONSTANT
 * ---------------------------------------------------------------------------
 *
 * O(log n + k) is only an improvement if k does not itself grow with n. It does
 * not, because of an invariant this module maintains:
 *
 *   Invariant: no two active sessions of the same teacher overlap.
 *
 * It holds inductively. It is true of an empty schedule, and every write that
 * could break it passes through this check first, which refuses any write that
 * would. So at any moment, one teacher's active sessions are laid end to end,
 * and consecutive start times are at least MIN_SESSION_DURATION_MS apart.
 *
 * The window has length MAX + d, where d is the proposed session's duration,
 * itself at most MAX. It therefore spans at most 2 * MAX = 8 hours. Starts at
 * least 15 minutes apart can number at most 8 hours / 15 minutes = 32 inside
 * it. Hence k <= 32 for every query, regardless of history size, and the check
 * is O(log n) in the worst case. The unit tests confirm this bound empirically
 * against thousands of randomly generated schedules.
 *
 * ---------------------------------------------------------------------------
 * THE TRADE-OFF
 * ---------------------------------------------------------------------------
 *
 * The bounded query is correct only because session length is constrained on
 * every write. A session longer than MAX could start before the lower bound and
 * be missed. The fully general unbounded scan needs no such rule but has no
 * cost ceiling. This design deliberately trades generality for a guaranteed
 * ceiling, and pays for it with two schema constraints, a 15-minute minimum and
 * a 4-hour maximum, both of which a language school can accept without cost.
 *
 * @file    app_api/scheduling/conflictDetection.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const {
    MAX_SESSION_DURATION_MS,
    MIN_SESSION_DURATION_MS
} = require('../models/classSession');

/** HTTP status for a request that conflicts with the current schedule. */
const CONFLICT_STATUS = 409;

/**
 * Converts a date-like value to milliseconds since the epoch.
 *
 * @param   {Date|string|number} value - A Date, an ISO string, or a timestamp.
 * @returns {number} Milliseconds, or NaN when the value is not a valid time.
 */
const toTime = (value) => {
    if (value === null || value === undefined || value === '') {
        return Number.NaN;
    }
    const time = value instanceof Date ? value.getTime() : new Date(value).getTime();
    return Number.isNaN(time) ? Number.NaN : time;
};

/**
 * Reports whether two half-open intervals [aStart, aEnd) and [bStart, bEnd)
 * overlap.
 *
 * Runs in O(1). Sessions that merely touch, one ending as the next begins, do
 * not overlap.
 *
 * @returns {boolean} True when the intervals share any moment of time.
 */
const intervalsOverlap = (aStart, aEnd, bStart, bEnd) =>
    toTime(aStart) < toTime(bEnd) && toTime(bStart) < toTime(aEnd);

/**
 * Computes the open window in which any session overlapping the proposal must
 * start.
 *
 * Shared by the database query and by the in-memory model used in the tests
 * and benchmark, so the bounds being tested are the bounds being used.
 *
 * @param   {number} proposedStart - Proposed start, in milliseconds.
 * @param   {number} proposedEnd   - Proposed end, in milliseconds.
 * @returns {{ lowerExclusive: number, upperExclusive: number }}
 */
const candidateWindow = (proposedStart, proposedEnd) => ({
    lowerExclusive: proposedStart - MAX_SESSION_DURATION_MS,
    upperExclusive: proposedEnd
});

/**
 * Builds the database filter that retrieves candidate sessions.
 *
 * Every condition here is served by the compound index
 * { teacherId: 1, active: 1, startTime: 1 }: two equality matches followed by a
 * range with both a lower and an upper bound. That is what allows the database
 * to examine only the k entries inside the window rather than the teacher's
 * whole history.
 *
 * The endTime condition is deliberately left out of the query. The index cannot
 * use it, and applying it in the database would not reduce the number of index
 * entries examined. It is instead applied exactly, in O(1) per candidate, by
 * intervalsOverlap.
 *
 * @param   {object} params
 * @param   {*}      params.teacherId - Teacher whose schedule is checked.
 * @param   {number} params.start     - Proposed start, in milliseconds.
 * @param   {number} params.end       - Proposed end, in milliseconds.
 * @param   {*}      [params.excludeId] - Session being updated, if any.
 * @returns {object} A MongoDB filter.
 */
const buildCandidateFilter = ({ teacherId, start, end, excludeId = null }) => {
    const { lowerExclusive, upperExclusive } = candidateWindow(start, end);

    const filter = {
        teacherId,
        active: true,
        startTime: { $gt: new Date(lowerExclusive), $lt: new Date(upperExclusive) }
    };

    // A session being rescheduled must not be reported as conflicting with
    // its own current time slot.
    if (excludeId) {
        filter._id = { $ne: excludeId };
    }

    return filter;
};

/**
 * Returns the first candidate that genuinely overlaps the proposal.
 *
 * O(k) over the candidates, each tested in O(1). Candidates arrive in start-time
 * order, so the first overlap found is the earliest one, which makes for the
 * clearest message to the user.
 *
 * @param   {object[]} candidates - Sessions returned by the window query.
 * @param   {number}   start      - Proposed start, in milliseconds.
 * @param   {number}   end        - Proposed end, in milliseconds.
 * @returns {object|null} The first overlapping session, or null.
 */
const findFirstOverlap = (candidates, start, end) => {
    for (const session of candidates) {
        if (intervalsOverlap(start, end, session.startTime, session.endTime)) {
            return session;
        }
    }
    return null;
};

/**
 * Formats a time as "YYYY-MM-DD HH:MM" in the server's local time zone, which
 * is the zone the times were entered in.
 */
const formatLocal = (value) => {
    const date = new Date(toTime(value));
    const pad = (number) => String(number).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} `
        + `${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

/**
 * Chooses a value from the incoming data, falling back to the stored record.
 *
 * An update may send only the fields that changed. The check has to reason
 * about the session as it will be after the update, not only about whatever the
 * request happened to include.
 */
const effectiveValue = (data, existing, field) => {
    if (Object.prototype.hasOwnProperty.call(data, field)) {
        return data[field];
    }
    return existing ? existing[field] : undefined;
};

/**
 * Creates the pre-save check that enforces the no-overlap invariant.
 *
 * Attached to the class-session entity through the controller factory's
 * preSaveChecks array, so the factory itself has no knowledge of scheduling.
 *
 * @param   {object} model - The ClassSession model.
 * @returns {Function} A pre-save check: (data, context) => failure or null.
 */
const createScheduleConflictCheck = (model) => async (data, context = {}) => {
    const existing = context.existing || null;

    const teacherId = effectiveValue(data, existing, 'teacherId');
    const start = toTime(effectiveValue(data, existing, 'startTime'));
    const end = toTime(effectiveValue(data, existing, 'endTime'));

    // Missing or malformed values, and durations outside the permitted range,
    // are left to schema validation, which reports them with a precise message.
    // Querying for conflicts on a session that cannot be saved anyway would be
    // wasted work, and could replace a clear validation error with a misleading
    // conflict error.
    if (!teacherId || Number.isNaN(start) || Number.isNaN(end)) {
        return null;
    }

    const duration = end - start;
    if (duration < MIN_SESSION_DURATION_MS || duration > MAX_SESSION_DURATION_MS) {
        return null;
    }

    // Efficiency: an update that leaves the teacher and both times unchanged
    // cannot introduce a conflict, since the stored session already satisfies
    // the invariant. Editing a room or a title then costs no query at all.
    if (existing
        && String(existing.teacherId) === String(teacherId)
        && toTime(existing.startTime) === start
        && toTime(existing.endTime) === end) {
        return null;
    }

    const filter = buildCandidateFilter({
        teacherId,
        start,
        end,
        excludeId: existing ? existing._id : null
    });

    // Sorting by startTime is free here: within one teacher's active sessions
    // the index is already in startTime order, so no in-memory sort stage runs.
    // Projecting three fields and returning plain objects keeps each of the k
    // candidates small.
    const candidates = await model.find(
        filter,
        'title startTime endTime',
        { sort: { startTime: 1 }, lean: true }
    );

    const clash = findFirstOverlap(candidates || [], start, end);

    if (!clash) {
        return null;
    }

    return {
        status: CONFLICT_STATUS,
        message: `This teacher is already booked for "${clash.title}" from `
            + `${formatLocal(clash.startTime)} to ${formatLocal(clash.endTime)}.`
    };
};

module.exports = {
    CONFLICT_STATUS,
    toTime,
    intervalsOverlap,
    candidateWindow,
    buildCandidateFilter,
    findFirstOverlap,
    createScheduleConflictCheck
};
