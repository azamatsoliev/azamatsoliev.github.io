/**
 * Attendance write policy.
 *
 * Teachers may record and edit attendance only for their own class sessions.
 *
 * Found while tracing how attendance reaches the billing reports. Teachers are
 * permitted to create attendance, and the record-level scope rule narrows which
 * existing records they can read and change, but a scope rule cannot apply to a
 * record that does not exist yet. So nothing checked that a new attendance record
 * belonged to one of the teacher's own sessions, and an update could move one of
 * their records onto a colleague's session.
 *
 * Attendance is not just a register here. Students are billed per lesson
 * attended, so a teacher able to mark a student present at another teacher's
 * lesson could add a charge to that student's balance. This check closes that
 * path on both create and update.
 *
 * Owners are unaffected; accountants cannot write attendance at all.
 *
 * @file    app_api/scheduling/attendancePolicy.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const { ROLES } = require('../config/roles');

/**
 * Creates the pre-save check for attendance writes.
 *
 * @param   {object} ClassSession - The ClassSession model.
 * @returns {Function} A pre-save check: (data, context) => failure or null.
 */
const createAttendanceWritePolicy = (ClassSession) => async (data, context = {}) => {
    const { user, existing } = context;

    if (!user || user.role !== ROLES.TEACHER) {
        return null;
    }

    // The session the record will belong to after this write: the one submitted,
    // or, for an update that leaves it unchanged, the one already stored.
    const sessionId = Object.prototype.hasOwnProperty.call(data, 'classSessionId')
        ? data.classSessionId
        : existing && existing.classSessionId;

    if (!sessionId) {
        // A missing session is reported by schema validation.
        return null;
    }

    if (!user.teacherId) {
        return { status: 403, message: 'Your account is not linked to a teacher record.' };
    }

    const ownSession = await ClassSession.findOne({
        _id: sessionId,
        teacherId: user.teacherId,
        active: true
    });

    if (!ownSession) {
        return { status: 403, message: 'Teachers may record attendance only for their own class sessions.' };
    }

    return null;
};

module.exports = { createAttendanceWritePolicy };
