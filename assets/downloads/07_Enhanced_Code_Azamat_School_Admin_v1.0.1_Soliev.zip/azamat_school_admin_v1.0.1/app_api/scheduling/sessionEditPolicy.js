/**
 * Class session edit policy.
 *
 * Teachers may reschedule their own class sessions, but may not reassign them
 * or reprice them. Those two changes belong to the owner.
 *
 * Found while tracing how updates reach the conflict check. The role model
 * allows a teacher to update their own sessions, and the field whitelist allows
 * teacherId and ratePerClass to be written, because the owner needs both. With
 * no rule distinguishing the two roles, a teacher could:
 *
 *   - change teacherId, moving a session onto another teacher's timetable,
 *     where it would then fall outside their own scope and into someone else's;
 *   - change ratePerClass, altering what students are charged, since the
 *     balance calculation reads the rate from the sessions attended.
 *
 * The rule compares against the stored value rather than refusing the field
 * outright. The administrative interface sends every field on each save, so an
 * unchanged teacherId or rate arriving in the request is normal and permitted.
 * Only an actual change is refused.
 *
 * @file    app_api/scheduling/sessionEditPolicy.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const { ROLES } = require('../config/roles');

/** Session fields a teacher may read but not change. */
const TEACHER_LOCKED_FIELDS = Object.freeze(['teacherId', 'ratePerClass']);

/**
 * Compares a submitted value with a stored one.
 *
 * Values are compared as strings because the same value can arrive in more
 * than one form: an identifier as a string or as an ObjectId, a rate as the
 * number 25 or the string "25".
 */
const sameValue = (submitted, stored) => String(submitted) === String(stored);

/**
 * Pre-save check refusing changes a teacher is not permitted to make.
 *
 * Applies only to updates. Teachers cannot create sessions at all, which the
 * role permissions already enforce.
 *
 * @param   {object} data    - Fields submitted, already filtered to writable ones.
 * @param   {object} context - Includes the verified user and the stored record.
 * @returns {Promise<object|null>} A 403 failure descriptor, or null.
 */
const restrictTeacherSessionEdits = async (data, context = {}) => {
    const { user, existing } = context;

    if (!user || user.role !== ROLES.TEACHER || !existing) {
        return null;
    }

    const attempted = TEACHER_LOCKED_FIELDS.filter((field) =>
        Object.prototype.hasOwnProperty.call(data, field)
        && !sameValue(data[field], existing[field]));

    if (attempted.length > 0) {
        return {
            status: 403,
            message: 'Teachers may change the title, time and room of their own sessions, '
                + 'but not the assigned teacher or the rate.'
        };
    }

    return null;
};

module.exports = { restrictTeacherSessionEdits, TEACHER_LOCKED_FIELDS };
