/**
 * User model.
 *
 * The account a person signs in with. Distinct from the Teacher record, which
 * holds the professional details of a member of teaching staff; a user account
 * may optionally be linked to one through teacherId.
 *
 * Two security changes were made to this model during the software design and
 * engineering enhancement:
 *
 *   1. A role field was added. Previously the application had a single kind of
 *      authenticated user and therefore only one permission state, signed in or
 *      signed out. The role is written into the signed token so that
 *      authorization decisions need no extra database read.
 *
 *   2. The password work factor was raised from 1,000 PBKDF2 iterations to
 *      210,000, matching current OWASP guidance for PBKDF2-HMAC-SHA512. The
 *      iteration count is now stored alongside each hash, which allows
 *      credentials created under the old factor to keep working while new and
 *      re-entered credentials use the stronger one.
 *
 * Changed for the final release: the minimum password length is defined here,
 * beside the hashing it protects, so every place that sets a password applies
 * the same rule.
 *
 * Changed in version 1.0.1: the iteration count no longer has a schema default.
 * Mongoose fills in defaults when it loads a document, so an account stored
 * before the count was recorded was read back as 210,000 and checked at the
 * wrong work factor: the account could not sign in, and its hash was never
 * upgraded. setPassword() always records the count, so new hashes are
 * unaffected.
 *
 * @file    app_api/models/user.js
 * @author  Azamat Soliev
 * @version 4.1
 * @date    October 2026
 */

const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { ROLES, DEFAULT_ROLE } = require('../config/roles');

/** Work factor applied to newly created passwords. */
const PBKDF2_ITERATIONS = 210000;

/** Work factor assumed for hashes stored before the iteration count was recorded. */
const LEGACY_PBKDF2_ITERATIONS = 1000;

/** Shortest password accepted when an account is created. */
const MIN_PASSWORD_LENGTH = 8;

const KEY_LENGTH = 64;
const DIGEST = 'sha512';

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: true,
        lowercase: true,
        trim: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },

    /**
     * Permission level for this account.
     *
     * Constrained by enum so an unrecognized value cannot reach the database.
     * Defaults to the least privileged role; only an owner sets any other,
     * through the account administration endpoints.
     */
    role: {
        type: String,
        required: true,
        enum: Object.values(ROLES),
        default: DEFAULT_ROLE,
        index: true
    },

    /**
     * Optional link to this account's Teacher record.
     *
     * Present for teaching staff, absent for administrative accounts. Carried
     * in the token so that a teacher's requests can be narrowed to their own
     * class sessions without an additional lookup on every request.
     */
    teacherId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'teachers',
        default: null
    },

    hash: String,
    salt: String,

    /**
     * Iterations used to produce the stored hash.
     *
     * Deliberately has no default: a missing value marks a hash created before
     * the count was recorded, which must be verified at the legacy factor.
     * setPassword() always sets it.
     */
    iterations: { type: Number }
}, { timestamps: true });

/**
 * Hashes and stores a password using a freshly generated salt.
 *
 * The iteration count is recorded with the hash so that the work factor can be
 * raised again in future without invalidating credentials already in use.
 *
 * @param {string} password - The plain-text password. Never stored.
 */
userSchema.methods.setPassword = function (password) {
    this.salt = crypto.randomBytes(16).toString('hex');
    this.iterations = PBKDF2_ITERATIONS;
    this.hash = crypto
        .pbkdf2Sync(password, this.salt, this.iterations, KEY_LENGTH, DIGEST)
        .toString('hex');
};

/**
 * Verifies a password against the stored hash.
 *
 * Records written before the iteration count was tracked are verified at the
 * legacy work factor, so raising the factor does not lock anyone out.
 *
 * Comparison uses crypto.timingSafeEqual rather than string equality. A plain
 * comparison returns as soon as it finds a differing character, and the time
 * that takes can reveal how much of a candidate hash was correct.
 *
 * @param   {string} password - The plain-text password supplied at sign-in.
 * @returns {boolean} True when the password matches.
 */
userSchema.methods.validPassword = function (password) {
    if (!this.hash || !this.salt) {
        return false;
    }

    const iterations = this.iterations || LEGACY_PBKDF2_ITERATIONS;
    const candidate = crypto.pbkdf2Sync(password, this.salt, iterations, KEY_LENGTH, DIGEST);
    const stored = Buffer.from(this.hash, 'hex');

    if (candidate.length !== stored.length) {
        return false;
    }

    return crypto.timingSafeEqual(candidate, stored);
};

/**
 * Reports whether the stored hash was produced at an out-of-date work factor.
 *
 * Used at sign-in to transparently upgrade a credential during the brief
 * moment the plain-text password is available.
 *
 * @returns {boolean} True when the hash should be regenerated.
 */
userSchema.methods.needsRehash = function () {
    return (this.iterations || LEGACY_PBKDF2_ITERATIONS) < PBKDF2_ITERATIONS;
};

/**
 * Issues a signed JSON Web Token for this account.
 *
 * The role and teacherId are included in the payload because every
 * authorization decision needs them. Reading them from the verified token
 * avoids a database round trip on each request, and the signature prevents a
 * client from altering either value.
 *
 * @returns {string} A signed token valid for one hour.
 */
userSchema.methods.generateJWT = function () {
    return jwt.sign(
        {
            id: this.id,
            email: this.email,
            name: this.name,
            role: this.role,
            teacherId: this.teacherId ? this.teacherId.toString() : null
        },
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
    );
};

const User = mongoose.model('users', userSchema);

module.exports = User;
module.exports.PBKDF2_ITERATIONS = PBKDF2_ITERATIONS;
module.exports.LEGACY_PBKDF2_ITERATIONS = LEGACY_PBKDF2_ITERATIONS;
module.exports.MIN_PASSWORD_LENGTH = MIN_PASSWORD_LENGTH;
