/**
 * Student model.
 *
 * Represents a person enrolled at the school. Attendance and payment records
 * reference a student by identifier rather than embedding a copy of it, so a
 * correction here propagates automatically to every related record.
 *
 * @file    app_api/models/student.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    firstName: { type: String, required: true, trim: true },
    lastName: { type: String, required: true, trim: true, index: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    phone: { type: String, trim: true },
    enrolledOn: { type: Date, required: true, default: Date.now },

    // Soft-delete flag. Withdrawing a student clears this rather than removing
    // the document, so their attendance and payment history stays intact.
    active: { type: Boolean, required: true, default: true, index: true }
}, { timestamps: true });

/** Convenience accessor used by list views and reports. */
studentSchema.virtual('fullName').get(function () {
    return `${this.firstName} ${this.lastName}`;
});

studentSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('students', studentSchema);
