/**
 * Database connection.
 *
 * Registers every schema, and provides the functions that open the connection
 * and close it cleanly when the server stops.
 *
 * Changed during the databases enhancement:
 *   - The connection string comes from app_api/config/database.js, which
 *     accepts a full MONGODB_URI so the application can connect to a database
 *     that requires a user name and password.
 *   - Connection strings are logged with the password hidden, since a string
 *     that can carry credentials must never be printed as-is.
 *   - A failed initial connection is reported as a clear message instead of an
 *     unhandled promise rejection, which terminated the process with a stack
 *     trace when MongoDB was not running.
 *
 * Changed for the final release:
 *   - Loading this module no longer opens a connection. The server calls
 *     connectDatabase() when it starts, so tests can load the application
 *     without a database and without leaving a connection attempt running.
 *   - Connection errors are logged by message only. The full error object
 *     includes internal driver details that do not belong in a log.
 *   - Shutdown now waits for the connection to close. Mongoose no longer
 *     accepts a callback in close(), so the previous shutdown message was never
 *     printed and the process exited while the connection was still open.
 *
 * @file    app_api/models/db.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const mongoose = require('mongoose');
const readLine = require('readline');
const { resolveDbUri, redactUri } = require('../config/database');

// Register every schema, so any module can look a model up by name.
require('./user');
require('./student');
require('./teacher');
require('./classSession');
require('./payment');
require('./attendance');

/**
 * Opens the connection to MongoDB and logs connection events.
 *
 * A failed first attempt is reported plainly rather than crashing the process,
 * so the API can still answer its health check and explain what is wrong.
 *
 * @param   {object} [env=process.env] - Environment variables.
 * @returns {Promise<void>} Resolves once the attempt has finished, either way.
 */
const connectDatabase = async (env = process.env) => {
    const dbURI = resolveDbUri(env);
    const safeURI = redactUri(dbURI);

    mongoose.connection.on('connected', () => {
        console.log(`MongoDB connected: ${safeURI}`);
    });

    mongoose.connection.on('error', (error) => {
        console.error(`MongoDB connection error: ${error.message}`);
    });

    mongoose.connection.on('disconnected', () => {
        console.log('MongoDB disconnected');
    });

    try {
        await mongoose.connect(dbURI);
    } catch (error) {
        console.error(`Could not connect to MongoDB at ${safeURI}: ${error.message}`);
        console.error('Check that MongoDB is running, then restart the API.');
    }
};

/**
 * Closes the connection, then exits.
 *
 * @param {string} reason - Shown in the log so the cause of the stop is visible.
 */
const shutDown = async (reason) => {
    try {
        await mongoose.connection.close();
        console.log(`MongoDB connection closed (${reason}).`);
    } catch (error) {
        console.error(`Error while closing the MongoDB connection: ${error.message}`);
    } finally {
        process.exit(0);
    }
};

/**
 * Closes the database connection cleanly when the server is stopped.
 *
 * Windows does not deliver SIGINT to Node the way other systems do, so on that
 * platform Ctrl+C is captured through the terminal and re-emitted.
 */
const registerShutdownHandlers = () => {
    if (process.platform === 'win32') {
        const rl = readLine.createInterface({ input: process.stdin, output: process.stdout });
        rl.on('SIGINT', () => process.emit('SIGINT'));
    }

    process.once('SIGINT', () => shutDown('stopped with Ctrl+C'));
    process.once('SIGTERM', () => shutDown('stopped by the system'));
};

module.exports = { mongoose, connectDatabase, registerShutdownHandlers };
