/**
 * Payment model.
 *
 * A single tuition payment made by a student. Payments reference the student
 * by identifier rather than being embedded inside the student document.
 *
 * Referencing is the correct choice here because payment records accumulate
 * continuously for the lifetime of an enrollment, are queried independently of
 * the student record when producing financial reports, and would otherwise
 * grow an unbounded array inside a document that is read on every roster view.
 *
 * @file    app_api/models/payment.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const mongoose = require('mongoose');
const { wholeCentsValidator } = require('../utils/money');

const paymentSchema = new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'students', required: true, index: true },

    amount: { type: Number, required: true, min: 0, validate: wholeCentsValidator },
    paidOn: { type: Date, required: true, default: Date.now, index: true },

    method: {
        type: String,
        required: true,
        enum: ['cash', 'card', 'transfer'],
        default: 'cash'
    },

    reference: { type: String, trim: true },

    // Payments are never removed outright. Reversing one clears this flag so
    // that the financial history remains auditable.
    active: { type: Boolean, required: true, default: true, index: true }
}, { timestamps: true });

module.exports = mongoose.model('payments', paymentSchema);
