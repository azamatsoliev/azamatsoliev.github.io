/**
 * Teacher model.
 *
 * Holds the professional record for a member of teaching staff. This is kept
 * separate from the User account that signs in: a teacher may exist in the
 * school's records before they are given system access, and an account may be
 * deactivated without erasing the teaching history attached to it.
 *
 * @file    app_api/models/teacher.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const mongoose = require('mongoose');

const teacherSchema = new mongoose.Schema({
    firstName: { type: String, required: true, trim: true },
    lastName: { type: String, required: true, trim: true, index: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },

    // Languages or subjects this teacher is qualified to deliver.
    subjects: { type: [String], default: [] },

    hiredOn: { type: Date, required: true, default: Date.now },
    active: { type: Boolean, required: true, default: true, index: true }
}, { timestamps: true });

teacherSchema.virtual('fullName').get(function () {
    return `${this.firstName} ${this.lastName}`;
});

teacherSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('teachers', teacherSchema);
