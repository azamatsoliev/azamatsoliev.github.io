/**
 * Attendance model.
 *
 * Records whether one student attended one class session. The pairing is
 * unique: a student has exactly one attendance record per session, enforced by
 * a compound unique index rather than by application logic, so a duplicate
 * cannot be created by two concurrent requests.
 *
 * Like payments, attendance references its student and session by identifier.
 * These records are numerous, are created continuously, and are queried
 * independently of the documents they point at.
 *
 * @file    app_api/models/attendance.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'students', required: true, index: true },
    classSessionId: { type: mongoose.Schema.Types.ObjectId, ref: 'classsessions', required: true, index: true },

    present: { type: Boolean, required: true, default: false },
    recordedOn: { type: Date, required: true, default: Date.now },
    note: { type: String, trim: true },

    active: { type: Boolean, required: true, default: true, index: true }
}, { timestamps: true });

// One attendance record per student per session.
attendanceSchema.index({ studentId: 1, classSessionId: 1 }, { unique: true });

module.exports = mongoose.model('attendance', attendanceSchema);
