/**
 * Owner bootstrap script.
 *
 * Creates or promotes the first owner account.
 *
 * Only an owner can create staff accounts or change a role, which leaves a
 * deliberate gap: a fresh installation has no owner and therefore no way to
 * create one through the API. That gap is closed here rather than by a rule
 * such as "the first account to register becomes owner", which would hand
 * control of a new school to whoever reached the sign-up page first.
 *
 * Running this requires shell access to the server, so the privilege can only
 * be granted by someone who already administers the machine.
 *
 * Usage:
 *   npm run create-owner -- <email> "<name>" <password>
 *
 * Changed for the final release: the password must meet the same minimum
 * length as every other account, and the usage text shows the npm script.
 *
 * @file    app_api/models/seedOwner.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

require('dotenv').config({ quiet: true });
const mongoose = require('mongoose');
const { ROLES } = require('../config/roles');
const { resolveDbUri, redactUri } = require('../config/database');
const User = require('./user');

const dbURI = resolveDbUri();

const [, , email, name, password] = process.argv;

if (!email || !name || !password) {
    console.error('Usage: npm run create-owner -- <email> "<name>" <password>');
    process.exit(1);
}

if (password.length < User.MIN_PASSWORD_LENGTH) {
    console.error(`The password must be at least ${User.MIN_PASSWORD_LENGTH} characters.`);
    process.exit(1);
}

const run = async () => {
    await mongoose.connect(dbURI);

    let user = await User.findOne({ email: email.toLowerCase().trim() });

    if (user) {
        user.role = ROLES.OWNER;
        user.teacherId = null;
        await user.save();
        console.log(`Existing account ${user.email} promoted to owner in ${redactUri(dbURI)}.`);
    } else {
        user = new User({ name, email, role: ROLES.OWNER });
        user.setPassword(password);
        await user.save();
        console.log(`Owner account created for ${user.email} in ${redactUri(dbURI)}.`);
    }

    await mongoose.connection.close();
};

run().catch(async (error) => {
    console.error('Failed to create owner account:', error.message);
    await mongoose.connection.close();
    process.exit(1);
});
