/**
 * ClassSession model.
 *
 * A single scheduled lesson taught by one teacher. Named ClassSession rather
 * than Class because "class" is a reserved word in JavaScript and would make
 * the surrounding code harder to read.
 *
 * The compound index on { teacherId, active, startTime } serves the bounded
 * range query used for scheduling-conflict detection. It is declared here
 * because index definition belongs with the schema. See the note above the
 * index for why the fields are in this order.
 *
 * @file    app_api/models/classSession.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const mongoose = require('mongoose');
const { wholeCentsValidator } = require('../utils/money');

/**
 * Longest permitted lesson, in milliseconds.
 *
 * This is a deliberate constraint, not an arbitrary limit. Bounding the
 * duration is what allows a later conflict check to search a fixed-width time
 * window instead of a teacher's entire history. Enforcing it at write time is
 * what makes that guarantee hold.
 */
const MAX_SESSION_DURATION_MS = 4 * 60 * 60 * 1000;

/**
 * Shortest permitted lesson, in milliseconds.
 *
 * The maximum duration bounds where an overlapping session can start. This
 * minimum bounds how many sessions can start there. Because the conflict check
 * guarantees that one teacher's active sessions never overlap, sessions in any
 * time window are laid end to end, and each occupies at least this long. The
 * number of candidates the conflict query can ever return is therefore capped
 * by the window's length divided by this value, which turns "the candidate set
 * is small in practice" into a guarantee. The derivation is in
 * app_api/scheduling/conflictDetection.js.
 *
 * Fifteen minutes is below any realistic lesson, so the rule costs the school
 * nothing while making the performance claim provable.
 */
const MIN_SESSION_DURATION_MS = 15 * 60 * 1000;

const classSessionSchema = new mongoose.Schema({
    title: { type: String, required: true, trim: true },
    teacherId: { type: mongoose.Schema.Types.ObjectId, ref: 'teachers', required: true },

    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },

    // Charge for attending this session. Stored per session rather than per
    // student so that different lesson types can be priced differently.
    ratePerClass: { type: Number, required: true, min: 0, validate: wholeCentsValidator },

    room: { type: String, trim: true },
    active: { type: Boolean, required: true, default: true, index: true }
}, { timestamps: true });

/**
 * Index serving the scheduling-conflict query.
 *
 * Field order follows the equality-sort-range rule for compound indexes:
 * fields matched by equality come first, and the field queried as a range
 * comes last. The conflict query matches teacherId and active exactly and
 * startTime as a range, so the index can seek straight to one teacher's active
 * sessions and then walk only the requested time window.
 *
 * The earlier design indexed { teacherId, startTime } and filtered active
 * afterwards. That left withdrawn sessions inside the index range, and because
 * the no-overlap rule applies only to active sessions, withdrawn ones could
 * accumulate in a single time window without limit. Placing active in the index
 * keeps them out of the range the query walks, so the candidate bound holds.
 */
classSessionSchema.index({ teacherId: 1, active: 1, startTime: 1 });

/**
 * Index serving the period reports, which select every active session in a
 * month regardless of teacher.
 *
 * The conflict index above cannot serve that query. A compound index can only
 * be used from its leading field, and its leading field is teacherId, which a
 * whole-school report does not filter on. Without this index, a monthly report
 * would scan every session the school has ever run. With it, the database seeks
 * straight to the month in O(log n) and reads only that month's sessions.
 *
 * Each index costs some write time and storage, so one is added only where a
 * real query needs it.
 */
classSessionSchema.index({ active: 1, startTime: 1 });

/**
 * Rejects a session that ends before it starts or runs longer than the
 * permitted maximum. Validation lives on the schema so that every write path
 * is covered, including any added later.
 *
 * Problems are reported through Document.prototype.invalidate rather than by
 * throwing. invalidate attaches the message to the offending field and produces
 * a proper ValidationError, which the controller factory answers with HTTP 400
 * and a readable message. Throwing a plain error would surface as an
 * unexplained HTTP 500 instead.
 *
 * The hook takes no callback argument. Document middleware in current Mongoose
 * versions is promise-based, and a hook declared with a next parameter receives
 * undefined for it.
 */
classSessionSchema.pre('validate', function () {
    if (!this.startTime || !this.endTime) {
        return;
    }

    const durationMs = this.endTime.getTime() - this.startTime.getTime();

    if (durationMs <= 0) {
        this.invalidate('endTime', 'The end time must be later than the start time.');
        return;
    }

    if (durationMs < MIN_SESSION_DURATION_MS) {
        this.invalidate(
            'endTime',
            `A class session must last at least ${MIN_SESSION_DURATION_MS / 60000} minutes.`
        );
        return;
    }

    if (durationMs > MAX_SESSION_DURATION_MS) {
        this.invalidate(
            'endTime',
            `A class session may not exceed ${MAX_SESSION_DURATION_MS / 3600000} hours.`
        );
    }
});

/**
 * Readable name for a session, shown wherever one must be picked from a list.
 *
 * A weekly class produces many sessions with the same title, so a list showing
 * titles alone offers dozens of identical "Beginner English A1" entries with no
 * way to tell them apart. Adding the date and time in the school's local time
 * makes each one identifiable.
 */
classSessionSchema.virtual('label').get(function () {
    if (!this.startTime) {
        return this.title;
    }
    const start = new Date(this.startTime);
    const pad = (n) => String(n).padStart(2, '0');
    return `${this.title} · ${start.getFullYear()}-${pad(start.getMonth() + 1)}-${pad(start.getDate())} `
        + `${pad(start.getHours())}:${pad(start.getMinutes())}`;
});

classSessionSchema.set('toJSON', { virtuals: true });

const ClassSession = mongoose.model('classsessions', classSessionSchema);

module.exports = ClassSession;
module.exports.MAX_SESSION_DURATION_MS = MAX_SESSION_DURATION_MS;
module.exports.MIN_SESSION_DURATION_MS = MIN_SESSION_DURATION_MS;
