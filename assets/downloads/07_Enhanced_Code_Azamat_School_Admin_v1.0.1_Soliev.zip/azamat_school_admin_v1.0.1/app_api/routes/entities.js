/**
 * Entity routes.
 *
 * Builds a complete REST route set for every entity described in the entity
 * configuration. One loop replaces what would otherwise be five separate route
 * files repeating the same five route definitions.
 *
 * Every route is authenticated. Role and record-level checks are applied by the
 * handlers themselves, so a route cannot be exposed without them.
 *
 * Routes produced for each entity:
 *   GET    /api/<entity>        list records visible to the caller
 *   GET    /api/<entity>/:id    read one record
 *   POST   /api/<entity>        create a record
 *   PUT    /api/<entity>/:id    update a record
 *   DELETE /api/<entity>/:id    withdraw a record
 *
 * @file    app_api/routes/entities.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const express = require('express');
const createCrudController = require('../controllers/crudControllerFactory');
const { authenticate } = require('../middleware/authenticate');
const ENTITIES = require('../config/entities');

const router = express.Router();

Object.entries(ENTITIES).forEach(([path, config]) => {
    const controller = createCrudController(config.model, config);

    // Authentication is attached to each entity route individually with
    // .all(), rather than to the whole router with router.use(). This router is
    // mounted at the API root, so a router-wide check would also intercept
    // requests for paths it does not own. That is exactly what happened in the
    // first version: a public route mounted alongside it began demanding a
    // login. The regression test in app_api/tests/routeScoping.test.js keeps
    // the public health check and sign-in reachable.
    router.route(`/${path}`)
        .all(authenticate)
        .get(controller.list)
        .post(controller.create);

    router.route(`/${path}/:id`)
        .all(authenticate)
        .get(controller.getOne)
        .put(controller.update)
        .delete(controller.remove);
});

module.exports = router;
