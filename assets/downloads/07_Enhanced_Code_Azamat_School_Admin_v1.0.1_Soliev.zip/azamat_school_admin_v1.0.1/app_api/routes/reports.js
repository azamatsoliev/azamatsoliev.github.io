/**
 * Report routes.
 *
 * Each report is available only to the roles whose decisions it supports:
 *
 *   Balances, revenue and its export   accountant, and owner by inheritance
 *   Class summary                      owner
 *   Attendance sheet                   teacher, and owner by inheritance
 *
 * GET  /api/reports/balances
 * GET  /api/reports/revenue?month=YYYY-MM
 * GET  /api/reports/revenue.csv?month=YYYY-MM
 * GET  /api/reports/revenue-by-month?year=YYYY
 * GET  /api/reports/classes?month=YYYY-MM
 * GET  /api/reports/attendance-sheet?month=YYYY-MM[&teacherId=...]   (owner names the teacher)
 *
 * @file    app_api/routes/reports.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const express = require('express');
const mongoose = require('mongoose');

const { authenticate, requireRole } = require('../middleware/authenticate');
const { ROLES } = require('../config/roles');
const { createReportService } = require('../reports/reportService');
const { createReportsController } = require('../controllers/reports');

const Student = require('../models/student');
const ClassSession = require('../models/classSession');
const Payment = require('../models/payment');
const Attendance = require('../models/attendance');

const service = createReportService({
    models: { Student, ClassSession, Payment, Attendance },
    castId: (id) => new mongoose.Types.ObjectId(String(id))
});
const reports = createReportsController(service);

const router = express.Router();

// Owner passes these checks too, because the owner role inherits both.
const financeRoles = [authenticate, requireRole(ROLES.ACCOUNTANT)];
const teachingRoles = [authenticate, requireRole(ROLES.TEACHER)];
const ownerOnly = [authenticate, requireRole(ROLES.OWNER)];

router.get('/balances', ...financeRoles, reports.balances);
router.get('/revenue', ...financeRoles, reports.revenue);
router.get('/revenue.csv', ...financeRoles, reports.revenueCsv);
router.get('/revenue-by-month', ...financeRoles, reports.revenueByMonth);
router.get('/classes', ...ownerOnly, reports.classes);
router.get('/attendance-sheet', ...teachingRoles, reports.attendanceSheet);

module.exports = router;
