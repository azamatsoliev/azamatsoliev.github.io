/**
 * API routes.
 *
 * The complete API surface: health check, sign-in, account administration,
 * reports, and the five school management entities.
 *
 * The JWT verification function that previously lived in this file moved to
 * app_api/middleware/authenticate.js during the software design and
 * engineering enhancement. Two defects identified in the code review were
 * corrected in the process: an unreachable branch that could never execute,
 * and an incorrect HTTP 501 response where 401 was required.
 *
 * Changed for the final release:
 *   - The public trip endpoints inherited from the original travel application
 *     were removed, along with public self-registration. The only routes left
 *     open without a token are the health check and sign-in.
 *   - Sign-in is rate limited.
 *   - Staff accounts are created by an owner through POST /api/users.
 *
 * @file    app_api/routes/index.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const express = require('express');
const mongoose = require('mongoose');

const { authenticate, requireRole } = require('../middleware/authenticate');
const { createLoginLimiter } = require('../middleware/rateLimit');
const { ROLES } = require('../config/roles');

const authController = require('../controllers/authentication');
const usersController = require('../controllers/users');
const entityRoutes = require('./entities');
const reportRoutes = require('./reports');

const router = express.Router();

// ---------------------------------------------------------------------------
// Health check - public
//
// Lets a person, or an automated check, confirm the API is running and can
// reach its database. Reports nothing beyond those two facts.
// ---------------------------------------------------------------------------

router.get('/health', (req, res) => {
    const connected = mongoose.connection.readyState === 1;
    res.status(connected ? 200 : 503).json({
        status: connected ? 'ok' : 'degraded',
        database: connected ? 'connected' : 'disconnected'
    });
});

// ---------------------------------------------------------------------------
// Sign-in - public, rate limited
// ---------------------------------------------------------------------------

router.post('/login', createLoginLimiter(), authController.login);

// ---------------------------------------------------------------------------
// Account administration - owner only
// ---------------------------------------------------------------------------

router.route('/users')
    .all(authenticate, requireRole(ROLES.OWNER))
    .get(usersController.listUsers)
    .post(usersController.createUser);

router.route('/users/:id/role')
    .put(authenticate, requireRole(ROLES.OWNER), usersController.setUserRole);

// ---------------------------------------------------------------------------
// Reports - each restricted to the roles whose decisions it supports
// ---------------------------------------------------------------------------

router.use('/reports', reportRoutes);

// ---------------------------------------------------------------------------
// School management entities
//
// Students, teachers, class sessions, payments and attendance all receive a
// full route set from the entity router, which builds them from configuration.
// ---------------------------------------------------------------------------

router.use('/', entityRoutes);

module.exports = router;
