/**
 * Sign-in strategy.
 *
 * Checks an email address and password against the stored account, using
 * Passport's local strategy. The controller in
 * app_api/controllers/authentication.js decides what the caller is told.
 *
 * Changed for the final release: any error raised while looking up the account
 * is now handed back to Passport instead of escaping the function. The lookup is
 * asynchronous, and Passport does not watch the promise it returns, so an error
 * there became an unhandled rejection, which stops a Node process. In practice,
 * one sign-in attempt made while MongoDB was unreachable shut the whole API
 * down. The error now reaches the controller, which answers 503 and keeps
 * serving.
 *
 * The reasons for refusal stay identical whether the account does not exist or
 * the password is wrong, so the response cannot reveal which addresses are
 * registered.
 *
 * @file    app_api/config/passport.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');

const User = mongoose.model('users');

/** The one message used for every refused credential. */
const REFUSED = { message: 'Email or password is incorrect.' };

/**
 * Verifies one set of credentials.
 *
 * Passport's local strategy only passes plain strings here: a value supplied as
 * an object or array is treated as missing before this function is called, so
 * an operator such as { "$gt": "" } can never reach the database query.
 *
 * @param {string}   email    - Address supplied at sign-in.
 * @param {string}   password - Password supplied at sign-in.
 * @param {Function} done     - Passport callback.
 */
const verifyCredentials = async (email, password, done) => {
    try {
        const user = await User.findOne({ email: String(email).toLowerCase().trim() }).exec();

        if (!user || !user.validPassword(password)) {
            return done(null, false, REFUSED);
        }

        return done(null, user);
    } catch (error) {
        return done(error);
    }
};

passport.use(new LocalStrategy({ usernameField: 'email' }, verifyCredentials));

module.exports = { verifyCredentials };
