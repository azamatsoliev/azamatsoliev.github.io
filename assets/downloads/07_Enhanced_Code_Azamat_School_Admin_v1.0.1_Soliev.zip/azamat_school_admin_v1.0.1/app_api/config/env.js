/**
 * Environment checks.
 *
 * Confirms that the settings the server cannot run safely without are present
 * before it starts listening, and explains what to do when one is missing.
 *
 * The token signing secret is the one setting that must never fall back to a
 * default. Without it, sign-in fails at the first request with an error that
 * gives no hint of the cause; with a short or guessable value, anyone who can
 * guess it can forge a token for any role, including owner. Refusing to start
 * turns both into a clear message at startup instead.
 *
 * @file    app_api/config/env.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

/** Shortest signing secret accepted. 32 characters of random text resist guessing. */
const MIN_SECRET_LENGTH = 32;

/** Command that prints a suitable secret, shown whenever the secret is rejected. */
const SECRET_HINT =
    'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"';

/**
 * Lists every problem with the current settings.
 *
 * Returns all problems at once rather than stopping at the first, so a
 * misconfigured installation can be fixed in a single pass.
 *
 * @param   {object} [env=process.env] - Environment variables.
 * @returns {string[]} Human-readable problems; empty when the settings are usable.
 */
const validateEnvironment = (env = process.env) => {
    const problems = [];
    const secret = typeof env.JWT_SECRET === 'string' ? env.JWT_SECRET.trim() : '';

    if (secret === '') {
        problems.push(`JWT_SECRET is not set. Add it to the .env file in the project root. ${SECRET_HINT}`);
    } else if (secret.length < MIN_SECRET_LENGTH) {
        problems.push(
            `JWT_SECRET is too short (${secret.length} characters; at least ${MIN_SECRET_LENGTH} required). ${SECRET_HINT}`
        );
    }

    if (env.PORT !== undefined && env.PORT !== '' && !/^\d+$/.test(String(env.PORT))) {
        problems.push(`PORT must be a number, but it is "${env.PORT}".`);
    }

    return problems;
};

module.exports = { MIN_SECRET_LENGTH, SECRET_HINT, validateEnvironment };
