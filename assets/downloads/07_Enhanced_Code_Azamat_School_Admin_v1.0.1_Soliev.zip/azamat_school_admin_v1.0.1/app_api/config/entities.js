/**
 * Entity configuration.
 *
 * Describes each managed entity to the generic controller factory: which roles
 * may perform which action, which records each role may act on, which fields a
 * client may write, and whether deletion preserves the record.
 *
 * Adding a sixth entity to this platform means adding a schema and one entry
 * here. No controller or route file needs to be written.
 *
 * Scope rules follow the plan agreed in the code review:
 *   - An owner sees everything, because they run the school.
 *   - An accountant sees financial records and the students they relate to.
 *   - A teacher sees only their own class sessions and the attendance for them.
 *
 * Changed for the final release: a teacher may now list students, receiving
 * their names only, so attendance can be recorded from the interface. Before
 * this, the student list was refused to teachers, which left the attendance
 * form's student choice empty and the teacher's main daily task impossible
 * without the owner's help. Teachers may likewise read teachers' names, so
 * their own lessons show a teacher's name instead of a database identifier.
 *
 * @file    app_api/config/entities.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const { ROLES } = require('./roles');

const Student = require('../models/student');
const Teacher = require('../models/teacher');
const ClassSession = require('../models/classSession');
const Payment = require('../models/payment');
const Attendance = require('../models/attendance');

const { createScheduleConflictCheck } = require('../scheduling/conflictDetection');
const { restrictTeacherSessionEdits } = require('../scheduling/sessionEditPolicy');
const { createAttendanceWritePolicy } = require('../scheduling/attendancePolicy');

/**
 * Narrows class sessions to those taught by the requesting teacher.
 *
 * Returning an impossible filter for a teacher account with no linked Teacher
 * record is deliberate. Returning an empty filter would widen the query to
 * every record, which is the opposite of what a failed scope lookup should do.
 *
 * @param   {object} user - Verified token payload.
 * @returns {object} A Mongoose filter fragment.
 */
const ownClassSessions = (user) => {
    if (user.role !== ROLES.TEACHER) {
        return {};
    }
    return { teacherId: user.teacherId || null };
};

/**
 * Narrows attendance records to sessions taught by the requesting teacher.
 *
 * Attendance has no teacher field of its own, so the teacher's sessions are
 * resolved first and the records restricted to those identifiers. Storing a
 * duplicate teacher reference on each attendance record would avoid this
 * lookup, but it would also drift out of step if a session were reassigned.
 * The extra query is the cheaper mistake.
 *
 * @param   {object} user - Verified token payload.
 * @returns {Promise<object>} A Mongoose filter fragment.
 */
const ownAttendance = async (user) => {
    if (user.role !== ROLES.TEACHER) {
        return {};
    }

    const sessions = await ClassSession
        .find({ teacherId: user.teacherId || null, active: true })
        .select('_id')
        .lean();

    return { classSessionId: { $in: sessions.map((session) => session._id) } };
};

/**
 * Confirms that a referenced record exists and is active before writing.
 *
 * Mongoose validates that a reference is a well-formed identifier but not that
 * it points at anything real. Without this check, attendance could be recorded
 * against a session that was never created or has been withdrawn.
 *
 * @param   {object} model - The model the reference points at.
 * @param   {string} field - The referencing field on the incoming data.
 * @param   {string} label - Human-readable name used in the error message.
 * @returns {Function} A pre-save check for the controller factory.
 */
const referenceMustExist = (model, field, label) => async (data) => {
    if (!Object.prototype.hasOwnProperty.call(data, field)) {
        return null;
    }

    const referenced = await model.findOne({ _id: data[field], active: true });

    if (!referenced) {
        return { status: 400, message: `The ${label} referenced does not exist or is inactive.` };
    }

    return null;
};

/**
 * Identifies whose schedule a class-session write affects.
 *
 * Writes to the same teacher's schedule are serialized under this key, so the
 * conflict check and the save happen as one step. For a reassignment the key is
 * the new teacher, whose schedule is the one that could gain an overlap.
 *
 * @param   {object} data    - Incoming fields.
 * @param   {object} context - Request context, including any stored record.
 * @returns {string|null} The teacher identifier, or null when none is known.
 */
const sessionTeacherKey = (data, context) => {
    const teacherId = Object.prototype.hasOwnProperty.call(data, 'teacherId')
        ? data.teacherId
        : context.existing && context.existing.teacherId;
    return teacherId ? `teacher:${teacherId}` : null;
};

/**
 * The managed entities, keyed by the path segment used in their API route.
 */
const ENTITIES = Object.freeze({
    students: {
        name: 'students',
        model: Student,
        permissions: {
            // Teachers may read the student list so they can record attendance,
            // but the projection below limits them to names.
            list: [ROLES.OWNER, ROLES.ACCOUNTANT, ROLES.TEACHER],
            create: [ROLES.OWNER],
            update: [ROLES.OWNER],
            remove: [ROLES.OWNER]
        },
        writableFields: ['firstName', 'lastName', 'email', 'phone', 'enrolledOn'],
        softDelete: true,

        // Least privilege at field level: a teacher needs a student's name to
        // mark attendance, and nothing else. Email, phone and enrollment date
        // are never sent to a teacher account. Matched on the exact role, so
        // an owner, who inherits teacher permissions, still sees every field.
        projectionByRole: {
            [ROLES.TEACHER]: 'firstName lastName'
        }
    },

    teachers: {
        name: 'teachers',
        model: Teacher,
        permissions: {
            // Teachers may read the teacher list, names only, so the Teacher
            // column of their own lessons shows a name rather than an identifier.
            list: [ROLES.OWNER, ROLES.TEACHER],
            create: [ROLES.OWNER],
            update: [ROLES.OWNER],
            remove: [ROLES.OWNER]
        },
        writableFields: ['firstName', 'lastName', 'email', 'subjects', 'hiredOn'],
        softDelete: true,
        projectionByRole: {
            [ROLES.TEACHER]: 'firstName lastName'
        }
    },

    classsessions: {
        name: 'classsessions',
        model: ClassSession,
        permissions: {
            list: [ROLES.OWNER, ROLES.TEACHER],
            create: [ROLES.OWNER],
            update: [ROLES.OWNER, ROLES.TEACHER],
            remove: [ROLES.OWNER]
        },
        writableFields: ['title', 'teacherId', 'startTime', 'endTime', 'ratePerClass', 'room'],
        scopeRule: ownClassSessions,
        softDelete: true,

        // Ordered cheapest first. The edit policy needs no database access, so
        // a refused change is rejected before any query runs. The conflict check
        // runs last, once the referenced teacher is known to exist.
        preSaveChecks: [
            restrictTeacherSessionEdits,
            referenceMustExist(Teacher, 'teacherId', 'teacher'),
            createScheduleConflictCheck(ClassSession)
        ],

        // Serializes writes per teacher so concurrent bookings cannot both
        // pass the conflict check. See app_api/utils/keyedMutex.js.
        lockKey: sessionTeacherKey
    },

    payments: {
        name: 'payments',
        model: Payment,
        permissions: {
            list: [ROLES.OWNER, ROLES.ACCOUNTANT],
            create: [ROLES.OWNER, ROLES.ACCOUNTANT],
            update: [ROLES.OWNER, ROLES.ACCOUNTANT],
            remove: [ROLES.OWNER]
        },
        writableFields: ['studentId', 'amount', 'paidOn', 'method', 'reference'],
        softDelete: true,
        preSaveChecks: [referenceMustExist(Student, 'studentId', 'student')]
    },

    attendance: {
        name: 'attendance',
        model: Attendance,
        permissions: {
            list: [ROLES.OWNER, ROLES.TEACHER],
            create: [ROLES.OWNER, ROLES.TEACHER],
            update: [ROLES.OWNER, ROLES.TEACHER],
            remove: [ROLES.OWNER]
        },
        writableFields: ['studentId', 'classSessionId', 'present', 'recordedOn', 'note'],
        scopeRule: ownAttendance,
        softDelete: true,
        // The references are confirmed first, so a missing session reads as
        // 400, and only then is a teacher's ownership of the session checked.
        preSaveChecks: [
            referenceMustExist(Student, 'studentId', 'student'),
            referenceMustExist(ClassSession, 'classSessionId', 'class session'),
            createAttendanceWritePolicy(ClassSession)
        ]
    }
});

module.exports = ENTITIES;
