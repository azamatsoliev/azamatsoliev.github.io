/**
 * Database connection settings.
 *
 * Resolves the MongoDB connection string from configuration, names the
 * separate databases the development tools work in, and prepares connection
 * strings for safe logging.
 *
 * Two configuration routes are supported, in order of precedence:
 *
 *   MONGODB_URI  A complete connection string. Required for any database that
 *                enforces authentication, since the credentials travel inside
 *                it: mongodb://schoolApp:secret@host:27017/azamat_school?authSource=azamat_school
 *
 *   DB_HOST      A host name only. Produces an unauthenticated connection to
 *                the application database on that host.
 *
 * With neither set, the application connects to the local development database.
 *
 * Because a connection string can carry a password, it must never be printed
 * as-is. redactUri replaces the password before anything is logged.
 *
 * @file    app_api/config/database.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

/** Default database name for the application. */
const DEFAULT_DB_NAME = 'azamat_school';

/**
 * Suffixes of the databases the development tools create for themselves.
 *
 * Each tool works in its own database, derived from the application's name, so
 * that seeding demo data or running a benchmark can never touch real records.
 */
const TOOL_DATABASES = Object.freeze({
    DEMO: 'demo',
    REPORT_CHECK: 'reportcheck',
    BENCHMARK: 'benchmark'
});

/**
 * Returns the connection string the application should use.
 *
 * @param   {object} [env=process.env] - Environment variables.
 * @returns {string} A MongoDB connection string.
 */
const resolveDbUri = (env = process.env) => {
    if (env.MONGODB_URI && env.MONGODB_URI.trim() !== '') {
        return env.MONGODB_URI.trim();
    }
    const host = env.DB_HOST || '127.0.0.1';
    return `mongodb://${host}/${DEFAULT_DB_NAME}`;
};

/**
 * Names the separate database used by a development tool.
 *
 * @param   {string} suffix - One of TOOL_DATABASES.
 * @returns {string} For example, azamat_school_demo.
 */
const toolDatabaseName = (suffix) => `${DEFAULT_DB_NAME}_${suffix}`;

/**
 * Returns the connection string for a development tool's own database.
 *
 * Tools always build their own string from DB_HOST and deliberately ignore
 * MONGODB_URI, which points at the application's real database.
 *
 * @param   {string} suffix - One of TOOL_DATABASES.
 * @param   {object} [env=process.env] - Environment variables.
 * @returns {string} A MongoDB connection string.
 */
const toolDbUri = (suffix, env = process.env) => {
    const host = env.DB_HOST || '127.0.0.1';
    return `mongodb://${host}/${toolDatabaseName(suffix)}`;
};

/**
 * Replaces the password in a connection string with asterisks.
 *
 * Handles both mongodb:// and mongodb+srv:// forms. The user name is kept, as
 * it is useful when diagnosing a connection problem and is not a secret.
 *
 * @param   {string} uri - A connection string.
 * @returns {string} The same string with any password hidden.
 */
const redactUri = (uri) => String(uri).replace(
    /^(mongodb(?:\+srv)?:\/\/[^:/@]+):[^@]*@/i,
    '$1:****@'
);

module.exports = {
    DEFAULT_DB_NAME,
    TOOL_DATABASES,
    resolveDbUri,
    toolDatabaseName,
    toolDbUri,
    redactUri
};
