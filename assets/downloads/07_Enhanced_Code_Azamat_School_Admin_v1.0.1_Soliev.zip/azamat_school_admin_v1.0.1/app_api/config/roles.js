/**
 * Role definitions and permission resolution.
 *
 * Defines the three roles used across the platform and the inheritance
 * between them. Keeping this in one module means a permission question is
 * answered in exactly one place rather than being re-implemented in each
 * controller.
 *
 * Role model:
 *   owner       - runs the school; inherits every accountant and teacher
 *                 permission in addition to its own.
 *   accountant  - financial records only (payments and billing).
 *   teacher     - own class sessions and the attendance belonging to them.
 *
 * @file    app_api/config/roles.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

/** Canonical role names. Used instead of bare strings to avoid typos. */
const ROLES = Object.freeze({
    OWNER: 'owner',
    ACCOUNTANT: 'accountant',
    TEACHER: 'teacher'
});

/** The role assigned to every self-registered account. */
const DEFAULT_ROLE = ROLES.TEACHER;

/**
 * Roles whose permissions each role additionally receives.
 * Owner inherits both subordinate roles; the others inherit nothing.
 */
const ROLE_INHERITANCE = Object.freeze({
    [ROLES.OWNER]: [ROLES.ACCOUNTANT, ROLES.TEACHER],
    [ROLES.ACCOUNTANT]: [],
    [ROLES.TEACHER]: []
});

/**
 * Expands a role into the full set of roles it can act as.
 *
 * Resolution is breadth-first over ROLE_INHERITANCE and tolerates an
 * inheritance cycle, so a future edit to the table cannot hang a request.
 *
 * @param   {string} role - A role name.
 * @returns {string[]} The role plus every role it inherits.
 */
const expandRole = (role) => {
    if (!role || !Object.prototype.hasOwnProperty.call(ROLE_INHERITANCE, role)) {
        return [];
    }

    const resolved = new Set();
    const queue = [role];

    while (queue.length > 0) {
        const current = queue.shift();
        if (resolved.has(current)) {
            continue;
        }
        resolved.add(current);
        (ROLE_INHERITANCE[current] || []).forEach((inherited) => queue.push(inherited));
    }

    return Array.from(resolved);
};

/**
 * Determines whether a role satisfies a permission requirement.
 *
 * @param   {string}   role         - The role held by the requesting account.
 * @param   {string[]} allowedRoles - Roles permitted to perform the action.
 * @returns {boolean} True when the role, or a role it inherits, is allowed.
 */
const isAuthorized = (role, allowedRoles) => {
    if (!role || !Array.isArray(allowedRoles) || allowedRoles.length === 0) {
        return false;
    }
    const effectiveRoles = expandRole(role);
    return allowedRoles.some((allowed) => effectiveRoles.includes(allowed));
};

/**
 * Validates a role name submitted from outside the application.
 *
 * @param   {string} role - Candidate role name.
 * @returns {boolean} True when the value is one of the defined roles.
 */
const isValidRole = (role) => Object.values(ROLES).includes(role);

module.exports = {
    ROLES,
    DEFAULT_ROLE,
    ROLE_INHERITANCE,
    expandRole,
    isAuthorized,
    isValidRole
};
