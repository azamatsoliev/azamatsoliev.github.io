/**
 * Sign-in rate limiting.
 *
 * Caps how many failed sign-in attempts one network address can make in a
 * period. Without a cap, a password can be guessed as fast as the server will
 * answer. Each attempt also runs the deliberately slow 210,000-iteration
 * password hash, so a flood of attempts ties up the server for everyone else.
 *
 * Only failed attempts count: a person who signs in successfully is never held
 * up by earlier typing mistakes.
 *
 * The attempt counts are kept in memory, so they hold for one server process.
 * A deployment running several copies of the API would need a shared store,
 * the same limitation that applies to the per-teacher booking lock.
 *
 * @file    app_api/middleware/rateLimit.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const { rateLimit } = require('express-rate-limit');

/** Length of the counting window. */
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

/** Failed attempts allowed per address within one window. */
const LOGIN_ATTEMPT_LIMIT = 10;

/**
 * Builds the sign-in limiter.
 *
 * A factory rather than a single shared instance, so each test can start with
 * a fresh count.
 *
 * @param   {object} [options]
 * @param   {number} [options.windowMs] - Length of the counting window.
 * @param   {number} [options.limit]    - Failed attempts allowed per window.
 * @returns {Function} Express middleware.
 */
const createLoginLimiter = ({ windowMs = LOGIN_WINDOW_MS, limit = LOGIN_ATTEMPT_LIMIT } = {}) => rateLimit({
    windowMs,
    limit,
    skipSuccessfulRequests: true,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: {
        message: `Too many sign-in attempts. Please wait ${Math.ceil(windowMs / 60000)} minutes and try again.`
    }
});

module.exports = { LOGIN_WINDOW_MS, LOGIN_ATTEMPT_LIMIT, createLoginLimiter };
