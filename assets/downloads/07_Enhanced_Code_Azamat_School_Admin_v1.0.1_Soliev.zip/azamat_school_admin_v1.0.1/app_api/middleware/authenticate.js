/**
 * Authentication middleware.
 *
 * Verifies the bearer token on an incoming request and attaches the verified
 * payload to req.auth for downstream handlers.
 *
 * This replaces the inline implementation previously held in the routes file.
 * The code review identified two defects in that version, both corrected here:
 *
 *   1. It tested whether splitting the Authorization header produced fewer than
 *      one element. String.prototype.split always returns at least one element,
 *      so that branch could never execute. The real failure it was reaching for
 *      is a header that is present but not a well-formed bearer token, which is
 *      what this version checks.
 *
 *   2. That branch answered HTTP 501 Not Implemented. A malformed or missing
 *      credential is 401 Unauthorized. 501 states that the server does not
 *      support the request method at all, which was misleading to any client
 *      trying to handle the response.
 *
 * Moving this out of the routes file also separates concerns: routes now
 * describe what is exposed, and this module decides who may reach it.
 *
 * @file    app_api/middleware/authenticate.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const jwt = require('jsonwebtoken');
const { isAuthorized } = require('../config/roles');

/** Expected shape of the Authorization header: "Bearer <token>". */
const BEARER_PREFIX = 'bearer';

/**
 * Extracts the token from an Authorization header.
 *
 * @param   {string} header - Raw Authorization header value.
 * @returns {string|null} The token, or null when the header is not usable.
 */
const extractBearerToken = (header) => {
    if (typeof header !== 'string' || header.trim() === '') {
        return null;
    }

    const parts = header.trim().split(/\s+/);

    if (parts.length !== 2 || parts[0].toLowerCase() !== BEARER_PREFIX) {
        return null;
    }

    return parts[1];
};

/**
 * Requires a valid token and attaches its payload to req.auth.
 *
 * Responses deliberately do not distinguish between a missing token, a
 * malformed one, and an expired one. Reporting which is at fault tells an
 * attacker how close a forged token came to being accepted.
 */
const authenticate = (req, res, next) => {
    const token = extractBearerToken(req.headers.authorization);

    if (!token) {
        return res.status(401).json({ message: 'Authentication required.' });
    }

    return jwt.verify(token, process.env.JWT_SECRET, (error, payload) => {
        if (error) {
            return res.status(401).json({ message: 'Authentication required.' });
        }

        req.auth = payload;
        return next();
    });
};

/**
 * Restricts a route to specific roles.
 *
 * Used for endpoints that are not produced by the controller factory, such as
 * changing another account's role. Factory-generated handlers carry their own
 * role and scope checks and do not need this.
 *
 * @param   {...string} allowedRoles - Roles permitted to reach the route.
 * @returns {Function} Express middleware.
 */
const requireRole = (...allowedRoles) => (req, res, next) => {
    if (!req.auth) {
        return res.status(401).json({ message: 'Authentication required.' });
    }

    if (!isAuthorized(req.auth.role, allowedRoles)) {
        return res.status(403).json({ message: 'You do not have permission to do that.' });
    }

    return next();
};

module.exports = { authenticate, requireRole, extractBearerToken };
