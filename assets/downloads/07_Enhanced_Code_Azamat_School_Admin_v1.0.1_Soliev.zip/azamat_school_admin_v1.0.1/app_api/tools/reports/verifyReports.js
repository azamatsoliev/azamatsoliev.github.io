/**
 * Report verification against a real MongoDB database.
 *
 * The unit tests run the reporting pipelines in an in-memory engine. This tool
 * runs the identical pipelines inside MongoDB itself, against the same
 * hand-calculated fixture, and checks every figure. It also asks MongoDB which
 * index each report query used, confirming that the indexes were designed for
 * the queries that actually run.
 *
 * It uses a separate database named azamat_school_reportcheck, which it creates
 * and deletes. The application's own database is never touched.
 *
 * Usage, with MongoDB running:
 *   npm run verify:reports
 *
 * Exits with status 0 when every check passes and 1 otherwise.
 *
 * This module is development tooling. The application never loads it.
 *
 * @file    app_api/tools/reports/verifyReports.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

require('dotenv').config({ quiet: true });
const assert = require('node:assert');
const mongoose = require('mongoose');

const Teacher = require('../../models/teacher');
const Student = require('../../models/student');
const ClassSession = require('../../models/classSession');
const Attendance = require('../../models/attendance');
const Payment = require('../../models/payment');
const { createReportService } = require('../../reports/reportService');
const { localMonthRange } = require('../../reports/periods');
const { buildFixture, EXPECTED, FIXED_NOW, PERIOD, ID } = require('./reportFixture');
const { DEFAULT_DB_NAME, TOOL_DATABASES, toolDatabaseName, toolDbUri } = require('../../config/database');

const DATABASE = toolDatabaseName(TOOL_DATABASES.REPORT_CHECK);
const uri = toolDbUri(TOOL_DATABASES.REPORT_CHECK);

const results = [];

/** Runs one comparison and records whether it passed. */
const check = (label, actual, expected) => {
    try {
        assert.deepStrictEqual(actual, expected);
        results.push({ label, passed: true });
    } catch (error) {
        results.push({
            label,
            passed: false,
            detail: `expected ${JSON.stringify(expected)}\n           got      ${JSON.stringify(actual)}`
        });
    }
};

const pick = (rows, fields) => rows.map((row) => Object.fromEntries(fields.map((f) => [f, row[f]])));

/** Finds the first index name anywhere in an explain document. */
const indexUsed = (explain) => {
    const visit = (node) => {
        if (!node || typeof node !== 'object') return undefined;
        if (typeof node.indexName === 'string') return node.indexName;
        for (const value of Object.values(node)) {
            const found = visit(value);
            if (found) return found;
        }
        return undefined;
    };
    return visit(explain && explain.queryPlanner && explain.queryPlanner.winningPlan) || '(collection scan)';
};

const run = async () => {
    if (DATABASE === DEFAULT_DB_NAME) {
        throw new Error('Refusing to run against the application database.');
    }

    console.log(`\nVerifying report pipelines against MongoDB (${uri})\n`);
    await mongoose.connect(uri);

    try {
        await mongoose.connection.dropDatabase();
        await Promise.all([Teacher, Student, ClassSession, Attendance, Payment].map((m) => m.createIndexes()));

        const data = buildFixture((hex) => new mongoose.Types.ObjectId(hex));
        await Teacher.insertMany(data.teachers);
        await Student.insertMany(data.students);
        await ClassSession.insertMany(data.classSessions);
        await Attendance.insertMany(data.attendance);
        await Payment.insertMany(data.payments);

        const service = createReportService({
            models: { Student, ClassSession, Payment, Attendance },
            now: () => FIXED_NOW,
            castId: (id) => new mongoose.Types.ObjectId(String(id))
        });

        const balances = await service.studentBalances();
        check('Balances: rows and order',
            pick(balances.rows, ['firstName', 'lastName', 'withdrawn', 'classesAttended', 'billed', 'paid', 'outstanding']),
            EXPECTED.balances.rows);
        check('Balances: totals', balances.totals, EXPECTED.balances.totals);

        const revenue = await service.revenueByStudent(PERIOD);
        check('Revenue for October: rows', pick(revenue.rows, ['lastName', 'payments', 'collected']), EXPECTED.revenue.rows);
        check('Revenue for October: totals', revenue.totals, EXPECTED.revenue.totals);

        const byMonth = await service.revenueByMonth(2026);
        check('Revenue by month: September',
            { payments: byMonth.months[8].payments, collected: byMonth.months[8].collected },
            EXPECTED.revenueByMonth.september);
        check('Revenue by month: October',
            { payments: byMonth.months[9].payments, collected: byMonth.months[9].collected },
            EXPECTED.revenueByMonth.october);
        check('Revenue by month: year totals', byMonth.totals, EXPECTED.revenueByMonth.totals);

        const classes = await service.classSummary(PERIOD);
        check('Class summary: rows',
            pick(classes.rows, ['title', 'sessions', 'recorded', 'present', 'attendanceRate', 'billed']),
            EXPECTED.classSummary.rows);
        check('Class summary: totals', classes.totals, EXPECTED.classSummary.totals);

        const sheet = await service.attendanceSheet({ teacherId: ID.T_DILNOZA, period: PERIOD });
        check('Attendance sheet: statuses', sheet.sessions.map((s) => s.status), EXPECTED.attendanceSheet.statuses);
        check('Attendance sheet: first roster',
            pick(sheet.sessions[0].roster, ['lastName', 'present']), EXPECTED.attendanceSheet.firstRoster);
        check('Attendance sheet: summary', sheet.summary, EXPECTED.attendanceSheet.summary);

        // Which indexes MongoDB chose for the two session queries the reports run.
        const { from, to } = localMonthRange(PERIOD);
        const periodPlan = await ClassSession
            .find({ active: true, startTime: { $gte: from, $lt: to } }).explain('executionStats');
        const sheetPlan = await ClassSession
            .find({ teacherId: new mongoose.Types.ObjectId(ID.T_DILNOZA), active: true, startTime: { $gte: from, $lt: to } })
            .explain('executionStats');

        check('Index used by the class summary', indexUsed(periodPlan), 'active_1_startTime_1');
        check('Index used by the attendance sheet', indexUsed(sheetPlan), 'teacherId_1_active_1_startTime_1');
    } finally {
        await mongoose.connection.dropDatabase();
        await mongoose.connection.close();
    }

    results.forEach((r) => {
        console.log(`  ${r.passed ? 'PASS' : 'FAIL'}  ${r.label}`);
        if (!r.passed) console.log(`           ${r.detail}`);
    });

    const failed = results.filter((r) => !r.passed).length;
    console.log(`\n${results.length - failed} of ${results.length} checks passed.`);
    console.log(`The ${DATABASE} database has been deleted.\n`);
    process.exit(failed === 0 ? 0 : 1);
};

run().catch(async (error) => {
    console.error('\nVerification could not run:', error.message);
    console.error('Is MongoDB running? See the troubleshooting section of the run guide.\n');
    try { await mongoose.connection.close(); } catch (closeError) { /* already closed */ }
    process.exit(1);
});
