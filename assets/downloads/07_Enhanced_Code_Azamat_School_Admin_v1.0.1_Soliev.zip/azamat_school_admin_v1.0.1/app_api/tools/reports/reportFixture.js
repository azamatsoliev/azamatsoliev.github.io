/**
 * Report fixture.
 *
 * A small, hand-built school whose every report figure has been calculated by
 * hand and is recorded in EXPECTED below. The unit tests run the reporting
 * pipelines against it in an in-memory engine, and the verification tool loads
 * the same data into a real MongoDB database and checks the same figures, so a
 * single set of hand calculations verifies both.
 *
 * The data deliberately contains every case the reports must handle correctly:
 *
 *   - a reversed payment, which must not count as money received;
 *   - a canceled session with attendance recorded, which must not be billed;
 *   - a withdrawn attendance record, which must not count as attendance;
 *   - a withdrawn student who still owes money, who must remain visible;
 *   - a withdrawn student whose balance is exactly zero, who must not appear;
 *   - rates of 10.05 and 16.85, which floating point adds to 26.900000000000002,
 *     and which still miss by a fraction when scaled to cents without rounding;
 *   - a class whose attendance was never taken, whose rate must be null, not 0;
 *   - a payment on the first of a month, which must not slip into the previous
 *     month in any time zone.
 *
 * Session times are built in local time and payment dates in UTC, matching how
 * the application receives each kind of value.
 *
 * This module is development tooling. The application never loads it.
 *
 * @file    app_api/tools/reports/reportFixture.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

/** Identifiers, as 24-character hexadecimal strings. */
const ID = Object.freeze({
    T_DILNOZA: 'a00000000000000000000001',
    T_JASUR: 'a00000000000000000000002',
    S_AZIZA: 'b00000000000000000000001',
    S_BEKZOD: 'b00000000000000000000002',
    S_DILSHOD: 'b00000000000000000000003',
    S_MALIKA: 'b00000000000000000000004',
    S_SEVARA: 'b00000000000000000000005',
    C1: 'c00000000000000000000001',
    C2: 'c00000000000000000000002',
    C3: 'c00000000000000000000003',
    C4: 'c00000000000000000000004',
    C5: 'c00000000000000000000005',
    C6: 'c00000000000000000000006',
    C7: 'c00000000000000000000007',
    C8: 'c00000000000000000000008',
    C10: 'c0000000000000000000000a',
    C11: 'c0000000000000000000000b'
});

/** The moment the attendance-sheet statuses are judged from: 20 Oct 2026, 12:00 local. */
const FIXED_NOW = new Date(2026, 9, 20, 12, 0);

/** The month every period report in the fixture is requested for. */
const PERIOD = Object.freeze({ year: 2026, month: 10 });

/** A lesson on a given October 2026 day, in local time. */
const lesson = (day, startHour, startMinute, endHour, endMinute, month = 9) => ({
    startTime: new Date(2026, month, day, startHour, startMinute),
    endTime: new Date(2026, month, day, endHour, endMinute)
});

/** A calendar date stored as midnight UTC, as the browser sends a date-only value. */
const calendarDate = (month, day) => new Date(Date.UTC(2026, month - 1, day));

/**
 * Builds the fixture documents.
 *
 * @param   {Function} [toId] - Converts a hexadecimal string to the identifier
 *          type of the target engine: unchanged for the in-memory engine, an
 *          ObjectId for MongoDB.
 * @returns {object} Documents keyed by collection.
 */
const buildFixture = (toId = (hex) => hex) => {
    const teachers = [
        { _id: toId(ID.T_DILNOZA), firstName: 'Dilnoza', lastName: 'Karimova', email: 'dilnoza@fixture.test', active: true },
        { _id: toId(ID.T_JASUR), firstName: 'Jasur', lastName: 'Aliev', email: 'jasur@fixture.test', active: true }
    ];

    const students = [
        { _id: toId(ID.S_AZIZA), firstName: 'Aziza', lastName: 'Rahimova', email: 'aziza@fixture.test', active: true },
        { _id: toId(ID.S_BEKZOD), firstName: 'Bekzod', lastName: 'Tursunov', email: 'bekzod@fixture.test', active: false },
        { _id: toId(ID.S_DILSHOD), firstName: 'Dilshod', lastName: 'Nazarov', email: 'dilshod@fixture.test', active: true },
        { _id: toId(ID.S_MALIKA), firstName: 'Malika', lastName: 'Ergasheva', email: 'malika@fixture.test', active: false },
        { _id: toId(ID.S_SEVARA), firstName: 'Sevara', lastName: 'Yusupova', email: 'sevara@fixture.test', active: true }
    ];

    const session = (id, title, teacher, times, ratePerClass, active = true) => ({
        _id: toId(id), title, teacherId: toId(teacher), ...times, ratePerClass, room: 'Room 1', active
    });

    const classSessions = [
        session(ID.C1, 'Beginner English A1', ID.T_DILNOZA, lesson(5, 9, 0, 11, 0), 25),
        session(ID.C2, 'Beginner English A1', ID.T_DILNOZA, lesson(12, 9, 0, 11, 0), 25),
        session(ID.C3, 'Conversation Club', ID.T_JASUR, lesson(7, 18, 0, 19, 30), 30),
        session(ID.C4, 'Beginner English A1', ID.T_DILNOZA, lesson(19, 9, 0, 11, 0), 25),
        session(ID.C5, 'IELTS Prep', ID.T_JASUR, lesson(9, 10, 0, 12, 0), 10.05),
        session(ID.C6, 'IELTS Prep', ID.T_JASUR, lesson(16, 10, 0, 12, 0), 16.85),
        session(ID.C7, 'Conversation Club', ID.T_JASUR, lesson(14, 18, 0, 19, 30), 30, false),
        session(ID.C8, 'Beginner English A1', ID.T_DILNOZA, lesson(28, 9, 0, 11, 0, 8), 25),
        session(ID.C10, 'Beginner English A1', ID.T_DILNOZA, lesson(26, 9, 0, 11, 0), 25),
        session(ID.C11, 'Business English', ID.T_JASUR, lesson(21, 14, 0, 15, 0), 40)
    ];

    let attendanceNumber = 0;
    const mark = (student, sessionId, present, active = true) => {
        attendanceNumber += 1;
        return {
            _id: toId(`d${String(attendanceNumber).padStart(23, '0')}`),
            studentId: toId(student),
            classSessionId: toId(sessionId),
            present,
            active,
            recordedOn: new Date(2026, 9, 1)
        };
    };

    const attendance = [
        mark(ID.S_AZIZA, ID.C1, true),
        mark(ID.S_AZIZA, ID.C2, true),
        mark(ID.S_AZIZA, ID.C3, true),
        mark(ID.S_AZIZA, ID.C8, false),
        mark(ID.S_BEKZOD, ID.C5, true),
        mark(ID.S_BEKZOD, ID.C6, true),
        mark(ID.S_DILSHOD, ID.C7, true),
        mark(ID.S_DILSHOD, ID.C1, false),
        mark(ID.S_MALIKA, ID.C3, true),
        mark(ID.S_SEVARA, ID.C2, true),
        mark(ID.S_SEVARA, ID.C1, true, false)
    ];

    const pay = (id, student, amount, paidOn, active = true) => ({
        _id: toId(id), studentId: toId(student), amount, paidOn, method: 'cash', active
    });

    const payments = [
        pay('e00000000000000000000001', ID.S_AZIZA, 50.00, calendarDate(10, 1)),
        pay('e00000000000000000000002', ID.S_AZIZA, 20.00, calendarDate(10, 3), false),
        pay('e00000000000000000000003', ID.S_BEKZOD, 26.90, calendarDate(9, 30)),
        pay('e00000000000000000000004', ID.S_SEVARA, 40.00, calendarDate(10, 15))
    ];

    return { teachers, students, classSessions, attendance, payments };
};

/**
 * Expected report figures, calculated by hand from the data above.
 *
 * Balances, by student (billed is the sum of rates of active sessions attended):
 *   Aziza    C1 25 + C2 25 + C3 30 = 80.00 billed; paid 50.00 (the 20.00 was
 *            reversed); outstanding 30.00. Her absence at C8 is not billed.
 *   Bekzod   C5 10.05 + C6 16.85 = 26.90 billed; paid 26.90; outstanding 0.00.
 *            Withdrawn and settled, so he does not appear.
 *   Dilshod  present only at C7, which was canceled, so 0.00 billed; absent at
 *            C1. Paid 0.00; outstanding 0.00. Active, so he appears.
 *   Malika   C3 30 = 30.00 billed; paid 0.00; outstanding 30.00. Withdrawn but
 *            owing, so she appears.
 *   Sevara   C2 25 = 25.00 billed. Her C1 record was withdrawn, so it is not
 *            billed. Paid 40.00; outstanding -15.00, a credit.
 *   Order: outstanding descending, then last name. Malika (Ergasheva) and Aziza
 *   (Rahimova) both owe 30.00; Ergasheva sorts first.
 *   Totals over the rows shown: billed 30 + 80 + 0 + 25 = 135.00;
 *   paid 0 + 50 + 0 + 40 = 90.00; outstanding 30 + 30 + 0 - 15 = 45.00.
 *
 * Revenue for October 2026 (payment dates in UTC):
 *   Aziza 50.00 on 1 Oct counts; her 20.00 on 3 Oct was reversed. Bekzod's
 *   26.90 on 30 Sep is September. Sevara 40.00 on 15 Oct counts.
 *   Rows by last name: Rahimova 50.00, Yusupova 40.00. Total 90.00, 2 payments.
 *
 * Revenue by month for 2026: September 26.90 (1 payment); October 90.00
 *   (2 payments); every other month 0. Year total 116.90, 3 payments.
 *
 * Class summary for October 2026 (active sessions only; C7 canceled, C8 is
 * September):
 *   Beginner English A1  C1 (Aziza present, Dilshod absent; Sevara's record
 *     withdrawn) 2 recorded 1 present; C2 2 recorded 2 present; C4 and C10 not
 *     taken. 4 sessions, 4 recorded, 3 present, rate 0.75,
 *     billed 1 x 25 + 2 x 25 = 75.00.
 *   Business English     C11, never taken. 1 session, rate null, billed 0.00.
 *   Conversation Club    C3, Aziza and Malika present. 1 session, 2 of 2,
 *     rate 1, billed 60.00.
 *   IELTS Prep           C5 and C6, Bekzod present at both. 2 sessions, 2 of 2,
 *     rate 1, billed 10.05 + 16.85 = 26.90.
 *   Totals: 8 sessions, 8 recorded, 7 present, rate 0.875, billed 161.90.
 *   Cross-check: October billing by student is Aziza 80 + Bekzod 26.90 +
 *   Malika 30 + Sevara 25 = 161.90.
 *
 * Attendance sheet for Dilnoza, October 2026, judged at 20 Oct 12:00:
 *   C1 5 Oct  Taken      roster Nazarov (absent), Rahimova (present)
 *   C2 12 Oct Taken      roster Rahimova (present), Yusupova (present)
 *   C4 19 Oct Not taken  past, no records
 *   C10 26 Oct Upcoming  future
 *   Summary: 4 sessions, 2 taken, 1 not taken, 1 upcoming, completion 2/3.
 */
const EXPECTED = Object.freeze({
    balances: {
        rows: [
            { firstName: 'Malika', lastName: 'Ergasheva', withdrawn: true, classesAttended: 1, billed: 30, paid: 0, outstanding: 30 },
            { firstName: 'Aziza', lastName: 'Rahimova', withdrawn: false, classesAttended: 3, billed: 80, paid: 50, outstanding: 30 },
            { firstName: 'Dilshod', lastName: 'Nazarov', withdrawn: false, classesAttended: 0, billed: 0, paid: 0, outstanding: 0 },
            { firstName: 'Sevara', lastName: 'Yusupova', withdrawn: false, classesAttended: 1, billed: 25, paid: 40, outstanding: -15 }
        ],
        totals: { billed: 135, paid: 90, outstanding: 45 }
    },
    revenue: {
        rows: [
            { lastName: 'Rahimova', payments: 1, collected: 50 },
            { lastName: 'Yusupova', payments: 1, collected: 40 }
        ],
        totals: { payments: 2, collected: 90 }
    },
    revenueByMonth: {
        september: { payments: 1, collected: 26.9 },
        october: { payments: 2, collected: 90 },
        totals: { payments: 3, collected: 116.9 }
    },
    classSummary: {
        rows: [
            { title: 'Beginner English A1', sessions: 4, recorded: 4, present: 3, attendanceRate: 0.75, billed: 75 },
            { title: 'Business English', sessions: 1, recorded: 0, present: 0, attendanceRate: null, billed: 0 },
            { title: 'Conversation Club', sessions: 1, recorded: 2, present: 2, attendanceRate: 1, billed: 60 },
            { title: 'IELTS Prep', sessions: 2, recorded: 2, present: 2, attendanceRate: 1, billed: 26.9 }
        ],
        totals: { sessions: 8, recorded: 8, present: 7, attendanceRate: 0.875, billed: 161.9 }
    },
    attendanceSheet: {
        statuses: ['Taken', 'Taken', 'Not taken', 'Upcoming'],
        firstRoster: [
            { lastName: 'Nazarov', present: false },
            { lastName: 'Rahimova', present: true }
        ],
        summary: { sessions: 4, taken: 2, notTaken: 1, upcoming: 1, completionRate: 0.6667 }
    }
});

module.exports = { ID, FIXED_NOW, PERIOD, buildFixture, EXPECTED };
