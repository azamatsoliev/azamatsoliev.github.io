/**
 * Demo school seeder.
 *
 * Builds a realistic language school in a separate database named
 * azamat_school_demo, so the reports can be demonstrated with meaningful data: four months of
 * weekly classes, attendance taken by two teachers, monthly tuition payments,
 * a reversed payment, a student who left still owing, a student who left fully
 * settled, and a few recent lessons whose attendance has not yet been taken.
 *
 * The application's own database is never touched. The seeder refuses to run
 * against it, and it deletes and recreates the demo database on every run, so
 * it can be rerun safely.
 *
 * Randomness is seeded, so the same schedule and attendance are produced every
 * time. Which lessons count as past depends on the date the seeder is run.
 *
 * Usage, with MongoDB running:
 *   npm run seed:demo
 *
 * Then start the backend against the demo database:
 *   npm run start:demo
 *
 * Demo email addresses use the reserved example domain (RFC 2606), so nothing
 * built from this data can ever reach a real mailbox.
 *
 * This module is development tooling. The application never loads it.
 *
 * @file    app_api/tools/reports/seedDemoSchool.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

require('dotenv').config({ quiet: true });
const mongoose = require('mongoose');

const User = require('../../models/user');
const Teacher = require('../../models/teacher');
const Student = require('../../models/student');
const ClassSession = require('../../models/classSession');
const Attendance = require('../../models/attendance');
const Payment = require('../../models/payment');
const { ROLES } = require('../../config/roles');
const { DEFAULT_DB_NAME, TOOL_DATABASES, toolDatabaseName, toolDbUri } = require('../../config/database');
const { createRandom } = require('../benchmark/scheduleGenerator');

const DATABASE = toolDatabaseName(TOOL_DATABASES.DEMO);
const uri = toolDbUri(TOOL_DATABASES.DEMO);

/** Domain reserved for examples; it can never deliver mail. */
const DEMO_DOMAIN = 'school.example';

/** Demo sign-ins. Local demonstration only; never reuse these passwords. */
const ACCOUNTS = [
    { name: 'School Owner', email: `owner@${DEMO_DOMAIN}`, password: 'DemoOwner123', role: ROLES.OWNER },
    { name: 'Madina Yusupova', email: `accounts@${DEMO_DOMAIN}`, password: 'DemoAccounts123', role: ROLES.ACCOUNTANT },
    { name: 'Dilnoza Karimova', email: `dilnoza@${DEMO_DOMAIN}`, password: 'DemoTeacher123', role: ROLES.TEACHER, teacher: 'dilnoza' },
    { name: 'Jasur Aliev', email: `jasur@${DEMO_DOMAIN}`, password: 'DemoTeacher123', role: ROLES.TEACHER, teacher: 'jasur' }
];

/**
 * Weekly classes: day of week (0 Sunday to 6 Saturday), start, length in
 * minutes, rate, teacher, and the students enrolled by index.
 */
const CLASSES = [
    { title: 'Beginner English A1', days: [1, 3], hour: 9, minute: 0, length: 120, rate: 25, teacher: 'dilnoza', students: [0, 1, 2, 3, 4] },
    { title: 'Business English', days: [6], hour: 14, minute: 0, length: 90, rate: 40, teacher: 'dilnoza', students: [5, 6] },
    { title: 'IELTS Prep', days: [2, 4], hour: 10, minute: 0, length: 120, rate: 16.85, teacher: 'jasur', students: [1, 6, 7] },
    { title: 'Conversation Club', days: [5], hour: 18, minute: 0, length: 90, rate: 10.05, teacher: 'jasur', students: [0, 2, 3, 5, 7] }
];

const STUDENTS = [
    ['Aziza', 'Rahimova'], ['Bekzod', 'Tursunov'], ['Dilshod', 'Nazarov'], ['Malika', 'Ergasheva'],
    ['Sevara', 'Yusupova'], ['Timur', 'Sadikov'], ['Nodira', 'Xolmatova'], ['Rustam', 'Qodirov']
];

/** Student 3 leaves after September still owing; student 4 leaves fully settled. */
const LEAVES_OWING = 3;
const LEAVES_SETTLED = 4;
const LAST_DAY_OF_ATTENDANCE = new Date(2026, 8, 30, 23, 59);

const FIRST_DAY = new Date(2026, 7, 3);    // 3 August 2026
const LAST_DAY = new Date(2026, 10, 28);   // 28 November 2026

const run = async () => {
    if (DATABASE === DEFAULT_DB_NAME) {
        throw new Error('Refusing to seed the application database.');
    }

    const now = new Date();
    const random = createRandom(20261005);

    console.log(`\nSeeding demo school into ${uri}\n`);
    await mongoose.connect(uri);
    await mongoose.connection.dropDatabase();
    await Promise.all([User, Teacher, Student, ClassSession, Attendance, Payment].map((m) => m.createIndexes()));

    // Teachers and accounts
    const teachers = {
        dilnoza: await Teacher.create({ firstName: 'Dilnoza', lastName: 'Karimova', email: `dilnoza@${DEMO_DOMAIN}`, subjects: ['English'] }),
        jasur: await Teacher.create({ firstName: 'Jasur', lastName: 'Aliev', email: `jasur@${DEMO_DOMAIN}`, subjects: ['English', 'IELTS'] })
    };

    for (const account of ACCOUNTS) {
        const user = new User({
            name: account.name,
            email: account.email,
            role: account.role,
            teacherId: account.teacher ? teachers[account.teacher]._id : null
        });
        user.setPassword(account.password);
        await user.save();
    }

    // Students
    const students = await Student.insertMany(STUDENTS.map(([firstName, lastName]) => ({
        firstName,
        lastName,
        email: `${firstName.toLowerCase()}@${DEMO_DOMAIN}`,
        enrolledOn: new Date(Date.UTC(2026, 7, 1))
    })));

    // Weekly sessions from August to November
    const sessionPlans = [];
    for (let day = new Date(FIRST_DAY); day <= LAST_DAY; day.setDate(day.getDate() + 1)) {
        for (const course of CLASSES) {
            if (course.days.includes(day.getDay())) {
                const startTime = new Date(day.getFullYear(), day.getMonth(), day.getDate(), course.hour, course.minute);
                sessionPlans.push({
                    course,
                    doc: {
                        title: course.title,
                        teacherId: teachers[course.teacher]._id,
                        startTime,
                        endTime: new Date(startTime.getTime() + course.length * 60000),
                        ratePerClass: course.rate,
                        room: course.teacher === 'dilnoza' ? 'Room 1' : 'Room 2'
                    }
                });
            }
        }
    }
    const sessions = await ClassSession.insertMany(sessionPlans.map((plan) => plan.doc));

    // Attendance for lessons that have already started. The two most recent past
    // Beginner English lessons are left untaken, so a teacher's sheet shows the
    // "Not taken" state.
    const pastBeginner = sessions
        .filter((s) => s.title === 'Beginner English A1' && s.startTime < now)
        .sort((a, b) => b.startTime - a.startTime)
        .slice(0, 2)
        .map((s) => String(s._id));

    const attendance = [];
    const billedCents = new Array(students.length).fill(0);

    sessions.forEach((session, index) => {
        if (session.startTime >= now || pastBeginner.includes(String(session._id))) {
            return;
        }
        sessionPlans[index].course.students.forEach((studentIndex) => {
            const left = studentIndex === LEAVES_OWING || studentIndex === LEAVES_SETTLED;
            if (left && session.startTime > LAST_DAY_OF_ATTENDANCE) {
                return;
            }
            const present = random() < 0.85;
            attendance.push({
                studentId: students[studentIndex]._id,
                classSessionId: session._id,
                present,
                recordedOn: session.startTime
            });
            if (present) {
                billedCents[studentIndex] += Math.round(session.ratePerClass * 100);
            }
        });
    });
    await Attendance.insertMany(attendance);

    // Monthly tuition payments, made on the 5th, for months that have begun.
    // Most students pay a little under what they were billed, so balances vary.
    const payments = [];
    for (let month = 7; month <= 10; month += 1) {
        const paidOn = new Date(Date.UTC(2026, month, 5));
        if (paidOn > now) break;
        students.forEach((student, index) => {
            if ((index === LEAVES_OWING || index === LEAVES_SETTLED) && month > 8) return;
            // The settling student pays a modest amount each month, so their final
            // settlement is always a further payment rather than a refund; a
            // payment amount may not be negative.
            const amount = [150, 200, 120, 100, 100, 160, 140, 130][index];
            payments.push({ studentId: student._id, amount, paidOn, method: index % 2 === 0 ? 'cash' : 'card' });
        });
    }

    // The student who leaves settled pays exactly what they owe. Their final
    // payment is calculated in cents, so the balance comes to exactly zero.
    const settledPaid = payments
        .filter((p) => String(p.studentId) === String(students[LEAVES_SETTLED]._id))
        .reduce((total, p) => total + Math.round(p.amount * 100), 0);
    const settlement = billedCents[LEAVES_SETTLED] - settledPaid;
    if (settlement < 0) {
        console.warn('  Note: the settling student was overpaid, so they will show a credit.');
    } else if (settlement > 0) {
        payments.push({
            studentId: students[LEAVES_SETTLED]._id,
            amount: settlement / 100,
            paidOn: new Date(Date.UTC(2026, 9, 1)),
            method: 'transfer',
            reference: 'Final settlement'
        });
    }

    // One reversed payment, kept for the audit trail but not counted.
    payments.push({
        studentId: students[0]._id, amount: 75, paidOn: new Date(Date.UTC(2026, 8, 12)),
        method: 'card', reference: 'Card payment reversed', active: false
    });

    await Payment.insertMany(payments);

    await Student.updateMany(
        { _id: { $in: [students[LEAVES_OWING]._id, students[LEAVES_SETTLED]._id] } },
        { $set: { active: false } }
    );

    await mongoose.connection.close();

    console.log(`  ${students.length} students, ${sessions.length} class sessions,`);
    console.log(`  ${attendance.length} attendance records, ${payments.length} payments\n`);
    console.log('  Sign in at http://localhost:4200/login with:\n');
    ACCOUNTS.forEach((a) => console.log(`    ${a.role.padEnd(11)} ${a.email.padEnd(24)} ${a.password}`));
    console.log('\n  Start the backend against this database with:');
    console.log('    npm run start:demo\n');
};

run().catch(async (error) => {
    console.error('\nSeeding failed:', error.message);
    try { await mongoose.connection.close(); } catch (closeError) { /* already closed */ }
    process.exit(1);
});
