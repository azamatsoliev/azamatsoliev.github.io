/**
 * In-memory models of the three conflict-detection strategies.
 *
 * Each function answers the same question as the production check, whether a
 * proposed session overlaps an existing one, and also reports how many
 * sessions it had to examine. That count is the quantity the Big O analysis
 * describes, measured directly rather than inferred from timing.
 *
 * The indexed strategies operate on a schedule sorted by start time, which is
 * exactly the order a B-tree index on startTime keeps its entries in. Seeking to
 * a position with binary search mirrors the index descending its tree in
 * O(log n), and walking forward from there mirrors an index range scan. The
 * model therefore reproduces the database's cost structure without needing a
 * database, which lets the tests run anywhere.
 *
 * The bounded strategy uses the production candidateWindow and intervalsOverlap
 * functions, so a test of this model is a test of the bounds the application
 * actually queries with.
 *
 * This module is development tooling. The application never loads it.
 *
 * @file    app_api/tools/benchmark/strategies.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const {
    candidateWindow,
    intervalsOverlap
} = require('../../scheduling/conflictDetection');

/**
 * Strategy 1: naive scan. Examines every session. O(n).
 *
 * @returns {{ conflict: boolean, examined: number }}
 */
const naiveScan = (schedule, start, end) => {
    let conflict = false;
    for (let i = 0; i < schedule.length; i += 1) {
        if (intervalsOverlap(start, end, schedule[i].startTime, schedule[i].endTime)) {
            conflict = true;
        }
    }
    return { conflict, examined: schedule.length };
};

/**
 * Strategy 2: indexed but unbounded. O(n).
 *
 * The overlap condition bounds startTime from above only, so an index scan has
 * nowhere to begin except the start of the teacher's history. It walks forward
 * until start times pass the proposed end.
 *
 * @returns {{ conflict: boolean, examined: number }}
 */
const unboundedIndexScan = (schedule, start, end) => {
    let conflict = false;
    let examined = 0;
    for (let i = 0; i < schedule.length && schedule[i].startTime < end; i += 1) {
        examined += 1;
        if (schedule[i].endTime > start) {
            conflict = true;
        }
    }
    return { conflict, examined };
};

/**
 * Finds the first index whose start time is strictly greater than a value.
 * Standard binary search, O(log n). Returns the number of probes it made so
 * the seek cost can be reported alongside the scan cost.
 */
const firstStartAfter = (schedule, value) => {
    let low = 0;
    let high = schedule.length;
    let probes = 0;
    while (low < high) {
        const middle = (low + high) >>> 1;
        probes += 1;
        if (schedule[middle].startTime > value) {
            high = middle;
        } else {
            low = middle + 1;
        }
    }
    return { index: low, probes };
};

/**
 * Strategy 3: indexed and bounded on both sides. O(log n + k).
 *
 * Seeks to the lower edge of the candidate window by binary search, then walks
 * only the entries inside it, testing each exactly.
 *
 * @returns {{ conflict: boolean, examined: number, probes: number, candidates: number }}
 */
const boundedIndexScan = (schedule, start, end) => {
    const { lowerExclusive, upperExclusive } = candidateWindow(start, end);
    const { index, probes } = firstStartAfter(schedule, lowerExclusive);

    let conflict = false;
    let candidates = 0;
    for (let i = index; i < schedule.length && schedule[i].startTime < upperExclusive; i += 1) {
        candidates += 1;
        if (intervalsOverlap(start, end, schedule[i].startTime, schedule[i].endTime)) {
            conflict = true;
        }
    }

    return { conflict, examined: probes + candidates, probes, candidates };
};

module.exports = { naiveScan, unboundedIndexScan, boundedIndexScan, firstStartAfter };
