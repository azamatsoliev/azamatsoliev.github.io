/**
 * Schedule generator for tests and benchmarks.
 *
 * Produces one teacher's timetable as a list of sessions that satisfy every
 * rule the application enforces: each lasts between the minimum and maximum
 * permitted duration, and no two overlap. Gaps of zero are generated on
 * purpose, so back-to-back sessions, the boundary case most likely to expose an
 * off-by-one error, appear throughout.
 *
 * Randomness comes from a seeded generator rather than Math.random, so a given
 * seed always produces the same schedule. Any result from a test or a benchmark
 * can therefore be reproduced exactly.
 *
 * This module is development tooling. The application never loads it.
 *
 * @file    app_api/tools/benchmark/scheduleGenerator.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const {
    MAX_SESSION_DURATION_MS,
    MIN_SESSION_DURATION_MS
} = require('../../models/classSession');

const MINUTE_MS = 60 * 1000;

/** Fixed starting point, so generated schedules do not depend on the clock. */
const SCHEDULE_ORIGIN_MS = Date.UTC(2023, 0, 2, 8, 0, 0);

/**
 * Mulberry32: a small, fast, seedable pseudo-random generator.
 *
 * @param   {number} seed - Any 32-bit integer.
 * @returns {() => number} A function returning floats in [0, 1).
 */
const createRandom = (seed) => {
    let state = seed >>> 0;
    return () => {
        state = (state + 0x6D2B79F5) >>> 0;
        let t = state;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
};

/** Random whole number of minutes in [min, max], inclusive. */
const randomMinutes = (random, min, max) => min + Math.floor(random() * (max - min + 1));

/**
 * Generates a valid, non-overlapping schedule sorted by start time.
 *
 * @param   {number} count - Number of sessions.
 * @param   {object} [options]
 * @param   {number} [options.seed=1]         - Seed for reproducibility.
 * @param   {number} [options.maxGapMinutes=180] - Largest gap between sessions.
 * @returns {{ startTime: number, endTime: number }[]} Times in milliseconds.
 */
const generateSchedule = (count, { seed = 1, maxGapMinutes = 180 } = {}) => {
    const random = createRandom(seed);
    const minMinutes = MIN_SESSION_DURATION_MS / MINUTE_MS;
    const maxMinutes = MAX_SESSION_DURATION_MS / MINUTE_MS;

    const sessions = new Array(count);
    let cursor = SCHEDULE_ORIGIN_MS;

    for (let i = 0; i < count; i += 1) {
        // Roughly one gap in five is zero, producing back-to-back sessions.
        const gap = random() < 0.2 ? 0 : randomMinutes(random, 1, maxGapMinutes);
        const start = cursor + gap * MINUTE_MS;
        const end = start + randomMinutes(random, minMinutes, maxMinutes) * MINUTE_MS;
        sessions[i] = { startTime: start, endTime: end };
        cursor = end;
    }

    return sessions;
};

/**
 * Generates a valid proposed session somewhere across the schedule's span,
 * including slightly beyond its final session.
 */
const randomProposal = (random, schedule) => {
    const first = schedule[0].startTime;
    const last = schedule[schedule.length - 1].endTime;
    const span = last - first + 24 * 60 * MINUTE_MS;
    const start = first + Math.floor(random() * span / MINUTE_MS) * MINUTE_MS;
    const minutes = randomMinutes(
        random,
        MIN_SESSION_DURATION_MS / MINUTE_MS,
        MAX_SESSION_DURATION_MS / MINUTE_MS
    );
    return { startTime: start, endTime: start + minutes * MINUTE_MS };
};

/**
 * Generates a proposal near the end of the schedule.
 *
 * This is the realistic case, since a school books upcoming lessons rather
 * than past ones, and it is the worst case for the unbounded query, which must
 * walk almost the entire history to reach it.
 */
const forwardProposal = (random, schedule) => {
    const last = schedule[schedule.length - 1];
    const offset = Math.floor(random() * 6 * 60) * MINUTE_MS - 3 * 60 * MINUTE_MS;
    const start = last.startTime + offset;
    const minutes = randomMinutes(
        random,
        MIN_SESSION_DURATION_MS / MINUTE_MS,
        MAX_SESSION_DURATION_MS / MINUTE_MS
    );
    return { startTime: start, endTime: start + minutes * MINUTE_MS };
};

module.exports = {
    MINUTE_MS,
    createRandom,
    generateSchedule,
    randomProposal,
    forwardProposal
};
