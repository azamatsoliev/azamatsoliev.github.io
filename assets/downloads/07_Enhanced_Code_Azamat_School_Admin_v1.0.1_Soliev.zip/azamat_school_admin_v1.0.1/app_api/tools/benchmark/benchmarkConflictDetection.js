/**
 * Conflict-detection benchmark.
 *
 * Measures how much work each strategy does as a teacher's history grows,
 * which is the evidence behind the complexity claims in
 * app_api/scheduling/conflictDetection.js.
 *
 * Two modes:
 *
 *   npm run bench
 *       In-memory. Runs anywhere, needs no database. Counts the sessions each
 *       strategy examines on schedules of increasing size.
 *
 *   npm run bench:mongo
 *       Against a local MongoDB. Reports MongoDB's own execution statistics,
 *       including how many index keys and documents it examined, so the result
 *       comes from the database rather than from a model of it. Uses a separate
 *       database named azamat_school_benchmark, which it creates and then
 *       deletes; the application's own database is never touched.
 *
 * This module is development tooling. The application never loads it.
 *
 * @file    app_api/tools/benchmark/benchmarkConflictDetection.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

require('dotenv').config({ quiet: true });

const {
    createRandom,
    generateSchedule,
    randomProposal,
    forwardProposal
} = require('./scheduleGenerator');
const { naiveScan, unboundedIndexScan, boundedIndexScan } = require('./strategies');

const SEED = 20260921;

// ---------------------------------------------------------------------------
// Shared formatting
// ---------------------------------------------------------------------------

const fmtInt = (value) => Math.round(value).toLocaleString('en-US');
const fmtMs = (value) => value.toFixed(value < 1 ? 4 : 2);
const pad = (text, width) => String(text).padStart(width);

const printTable = (headers, rows, widths) => {
    console.log(headers.map((h, i) => pad(h, widths[i])).join('  '));
    console.log(widths.map((w) => '-'.repeat(w)).join('  '));
    rows.forEach((row) => console.log(row.map((cell, i) => pad(cell, widths[i])).join('  ')));
};

// ---------------------------------------------------------------------------
// In-memory mode
// ---------------------------------------------------------------------------

/** Runs one strategy over every proposal and summarizes the work done. */
const measure = (strategy, schedule, proposals) => {
    let examined = 0;
    let conflicts = 0;
    let maxCandidates = 0;
    const started = process.hrtime.bigint();

    proposals.forEach((p) => {
        const outcome = strategy(schedule, p.startTime, p.endTime);
        examined += outcome.examined;
        if (outcome.conflict) {
            conflicts += 1;
        }
        if (outcome.candidates !== undefined) {
            maxCandidates = Math.max(maxCandidates, outcome.candidates);
        }
    });

    const elapsedMs = Number(process.hrtime.bigint() - started) / 1e6;
    return {
        avgExamined: examined / proposals.length,
        avgMs: elapsedMs / proposals.length,
        conflicts,
        maxCandidates
    };
};

const runInMemory = () => {
    const sizes = [1000, 10000, 100000, 1000000];
    const queriesPerSize = 200;

    console.log('\nConflict detection: in-memory model');
    console.log(`Seed ${SEED}. ${queriesPerSize} forward-booking checks per size.\n`);

    const rows = [];
    let agreementFailures = 0;
    let largestK = 0;

    sizes.forEach((n) => {
        const schedule = generateSchedule(n, { seed: SEED });
        const random = createRandom(SEED + n);
        const proposals = Array.from({ length: queriesPerSize }, () => forwardProposal(random, schedule));

        const naive = measure(naiveScan, schedule, proposals);
        const unbounded = measure(unboundedIndexScan, schedule, proposals);
        const bounded = measure(boundedIndexScan, schedule, proposals);

        // All three must reach the same verdict on every proposal.
        if (naive.conflicts !== unbounded.conflicts || naive.conflicts !== bounded.conflicts) {
            agreementFailures += 1;
        }
        largestK = Math.max(largestK, bounded.maxCandidates);

        rows.push([
            fmtInt(n),
            fmtInt(naive.avgExamined),
            fmtInt(unbounded.avgExamined),
            bounded.avgExamined.toFixed(1),
            fmtMs(naive.avgMs),
            fmtMs(bounded.avgMs),
            `${naive.conflicts}/${queriesPerSize}`
        ]);
    });

    printTable(
        ['n', 'naive examined', 'unbounded examined', 'bounded examined',
            'naive ms', 'bounded ms', 'conflicts'],
        rows,
        [9, 14, 18, 16, 9, 10, 9]
    );

    // A second workload spreads proposals across the whole history.
    const n = 100000;
    const schedule = generateSchedule(n, { seed: SEED });
    const random = createRandom(SEED + 7);
    const spread = Array.from({ length: 2000 }, () => randomProposal(random, schedule));
    const unbounded = measure(unboundedIndexScan, schedule, spread);
    const bounded = measure(boundedIndexScan, schedule, spread);

    console.log(`\nProposals spread across a ${fmtInt(n)}-session history (2,000 checks):`);
    console.log(`  unbounded examined on average: ${fmtInt(unbounded.avgExamined)}`
        + '  (about half the history, as expected)');
    console.log(`  bounded examined on average:   ${bounded.avgExamined.toFixed(1)}`);

    console.log(`\nLargest candidate set seen (k): ${largestK}  (proven upper bound: 32)`);
    console.log(agreementFailures === 0
        ? 'All three strategies agreed on every verdict.'
        : `WARNING: strategies disagreed at ${agreementFailures} size(s).`);
    console.log('');
};

// ---------------------------------------------------------------------------
// MongoDB mode
// ---------------------------------------------------------------------------

/** Finds the first value of a property anywhere in a nested explain document. */
const findInPlan = (node, key) => {
    if (!node || typeof node !== 'object') {
        return undefined;
    }
    if (Object.prototype.hasOwnProperty.call(node, key)) {
        return node[key];
    }
    for (const value of Object.values(node)) {
        const found = findInPlan(value, key);
        if (found !== undefined) {
            return found;
        }
    }
    return undefined;
};

const runMongo = async () => {
    const mongoose = require('mongoose');
    const ClassSession = require('../../models/classSession');
    const {
        buildCandidateFilter,
        findFirstOverlap
    } = require('../../scheduling/conflictDetection');

    const { TOOL_DATABASES, toolDatabaseName, toolDbUri } = require('../../config/database');
    const databaseName = toolDatabaseName(TOOL_DATABASES.BENCHMARK);
    const uri = toolDbUri(TOOL_DATABASES.BENCHMARK);
    const INDEX = { teacherId: 1, active: 1, startTime: 1 };
    const sizes = (process.argv.find((a) => a.startsWith('--sizes=')) || '--sizes=1000,10000,50000')
        .split('=')[1].split(',').map(Number).filter((v) => v > 0);

    console.log(`\nConflict detection: MongoDB execution statistics (${uri})\n`);
    await mongoose.connect(uri);

    const rows = [];

    try {
        for (const n of sizes) {
            await mongoose.connection.dropDatabase();
            await ClassSession.createIndexes();

            const teacherId = new mongoose.Types.ObjectId();
            const schedule = generateSchedule(n, { seed: SEED });
            const batch = 5000;
            for (let i = 0; i < n; i += batch) {
                const docs = schedule.slice(i, i + batch).map((s, j) => ({
                    title: `Lesson ${i + j + 1}`,
                    teacherId,
                    startTime: new Date(s.startTime),
                    endTime: new Date(s.endTime),
                    ratePerClass: 25
                }));
                await ClassSession.insertMany(docs, { ordered: false });
            }

            const proposal = forwardProposal(createRandom(SEED + n), schedule);
            const start = proposal.startTime;
            const end = proposal.endTime;

            // Strategy 1: fetch the teacher's whole history.
            const naiveFilter = { teacherId, active: true };
            const naiveExplain = await ClassSession.find(naiveFilter).explain('executionStats');

            // Strategy 2: the unbounded overlap query, forced onto the same index.
            const unboundedFilter = {
                teacherId,
                active: true,
                startTime: { $lt: new Date(end) },
                endTime: { $gt: new Date(start) }
            };
            const unboundedExplain = await ClassSession.find(unboundedFilter)
                .hint(INDEX).explain('executionStats');

            // Strategy 3: the production query, left to the query planner.
            const boundedFilter = buildCandidateFilter({ teacherId, start, end });
            const boundedExplain = await ClassSession.find(boundedFilter).explain('executionStats');

            // Confirm the production path reaches the same verdict as the naive one.
            const all = await ClassSession.find(naiveFilter).lean();
            const candidates = await ClassSession.find(boundedFilter).sort({ startTime: 1 }).lean();
            const naiveVerdict = all.some((s) => findFirstOverlap([s], start, end));
            const boundedVerdict = Boolean(findFirstOverlap(candidates, start, end));

            const stats = (ex) => ex.executionStats || {};
            rows.push([
                fmtInt(n),
                fmtInt(stats(naiveExplain).totalKeysExamined),
                fmtInt(stats(unboundedExplain).totalKeysExamined),
                fmtInt(stats(boundedExplain).totalKeysExamined),
                fmtInt(stats(boundedExplain).totalDocsExamined),
                findInPlan(boundedExplain.queryPlanner, 'indexName') || '(none)',
                naiveVerdict === boundedVerdict ? 'yes' : 'NO'
            ]);
        }
    } finally {
        await mongoose.connection.dropDatabase();
        await mongoose.connection.close();
    }

    printTable(
        ['n', 'naive keys', 'unbounded keys', 'bounded keys', 'bounded docs',
            'index chosen by planner', 'verdicts agree'],
        rows,
        [9, 11, 15, 13, 13, 30, 15]
    );
    console.log('\nKeys and documents are MongoDB\'s own totalKeysExamined and');
    console.log('totalDocsExamined figures from explain("executionStats").');
    console.log(`The ${databaseName} database has been deleted.\n`);
};

// ---------------------------------------------------------------------------

if (process.argv.includes('--mongo')) {
    runMongo().catch((error) => {
        console.error('\nBenchmark failed:', error.message);
        console.error('Is MongoDB running? See the troubleshooting section of the run guide.\n');
        process.exit(1);
    });
} else {
    runInMemory();
}
