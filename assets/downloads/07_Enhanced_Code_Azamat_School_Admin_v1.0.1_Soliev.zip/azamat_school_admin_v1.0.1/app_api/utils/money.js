/**
 * Money handling.
 *
 * Every monetary calculation in the platform is carried out in whole cents.
 *
 * Why: JavaScript numbers and MongoDB doubles are binary floating point, which
 * cannot represent most decimal fractions exactly. Adding the two lesson rates
 * 12.10 and 12.20 directly gives 24.299999999999997, not 24.30. Across a
 * report summing hundreds of lessons and payments, those errors accumulate, and
 * worse, a balance that should be exactly zero can come out a tiny distance
 * from zero, which then fails an equality test against zero. The code review
 * checklist asks whether code systematically prevents rounding errors; this is
 * the systematic answer.
 *
 * The approach: stored amounts are validated to have at most two decimal
 * places, so each is a whole number of cents. Inside an aggregation pipeline,
 * each amount is multiplied by 100 and rounded to the nearest integer before
 * any summing. Integers are represented exactly in a double up to 2^53, far
 * beyond any school's finances, so every sum is exact. The result is divided by
 * 100 only at the very end, for display.
 *
 * MongoDB's Decimal128 type would be the alternative for a new system. It was
 * not chosen here because it would mean migrating every stored rate and amount,
 * and changing how they are serialized to the interface. Converting to cents at
 * the calculation boundary gives exact results with no migration.
 *
 * @file    app_api/utils/money.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

/** Cents in one currency unit. */
const CENTS_PER_UNIT = 100;

/**
 * Reports whether a value is a whole number of cents, that is, has at most two
 * decimal places. Used as a schema validator for every stored amount.
 *
 * The tolerance absorbs the representation error of the multiplication itself:
 * 0.29 * 100 is 28.999999999999996, which is a whole number of cents, while
 * 0.295 * 100 is 29.5, which is not.
 *
 * @param   {number} value - A monetary amount.
 * @returns {boolean} True for absent values and for amounts in whole cents.
 */
const isWholeCents = (value) => {
    if (value === null || value === undefined) {
        return true;
    }
    if (typeof value !== 'number' || !Number.isFinite(value)) {
        return false;
    }
    const scaled = value * CENTS_PER_UNIT;
    return Math.abs(scaled - Math.round(scaled)) < 1e-6;
};

/**
 * Builds an aggregation expression converting an amount field to integer cents.
 *
 * @param   {string} fieldPath - A field reference, such as '$amount'.
 * @returns {object} A MongoDB expression.
 */
const centsExpression = (fieldPath) => ({
    $round: [{ $multiply: [fieldPath, CENTS_PER_UNIT] }, 0]
});

/**
 * Converts integer cents to currency units for output.
 *
 * @param   {number} cents - A whole number of cents.
 * @returns {number} The amount in currency units, exact to two decimal places.
 */
const fromCents = (cents) => Math.round(Number(cents) || 0) / CENTS_PER_UNIT;

/**
 * Formats integer cents as a fixed two-decimal string, such as "24.30".
 *
 * @param   {number} cents - A whole number of cents.
 * @returns {string} The formatted amount.
 */
const formatCents = (cents) => {
    const whole = Math.round(Number(cents) || 0);
    const sign = whole < 0 ? '-' : '';
    const absolute = Math.abs(whole);
    const units = Math.floor(absolute / CENTS_PER_UNIT);
    const remainder = String(absolute % CENTS_PER_UNIT).padStart(2, '0');
    return `${sign}${units}.${remainder}`;
};

/** Validator definition reused by every monetary schema field. */
const wholeCentsValidator = {
    validator: isWholeCents,
    message: 'Amounts may have at most two decimal places.'
};

module.exports = {
    CENTS_PER_UNIT,
    isWholeCents,
    centsExpression,
    fromCents,
    formatCents,
    wholeCentsValidator
};
