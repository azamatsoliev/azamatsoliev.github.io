/**
 * Keyed mutex.
 *
 * Runs asynchronous tasks one at a time per key, while tasks under different
 * keys run freely in parallel.
 *
 * Why this exists: a conflict check followed by a save is a check-then-act
 * sequence. Node handles many requests concurrently, so two requests booking
 * the same teacher into overlapping slots can both run their check before
 * either saves. Both see a clear schedule, both save, and the schedule now
 * contains exactly the overlap the check exists to prevent. Serializing the
 * check and the save per teacher removes that window. Bookings for different
 * teachers cannot conflict, so they are never made to wait for each other.
 *
 * Data structure: a Map from each key to the promise at the tail of that key's
 * queue. Acquiring appends a new promise to the tail, and a task starts only
 * once the promise before it has settled, so tasks run in arrival order. When
 * the last task under a key finishes, its entry is removed, keeping memory
 * proportional to the number of keys currently in use rather than to the
 * number ever seen.
 *
 * Complexity: acquiring and releasing are O(1) Map operations. A task waits
 * only for tasks already queued under the same key.
 *
 * Limitation: the lock lives in this process's memory, which is sufficient
 * while the API runs as a single Node process, as it does here. If the API were
 * scaled across several processes or machines, each would hold its own lock and
 * the guarantee would no longer span them. The replacement at that point is a
 * database-level mechanism, such as a transaction on a replica set or a lock
 * document updated atomically.
 *
 * @file    app_api/utils/keyedMutex.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

class KeyedMutex {

    constructor() {
        /** @type {Map<string, Promise<void>>} Tail of each key's queue. */
        this.tails = new Map();
    }

    /**
     * Runs a task once every earlier task under the same key has finished.
     *
     * The lock is released however the task ends, including when it throws, so
     * a failed request can never leave a teacher's schedule locked.
     *
     * @template T
     * @param   {*}                key  - Identifies the resource, e.g. a teacher id.
     * @param   {() => Promise<T>} task - The work to run exclusively.
     * @returns {Promise<T>} Whatever the task returns.
     */
    async runExclusive(key, task) {
        const normalizedKey = String(key);
        const previous = this.tails.get(normalizedKey) || Promise.resolve();

        let release;
        const current = new Promise((resolve) => { release = resolve; });
        const tail = previous.then(() => current);
        this.tails.set(normalizedKey, tail);

        try {
            await previous;
            return await task();
        } finally {
            release();

            // Remove the entry only if no later task has queued behind this one.
            if (this.tails.get(normalizedKey) === tail) {
                this.tails.delete(normalizedKey);
            }
        }
    }

    /** Number of keys that currently have a running or queued task. */
    get size() {
        return this.tails.size;
    }
}

module.exports = KeyedMutex;
