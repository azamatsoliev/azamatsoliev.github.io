/**
 * User administration controller.
 *
 * Handles the account operations that cannot be produced by the generic
 * controller factory: creating a staff account, listing accounts, and changing
 * another account's role. All three are owner only.
 *
 * Roles are set through these narrow endpoints rather than as a writable field
 * on the user record, so an account can never raise its own access, either when
 * it is created or by updating its own profile later.
 *
 * Changed for the final release: accounts are created here, by an owner, with
 * the role and teacher link stated at creation. This replaces public
 * self-registration, which let anyone on the network create an account. A
 * teacher link is now checked to point at an active teacher record before it is
 * stored, on creation and on a role change alike.
 *
 * @file    app_api/controllers/users.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const mongoose = require('mongoose');
const User = require('../models/user');
const Teacher = require('../models/teacher');
const { isValidRole, ROLES } = require('../config/roles');

/** Minimum acceptable password length. */
const MIN_PASSWORD_LENGTH = User.MIN_PASSWORD_LENGTH;

/** Fields of an account that are safe to return. Credential material never is. */
const toAccountSummary = (user) => ({
    id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    teacherId: user.teacherId
});

/**
 * Works out the teacher link to store for an account.
 *
 * Only a teacher account carries a link; any other role is stored without one.
 * A supplied link must be an identifier of an active teacher record. Without
 * this check, a mistyped or invented identifier would be saved, and the
 * account's view would silently be scoped to a teacher who does not exist.
 *
 * @param   {string} role      - The role being given to the account.
 * @param   {*}      teacherId - The teacher identifier supplied, if any.
 * @returns {Promise<{teacherId: (string|null)}|{error: {status: number, message: string}}>}
 */
const resolveTeacherLink = async (role, teacherId) => {
    if (role !== ROLES.TEACHER || teacherId === undefined || teacherId === null || teacherId === '') {
        return { teacherId: null };
    }

    if (typeof teacherId !== 'string' || !mongoose.isValidObjectId(teacherId)) {
        return { error: { status: 400, message: 'The teacher link is not a valid identifier.' } };
    }

    const exists = await Teacher.exists({ _id: teacherId, active: true });

    if (!exists) {
        return { error: { status: 400, message: 'The teacher referenced does not exist or is inactive.' } };
    }

    return { teacherId };
};

/**
 * POST /api/users
 * Creates a staff account. Owner only.
 *
 * Returns the new account's details but no token: the person the account is
 * for signs in with their own password.
 */
const createUser = async (req, res) => {
    const { name, email, password, role, teacherId } = req.body || {};

    const isText = (value) => typeof value === 'string' && value.trim() !== '';

    if (!isText(name) || !isText(email) || !isText(password)) {
        return res.status(400).json({ message: 'Name, email and password are all required.' });
    }

    if (password.length < MIN_PASSWORD_LENGTH) {
        return res.status(400).json({
            message: `Password must be at least ${MIN_PASSWORD_LENGTH} characters.`
        });
    }

    if (!isValidRole(role)) {
        return res.status(400).json({ message: 'A valid role is required.' });
    }

    try {
        const link = await resolveTeacherLink(role, teacherId);

        if (link.error) {
            return res.status(link.error.status).json({ message: link.error.message });
        }

        const user = new User({ name: name.trim(), email: email.trim(), role, teacherId: link.teacherId });
        user.setPassword(password);
        await user.save();

        return res.status(201).json(toAccountSummary(user));
    } catch (error) {
        if (error && error.code === 11000) {
            return res.status(409).json({ message: 'An account with that email already exists.' });
        }

        if (error && error.name === 'ValidationError') {
            return res.status(400).json({ message: error.message });
        }

        console.error('[users.create]', error.message);
        return res.status(500).json({ message: 'An unexpected error occurred.' });
    }
};

/**
 * GET /api/users
 * Lists accounts. Owner only. Credential material is never returned.
 */
const listUsers = async (req, res) => {
    try {
        const users = await User.find({}).select('name email role teacherId createdAt');
        return res.status(200).json(users);
    } catch (error) {
        console.error('[users.list]', error.message);
        return res.status(500).json({ message: 'An unexpected error occurred.' });
    }
};

/**
 * PUT /api/users/:id/role
 * Changes an account's role. Owner only.
 *
 * Refuses to let the acting owner change their own role, which would otherwise
 * allow the last owner to demote themselves and leave the school with no
 * account able to promote anyone back.
 */
const setUserRole = async (req, res) => {
    const { role, teacherId } = req.body || {};

    if (!isValidRole(role)) {
        return res.status(400).json({ message: 'A valid role is required.' });
    }

    if (req.auth.id === req.params.id) {
        return res.status(400).json({ message: 'You cannot change your own role.' });
    }

    if (!mongoose.isValidObjectId(req.params.id)) {
        return res.status(404).json({ message: 'Account not found.' });
    }

    try {
        const link = await resolveTeacherLink(role, teacherId);

        if (link.error) {
            return res.status(link.error.status).json({ message: link.error.message });
        }

        const user = await User.findById(req.params.id);

        if (!user) {
            return res.status(404).json({ message: 'Account not found.' });
        }

        user.role = role;

        // A teacher account is only useful when linked to a teacher record,
        // since that link is what narrows their view to their own sessions.
        // Leaving the link out on a change to teacher keeps any existing one.
        if (role === ROLES.TEACHER && link.teacherId) {
            user.teacherId = link.teacherId;
        }

        if (role !== ROLES.TEACHER) {
            user.teacherId = null;
        }

        await user.save();

        return res.status(200).json(toAccountSummary(user));
    } catch (error) {
        console.error('[users.setRole]', error.message);
        return res.status(500).json({ message: 'An unexpected error occurred.' });
    }
};

module.exports = { createUser, listUsers, setUserRole, resolveTeacherLink, MIN_PASSWORD_LENGTH };
