/**
 * Reports controller.
 *
 * Validates report requests and returns the results as JSON or as a CSV file.
 * Which roles may reach each report is decided by the routes; this controller
 * decides what each request is allowed to ask for.
 *
 * Every response is sent with Cache-Control: no-store. These are financial and
 * attendance records, and they should not remain in a browser or proxy cache
 * after the person who requested them has signed out.
 *
 * @file    app_api/controllers/reports.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const { ROLES } = require('../config/roles');
const { parseMonth, parseYear, monthLabel, ReportParameterError } = require('../reports/periods');
const { toCsv } = require('../reports/csv');

/** A refusal that is not a malformed request, reported with its own status. */
class ReportAccessError extends Error {
    constructor(status, message) {
        super(message);
        this.name = 'ReportAccessError';
        this.status = status;
    }
}

/** A MongoDB identifier: exactly 24 hexadecimal characters. */
const OBJECT_ID_PATTERN = /^[a-f0-9]{24}$/i;

/**
 * Decides whose attendance sheet a request may see.
 *
 * A teacher always receives their own sheet. The identifier is taken from the
 * signed token, and any teacherId in the query string is deliberately ignored,
 * so no request a teacher can construct will show them a colleague's sessions.
 * An owner, who has no teaching record of their own, names the teacher.
 */
const resolveTeacherId = (user, query) => {
    if (user.role === ROLES.TEACHER) {
        if (!user.teacherId) {
            throw new ReportAccessError(403, 'Your account is not linked to a teacher record.');
        }
        return user.teacherId;
    }

    const requested = query.teacherId;
    if (typeof requested !== 'string' || !OBJECT_ID_PATTERN.test(requested)) {
        throw new ReportParameterError('Choose a teacher to view their attendance sheet.');
    }
    return requested;
};

/** Sends a report, mapping known errors to their statuses and hiding the rest. */
const respond = async (res, produce) => {
    res.set('Cache-Control', 'no-store');
    try {
        return res.status(200).json(await produce());
    } catch (error) {
        if (error instanceof ReportParameterError || error instanceof ReportAccessError) {
            return res.status(error.status).json({ message: error.message });
        }
        console.error('[reports]', error);
        return res.status(500).json({ message: 'The report could not be produced.' });
    }
};

/** Columns of the monthly revenue export. */
const REVENUE_CSV_COLUMNS = [
    { header: 'Last name', key: 'lastName' },
    { header: 'First name', key: 'firstName' },
    { header: 'Email', key: 'email' },
    { header: 'Payments', key: 'payments', type: 'integer' },
    { header: 'Collected', key: 'collectedCents', type: 'cents' }
];

/** Converts a currency amount produced by the service back to exact cents. */
const toCents = (amount) => Math.round(Number(amount) * 100);

/**
 * Creates the report handlers.
 *
 * @param   {object} service - A report service.
 * @returns {object} Express handlers.
 */
const createReportsController = (service) => ({
    balances: (req, res) => respond(res, () => service.studentBalances()),

    revenue: (req, res) => respond(res, () => service.revenueByStudent(parseMonth(req.query.month))),

    revenueByMonth: (req, res) => respond(res, () => service.revenueByMonth(parseYear(req.query.year))),

    classes: (req, res) => respond(res, () => service.classSummary(parseMonth(req.query.month))),

    attendanceSheet: (req, res) => respond(res, () => service.attendanceSheet({
        teacherId: resolveTeacherId(req.auth, req.query),
        period: parseMonth(req.query.month)
    })),

    /** The monthly revenue report as a CSV file for bookkeeping. */
    revenueCsv: async (req, res) => {
        res.set('Cache-Control', 'no-store');
        try {
            const period = parseMonth(req.query.month);
            const report = await service.revenueByStudent(period);

            const rows = report.rows.map((row) => ({ ...row, collectedCents: toCents(row.collected) }));
            rows.push({
                lastName: 'TOTAL',
                payments: report.totals.payments,
                collectedCents: toCents(report.totals.collected)
            });

            res.set('Content-Type', 'text/csv; charset=utf-8');
            // The month has already been validated as YYYY-MM, so it is safe in a header.
            res.set('Content-Disposition', `attachment; filename="revenue-${monthLabel(period)}.csv"`);
            return res.status(200).send(toCsv(REVENUE_CSV_COLUMNS, rows));
        } catch (error) {
            if (error instanceof ReportParameterError) {
                return res.status(400).json({ message: error.message });
            }
            console.error('[reports.revenueCsv]', error);
            return res.status(500).json({ message: 'The report could not be produced.' });
        }
    }
});

module.exports = { createReportsController, resolveTeacherId, ReportAccessError };
