/**
 * Generic CRUD controller factory.
 *
 * Produces the five request handlers for any Mongoose model from a
 * configuration object, replacing what would otherwise be five near-identical
 * controller files for the five entities this platform manages.
 *
 * The original application repeated the same shape in every controller
 * function: authorize, run a query, branch on an empty result, return a status
 * code. That pattern is implemented once here. Anything specific to a
 * particular entity is supplied as configuration rather than written into this
 * module, so the factory has no knowledge of any individual model.
 *
 * Three authorization concerns are handled, and they are deliberately distinct:
 *
 *   1. Role       - may this kind of account perform this action at all?
 *   2. Scope      - which records may it perform the action on?
 *   3. Fields     - which properties of a record may it write?
 *
 * Checking only the first is a common and serious mistake. A teacher who
 * passes a role check would otherwise receive every teacher's class sessions,
 * because the role condition is satisfied even though the records belong to
 * somebody else. The scope rule closes that path.
 *
 * Changed for the final release: an entity may also limit which fields a role
 * receives when it reads, through projectionByRole. Teachers use this to read
 * student names, and nothing more, when they record attendance.
 *
 * @file    app_api/controllers/crudControllerFactory.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const { isAuthorized } = require('../config/roles');
const KeyedMutex = require('../utils/keyedMutex');

/** HTTP status codes used by the generated handlers. */
const STATUS = Object.freeze({
    OK: 200,
    CREATED: 201,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    CONFLICT: 409,
    SERVER_ERROR: 500
});

/**
 * Resolves the record-level filter that applies to a request.
 *
 * A configuration without a scope rule places no additional restriction, which
 * is correct for roles allowed to see every record of that type.
 *
 * @param   {object}   user      - The verified token payload.
 * @param   {Function} scopeRule - Optional rule returning a Mongoose filter.
 * @returns {Promise<object>} A filter fragment merged into every query.
 */
const resolveScope = async (user, scopeRule) => {
    if (typeof scopeRule !== 'function') {
        return {};
    }
    const scope = await scopeRule(user);
    return scope || {};
};

/**
 * Copies only the permitted properties out of a request body.
 *
 * Passing a request body straight into a model lets a caller set any field the
 * schema happens to define, including ones that control access or state. This
 * restricts writes to an explicit list, so adding a sensitive field to a schema
 * does not silently make it client-writable.
 *
 * @param   {object}   body           - The raw request body.
 * @param   {string[]} writableFields - Properties a client may set.
 * @returns {object} A new object containing only permitted properties.
 */
const pickWritableFields = (body, writableFields) => {
    const source = body && typeof body === 'object' ? body : {};
    return writableFields.reduce((accumulator, field) => {
        if (Object.prototype.hasOwnProperty.call(source, field)) {
            accumulator[field] = source[field];
        }
        return accumulator;
    }, {});
};

/**
 * Reports whether a value contains a MongoDB operator anywhere inside it.
 *
 * MongoDB treats any object with a key beginning with "$" as a query operator.
 * A request body is supposed to contain plain values, so an operator inside one
 * can only be an attempt at NoSQL injection. For example, a body containing
 * "teacherId": { "$ne": null } would turn the referenced-record check into
 * findOne({ _id: { $ne: null } }), which matches any teacher at all, and the
 * check would pass without the request ever naming a real one.
 *
 * Keys containing a dot are refused for the same reason, since MongoDB reads
 * them as paths into nested fields.
 *
 * Runs in time proportional to the size of the body, which the JSON parser
 * already bounds.
 *
 * @param   {*} value - A request body value.
 * @returns {boolean} True when an operator or path key is present.
 */
const containsOperatorKey = (value) => {
    if (Array.isArray(value)) {
        return value.some(containsOperatorKey);
    }
    if (value && typeof value === 'object' && !(value instanceof Date)) {
        return Object.keys(value).some((key) =>
            key.startsWith('$') || key.includes('.') || containsOperatorKey(value[key]));
    }
    return false;
};

/**
 * Translates a thrown error into an appropriate response.
 *
 * Schema validation problems are the caller's fault and answer 400. Anything
 * unexpected answers 500 with a generic message, because error text can reveal
 * database structure. The detail is logged server-side instead.
 *
 * @param {object} res    - Express response.
 * @param {Error}  error  - The error that was thrown.
 * @param {string} action - Label used in the server-side log entry.
 */
const handleError = (res, error, action) => {
    if (error && (error.name === 'ValidationError' || error.name === 'CastError')) {
        return res.status(STATUS.BAD_REQUEST).json({ message: error.message });
    }

    if (error && error.code === 11000) {
        return res.status(STATUS.CONFLICT).json({ message: 'That record already exists.' });
    }

    console.error(`[${action}]`, error);
    return res.status(STATUS.SERVER_ERROR).json({ message: 'An unexpected error occurred.' });
};

/**
 * Runs the configured pre-save checks in order.
 *
 * This is the extension point that keeps the factory generic. A model needing a
 * rule of its own supplies it through configuration instead of having a special
 * case written into this file. The scheduling conflict check planned for the
 * algorithms enhancement attaches here without this module changing.
 *
 * @param   {Function[]} checks  - Check functions.
 * @param   {object}     data    - The data about to be written.
 * @param   {object}     context - Request context: user, model, existing record.
 * @returns {Promise<object|null>} A failure descriptor, or null when all pass.
 */
const runPreSaveChecks = async (checks, data, context) => {
    for (const check of checks) {
        const failure = await check(data, context);
        if (failure) {
            return failure;
        }
    }
    return null;
};

/**
 * Builds the CRUD handlers for one model.
 *
 * @param   {object} model  - A Mongoose model.
 * @param   {object} config - Entity configuration.
 * @param   {string} config.name - Entity name, used in log messages.
 * @param   {object} config.permissions - Roles allowed per action.
 * @param   {string[]} config.writableFields - Properties a client may set.
 * @param   {Function} [config.scopeRule] - Record-level filter for the caller.
 * @param   {boolean} [config.softDelete] - Mark inactive instead of removing.
 * @param   {Function[]} [config.preSaveChecks] - Rules run before create/update.
 * @param   {Function} [config.lockKey] - Given the incoming data and context,
 *          returns a key under which the pre-save checks and the write run as
 *          one uninterrupted step. Required whenever a check's verdict depends
 *          on other records, so that two concurrent writes cannot both pass
 *          the check and together produce the state it forbids.
 * @param   {object} [config.projectionByRole] - Fields returned to a role on
 *          reads, as a Mongoose select string keyed by role name. A role not
 *          listed receives the full record. Matched on the exact role rather
 *          than through inheritance, so a broader role is never narrowed by a
 *          projection meant for a role it inherits.
 * @returns {object} Express handlers: list, getOne, create, update, remove.
 */
const createCrudController = (model, config) => {
    const {
        name,
        permissions,
        writableFields,
        scopeRule = null,
        softDelete = false,
        preSaveChecks = [],
        lockKey = null,
        projectionByRole = null
    } = config;

    /**
     * Returns the fields a role may read, or null when it may read them all.
     *
     * @param   {object} user - The verified token payload.
     * @returns {string|null} A Mongoose select string, or null.
     */
    const projectionFor = (user) => (
        projectionByRole && Object.prototype.hasOwnProperty.call(projectionByRole, user.role)
            ? projectionByRole[user.role]
            : null
    );

    /** Applies a projection to a query when one is given. */
    const withProjection = (query, projection) => (projection ? query.select(projection) : query);

    // One lock table per controller. Only entities that configure a lockKey use it.
    const locks = new KeyedMutex();

    /**
     * Runs the checks and the write for one request, under the entity's lock
     * when one is configured. Without a lock the two steps simply run in order.
     */
    const checkedWrite = async (data, context, write) => {
        const run = async () => {
            const failure = await runPreSaveChecks(preSaveChecks, data, context);
            if (failure) {
                return { failure };
            }
            return { result: await write() };
        };

        const key = typeof lockKey === 'function' ? lockKey(data, context) : null;
        return key ? locks.runExclusive(key, run) : run();
    };

    /**
     * Verifies the caller may perform an action, answering the response
     * directly when they may not.
     *
     * @returns {object|null} The verified user, or null when already answered.
     */
    const authorize = (req, res, action) => {
        const user = req.auth;

        if (!user) {
            res.status(STATUS.UNAUTHORIZED).json({ message: 'Authentication required.' });
            return null;
        }

        if (!isAuthorized(user.role, permissions[action] || [])) {
            res.status(STATUS.FORBIDDEN).json({ message: 'You do not have permission to do that.' });
            return null;
        }

        return user;
    };

    /** Restricts a query to active records when the entity is soft-deletable. */
    const withActiveFilter = (filter) => (softDelete ? { ...filter, active: true } : filter);

    /**
     * Finds a record the caller is entitled to act on.
     *
     * Returns null both when the record does not exist and when it exists but
     * falls outside the caller's scope. Callers answer 403 in either case, so a
     * response cannot be used to discover whether a record exists.
     */
    const findScopedRecord = async (user, id, projection = null) => {
        const scope = await resolveScope(user, scopeRule);
        return withProjection(model.findOne(withActiveFilter({ ...scope, _id: id })), projection);
    };

    return {
        /** GET / - lists records visible to the caller. */
        list: async (req, res) => {
            const user = authorize(req, res, 'list');
            if (!user) {
                return undefined;
            }

            try {
                const scope = await resolveScope(user, scopeRule);
                const records = await withProjection(model.find(withActiveFilter(scope)), projectionFor(user));
                return res.status(STATUS.OK).json(records);
            } catch (error) {
                return handleError(res, error, `${name}.list`);
            }
        },

        /** GET /:id - returns one record the caller is entitled to see. */
        getOne: async (req, res) => {
            const user = authorize(req, res, 'list');
            if (!user) {
                return undefined;
            }

            try {
                const record = await findScopedRecord(user, req.params.id, projectionFor(user));

                if (!record) {
                    return res.status(STATUS.FORBIDDEN)
                        .json({ message: 'You do not have permission to do that.' });
                }

                return res.status(STATUS.OK).json(record);
            } catch (error) {
                return handleError(res, error, `${name}.getOne`);
            }
        },

        /** POST / - creates a record. */
        create: async (req, res) => {
            const user = authorize(req, res, 'create');
            if (!user) {
                return undefined;
            }

            try {
                const data = pickWritableFields(req.body, writableFields);

                if (containsOperatorKey(data)) {
                    return res.status(STATUS.BAD_REQUEST)
                        .json({ message: 'The request contains a value that is not allowed.' });
                }

                const { failure, result } = await checkedWrite(
                    data,
                    { user, model },
                    () => model.create(data)
                );

                if (failure) {
                    return res.status(failure.status).json({ message: failure.message });
                }

                return res.status(STATUS.CREATED).json(result);
            } catch (error) {
                return handleError(res, error, `${name}.create`);
            }
        },

        /** PUT /:id - updates a record the caller owns or administers. */
        update: async (req, res) => {
            const user = authorize(req, res, 'update');
            if (!user) {
                return undefined;
            }

            try {
                const existing = await findScopedRecord(user, req.params.id);

                if (!existing) {
                    return res.status(STATUS.FORBIDDEN)
                        .json({ message: 'You do not have permission to do that.' });
                }

                const data = pickWritableFields(req.body, writableFields);

                if (containsOperatorKey(data)) {
                    return res.status(STATUS.BAD_REQUEST)
                        .json({ message: 'The request contains a value that is not allowed.' });
                }

                const { failure, result } = await checkedWrite(
                    data,
                    { user, model, existing },
                    () => {
                        Object.assign(existing, data);
                        return existing.save();
                    }
                );

                if (failure) {
                    return res.status(failure.status).json({ message: failure.message });
                }

                return res.status(STATUS.OK).json(result);
            } catch (error) {
                return handleError(res, error, `${name}.update`);
            }
        },

        /** DELETE /:id - withdraws a record, preserving history where configured. */
        remove: async (req, res) => {
            const user = authorize(req, res, 'remove');
            if (!user) {
                return undefined;
            }

            try {
                const existing = await findScopedRecord(user, req.params.id);

                if (!existing) {
                    return res.status(STATUS.FORBIDDEN)
                        .json({ message: 'You do not have permission to do that.' });
                }

                if (softDelete) {
                    existing.active = false;
                    await existing.save();
                    return res.status(STATUS.OK)
                        .json({ message: 'Record deactivated.', id: existing._id });
                }

                await model.deleteOne({ _id: existing._id });
                return res.status(STATUS.OK)
                    .json({ message: 'Record removed.', id: existing._id });
            } catch (error) {
                return handleError(res, error, `${name}.remove`);
            }
        }
    };
};

module.exports = createCrudController;
module.exports.STATUS = STATUS;
module.exports.resolveScope = resolveScope;
module.exports.pickWritableFields = pickWritableFields;
module.exports.containsOperatorKey = containsOperatorKey;
