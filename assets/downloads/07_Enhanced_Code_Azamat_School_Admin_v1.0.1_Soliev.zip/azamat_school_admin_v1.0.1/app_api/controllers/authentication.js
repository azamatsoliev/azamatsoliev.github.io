/**
 * Authentication controller.
 *
 * Handles sign-in. Accounts are created by an owner through POST /api/users;
 * see app_api/controllers/users.js.
 *
 * Changes made during the software design and engineering enhancement:
 *
 *   - Sign-in transparently upgrades a password hash that was stored under the
 *     old work factor. The plain-text password is only available at this moment,
 *     so it is the only point at which an existing credential can be
 *     strengthened without asking the account holder to reset it.
 *
 *   - A failed sign-in no longer returns the raw error object from Passport,
 *     which could disclose whether an address was registered.
 *
 * Changes made for the final release:
 *
 *   - Public self-registration (POST /api/register) was removed. It let anyone
 *     on the network create an account; school staff accounts are now created
 *     by an owner only.
 *
 *   - Credentials must be text. Anything else is refused with 400 before any
 *     work is done.
 *
 *   - A failure to reach the database during sign-in answers 503, telling the
 *     caller the problem is temporary rather than their fault.
 *
 * @file    app_api/controllers/authentication.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const passport = require('passport');

/** Longest email address allowed by the email standard (RFC 5321). */
const MAX_EMAIL_LENGTH = 254;

/** Longest password accepted; far beyond any real password, but bounded. */
const MAX_PASSWORD_LENGTH = 1024;

/**
 * Reports whether a sign-in request carries usable credentials.
 *
 * @param   {*} email    - Value supplied as the email address.
 * @param   {*} password - Value supplied as the password.
 * @returns {boolean} True when both are non-empty text of a sensible length.
 */
const credentialsAreWellFormed = (email, password) =>
    typeof email === 'string' && typeof password === 'string'
    && email.trim() !== '' && password !== ''
    && email.length <= MAX_EMAIL_LENGTH && password.length <= MAX_PASSWORD_LENGTH;

/**
 * POST /api/login
 * Verifies credentials and returns a signed token.
 */
const login = (req, res) => {
    const { email, password } = req.body || {};

    if (!credentialsAreWellFormed(email, password)) {
        return res.status(400).json({ message: 'Email and password are both required.' });
    }

    return passport.authenticate('local', async (error, user) => {
        if (error) {
            console.error('[auth.login]', error.message);
            return res.status(503)
                .json({ message: 'Sign-in is temporarily unavailable. Please try again shortly.' });
        }

        // A single message for every failure. Distinguishing "no such account"
        // from "wrong password" confirms which addresses are registered.
        if (!user) {
            return res.status(401).json({ message: 'Email or password is incorrect.' });
        }

        try {
            // Strengthen a credential still stored at the old work factor.
            if (typeof user.needsRehash === 'function' && user.needsRehash()) {
                user.setPassword(password);
                await user.save();
            }
        } catch (rehashError) {
            // An upgrade failure must not prevent a valid sign-in.
            console.error('[auth.login.rehash]', rehashError.message);
        }

        return res.status(200).json({ token: user.generateJWT() });
    })(req, res);
};

module.exports = { login, credentialsAreWellFormed, MAX_EMAIL_LENGTH, MAX_PASSWORD_LENGTH };
