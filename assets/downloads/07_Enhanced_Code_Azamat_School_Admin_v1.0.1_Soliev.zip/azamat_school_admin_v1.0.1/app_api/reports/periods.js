/**
 * Report periods.
 *
 * Parses the month and year a report is requested for, and converts them into
 * the date boundaries used to filter records.
 *
 * Strict parsing. Parameters arrive from the query string and are treated as
 * untrusted. Only an exact "YYYY-MM" or "YYYY" string is accepted; anything
 * else, including an object, an array, or a string with extra characters, is
 * refused with a 400. That matters because these values end up inside database
 * filters, and a value that is not a plain string could carry a query operator.
 *
 * Two kinds of boundary. The platform stores two different kinds of time, and
 * each must be bucketed into months the same way it was entered:
 *
 *   - A payment date is a calendar date. The browser sends a date-only value
 *     such as "2026-10-01", which JavaScript interprets as midnight UTC. Months
 *     for payments are therefore cut in UTC. Cutting them in local time would,
 *     in any time zone behind UTC, move a payment made on the first of a month
 *     into the previous month.
 *
 *   - A class session start is a date and time of day. The browser sends a value
 *     such as "2026-10-01T09:00", which is interpreted as local time. Months for
 *     sessions are therefore cut in the school's local time.
 *
 * @file    app_api/reports/periods.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

/** Earliest and latest years a report may be requested for. */
const MIN_YEAR = 2000;
const MAX_YEAR = 2100;

/** An error that should be reported to the client as 400 Bad Request. */
class ReportParameterError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ReportParameterError';
        this.status = 400;
    }
}

/** Confirms a year lies within the supported range. */
const assertYearInRange = (year) => {
    if (year < MIN_YEAR || year > MAX_YEAR) {
        throw new ReportParameterError(`The year must be between ${MIN_YEAR} and ${MAX_YEAR}.`);
    }
};

/**
 * Parses a month in the form "YYYY-MM".
 *
 * @param   {*} value - The raw query-string value.
 * @returns {{ year: number, month: number }} Month is 1 to 12.
 * @throws  {ReportParameterError} When the value is missing or malformed.
 */
const parseMonth = (value) => {
    if (typeof value !== 'string' || !/^\d{4}-(0[1-9]|1[0-2])$/.test(value)) {
        throw new ReportParameterError('A month is required in the form YYYY-MM, for example 2026-10.');
    }
    const year = Number(value.slice(0, 4));
    const month = Number(value.slice(5, 7));
    assertYearInRange(year);
    return { year, month };
};

/**
 * Parses a year in the form "YYYY".
 *
 * @param   {*} value - The raw query-string value.
 * @returns {number} The year.
 * @throws  {ReportParameterError} When the value is missing or malformed.
 */
const parseYear = (value) => {
    if (typeof value !== 'string' || !/^\d{4}$/.test(value)) {
        throw new ReportParameterError('A year is required in the form YYYY, for example 2026.');
    }
    const year = Number(value);
    assertYearInRange(year);
    return year;
};

/**
 * Month boundaries in UTC, for calendar-date fields such as a payment date.
 * The range is half-open: from is included, to is not.
 */
const utcMonthRange = ({ year, month }) => ({
    from: new Date(Date.UTC(year, month - 1, 1)),
    to: new Date(Date.UTC(year, month, 1))
});

/** Year boundaries in UTC, for calendar-date fields. */
const utcYearRange = (year) => ({
    from: new Date(Date.UTC(year, 0, 1)),
    to: new Date(Date.UTC(year + 1, 0, 1))
});

/**
 * Month boundaries in the server's local time, for date-and-time fields such as
 * a class session start. The server is expected to run in the school's time
 * zone, which is also the zone those values are entered and stored in.
 */
const localMonthRange = ({ year, month }) => ({
    from: new Date(year, month - 1, 1),
    to: new Date(year, month, 1)
});

/** Formats a parsed month back to "YYYY-MM", for labels and file names. */
const monthLabel = ({ year, month }) => `${year}-${String(month).padStart(2, '0')}`;

module.exports = {
    MIN_YEAR,
    MAX_YEAR,
    ReportParameterError,
    parseMonth,
    parseYear,
    utcMonthRange,
    utcYearRange,
    localMonthRange,
    monthLabel
};
