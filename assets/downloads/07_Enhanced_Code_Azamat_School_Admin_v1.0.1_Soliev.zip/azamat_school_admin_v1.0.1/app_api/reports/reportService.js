/**
 * Report service.
 *
 * Runs the reporting pipelines and shapes their results for the interface:
 * converting cents to currency units, adding totals, filling in empty months,
 * and labeling each session's attendance status.
 *
 * Its dependencies are passed in rather than required directly, which lets the
 * test suite run the real pipelines against an in-memory engine through stub
 * models, and lets the verification tool run them against a real database.
 *
 * @file    app_api/reports/reportService.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const pipelines = require('./pipelines');
const {
    utcMonthRange,
    utcYearRange,
    localMonthRange,
    monthLabel
} = require('./periods');
const { fromCents } = require('../utils/money');

/** Session attendance states shown on a teacher's sheet. */
const SESSION_STATUS = Object.freeze({
    TAKEN: 'Taken',
    NOT_TAKEN: 'Not taken',
    UPCOMING: 'Upcoming'
});

/** Rounds a ratio to four decimal places, or returns null when undefined. */
const ratio = (numerator, denominator) =>
    (denominator === 0 ? null : Math.round((numerator / denominator) * 10000) / 10000);

/** Sums a numeric field across rows. */
const sumOf = (rows, field) => rows.reduce((total, row) => total + (row[field] || 0), 0);

/**
 * Creates the report service.
 *
 * @param   {object}   deps
 * @param   {object}   deps.models - Student, ClassSession, Payment and Attendance models.
 * @param   {Function} [deps.now]  - Returns the current time; injectable for tests.
 * @param   {Function} [deps.castId] - Converts an identifier string to the database's type.
 * @returns {object} Report methods.
 */
const createReportService = ({ models, now = () => new Date(), castId = (id) => id }) => {
    const { Student, ClassSession, Payment, Attendance } = models;

    const collections = {
        students: Student.collection.collectionName,
        classSessions: ClassSession.collection.collectionName,
        payments: Payment.collection.collectionName,
        attendance: Attendance.collection.collectionName
    };

    return {
        /** Outstanding balance per student, for the accountant and owner. */
        async studentBalances() {
            const rows = await Student.aggregate(pipelines.studentBalancesPipeline({ collections }));

            return {
                generatedAt: now(),
                rows: rows.map((row) => ({
                    studentId: row._id,
                    firstName: row.firstName,
                    lastName: row.lastName,
                    email: row.email,
                    withdrawn: row.active !== true,
                    classesAttended: row.classesAttended,
                    billed: fromCents(row.billedCents),
                    paid: fromCents(row.paidCents),
                    outstanding: fromCents(row.outstandingCents)
                })),
                totals: {
                    billed: fromCents(sumOf(rows, 'billedCents')),
                    paid: fromCents(sumOf(rows, 'paidCents')),
                    outstanding: fromCents(sumOf(rows, 'outstandingCents'))
                }
            };
        },

        /** Money received in one month, one row per student. */
        async revenueByStudent(period) {
            const { from, to } = utcMonthRange(period);
            const rows = await Payment.aggregate(
                pipelines.revenueByStudentPipeline({ from, to, collections })
            );

            return {
                month: monthLabel(period),
                rows: rows.map((row) => ({
                    studentId: row.studentId,
                    firstName: row.firstName,
                    lastName: row.lastName,
                    email: row.email,
                    payments: row.payments,
                    collected: fromCents(row.collectedCents)
                })),
                totals: {
                    payments: sumOf(rows, 'payments'),
                    collected: fromCents(sumOf(rows, 'collectedCents'))
                }
            };
        },

        /** Money received in each month of a year; every month is present. */
        async revenueByMonth(year) {
            const { from, to } = utcYearRange(year);
            const groups = await Payment.aggregate(pipelines.revenueByMonthPipeline({ from, to }));
            const byMonth = new Map(groups.map((group) => [group._id, group]));

            const months = Array.from({ length: 12 }, (_, index) => {
                const group = byMonth.get(index + 1);
                return {
                    month: monthLabel({ year, month: index + 1 }),
                    payments: group ? group.payments : 0,
                    collected: fromCents(group ? group.collectedCents : 0)
                };
            });

            return {
                year,
                months,
                totals: {
                    payments: sumOf(groups, 'payments'),
                    collected: fromCents(sumOf(groups, 'collectedCents'))
                }
            };
        },

        /** Attendance and earnings per class in one month, for the owner. */
        async classSummary(period) {
            const { from, to } = localMonthRange(period);
            const rows = await ClassSession.aggregate(
                pipelines.classSummaryPipeline({ from, to, collections })
            );

            const recorded = sumOf(rows, 'recorded');
            const present = sumOf(rows, 'present');

            return {
                month: monthLabel(period),
                rows: rows.map((row) => ({
                    title: row.title,
                    sessions: row.sessions,
                    recorded: row.recorded,
                    present: row.present,
                    attendanceRate: row.attendanceRate,
                    billed: fromCents(row.billedCents)
                })),
                totals: {
                    sessions: sumOf(rows, 'sessions'),
                    recorded,
                    present,
                    attendanceRate: ratio(present, recorded),
                    billed: fromCents(sumOf(rows, 'billedCents'))
                }
            };
        },

        /** One teacher's sessions in one month, with rosters and statuses. */
        async attendanceSheet({ teacherId, period }) {
            const { from, to } = localMonthRange(period);
            const current = now();
            const rows = await ClassSession.aggregate(pipelines.attendanceSheetPipeline({
                teacherId: castId(teacherId), from, to, collections
            }));

            const sessions = rows.map((row) => {
                let status = SESSION_STATUS.NOT_TAKEN;
                if (row.recorded > 0) {
                    status = SESSION_STATUS.TAKEN;
                } else if (new Date(row.startTime) > current) {
                    status = SESSION_STATUS.UPCOMING;
                }
                return {
                    sessionId: row._id,
                    title: row.title,
                    startTime: row.startTime,
                    endTime: row.endTime,
                    room: row.room,
                    recorded: row.recorded,
                    present: row.present,
                    status,
                    roster: row.roster
                };
            });

            const taken = sessions.filter((s) => s.status === SESSION_STATUS.TAKEN).length;
            const notTaken = sessions.filter((s) => s.status === SESSION_STATUS.NOT_TAKEN).length;

            return {
                month: monthLabel(period),
                sessions,
                summary: {
                    sessions: sessions.length,
                    taken,
                    notTaken,
                    upcoming: sessions.length - taken - notTaken,
                    // Completion counts only sessions that have already started.
                    completionRate: ratio(taken, taken + notTaken)
                }
            };
        }
    };
};

module.exports = { createReportService, SESSION_STATUS };
