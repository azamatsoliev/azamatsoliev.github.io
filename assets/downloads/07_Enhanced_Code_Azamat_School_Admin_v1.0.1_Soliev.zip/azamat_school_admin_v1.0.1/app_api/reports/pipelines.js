/**
 * Reporting aggregation pipelines.
 *
 * Each function builds, but does not run, a MongoDB aggregation pipeline. An
 * aggregation pipeline is a sequence of stages the database applies in order:
 * filtering, joining collections, grouping, and computing fields. Doing this
 * work inside the database means only the finished report crosses the network,
 * rather than every underlying record.
 *
 * Keeping the builders free of any database connection has a practical
 * benefit: the identical pipeline objects that run in production also run in
 * the test suite, against an in-memory engine, so the tests exercise the real
 * queries rather than an imitation of them.
 *
 * Rules applied consistently by every pipeline:
 *
 *   Money in cents. Every amount is converted to integer cents with
 *   centsExpression before it is summed, so totals are exact. See
 *   app_api/utils/money.js.
 *
 *   Soft deletes respected. Withdrawn records keep their history but stop
 *   counting. A reversed payment is not money received; attendance recorded
 *   against a canceled session is not billable; a withdrawn attendance record
 *   is not attendance. The original plan's balance pipeline omitted these
 *   filters, and would have overstated both what students paid and what they owe.
 *
 *   Billing model. The school charges per lesson attended, at the rate stored
 *   on that lesson. A balance is the sum of the rates of the active sessions a
 *   student was marked present at, minus their active payments. Each session is
 *   a single dated lesson rather than a recurring template, so editing its rate
 *   is a correction to that lesson, and reading the rate at report time
 *   applies the correction. If sessions were ever generated from a shared
 *   course template, the rate would instead need to be copied onto each
 *   attendance record when marked, so a later price change could not rewrite
 *   past charges.
 *
 *   Collection names come from the models. Mongoose stores the attendance
 *   model in a collection named "attendances". A $lookup naming "attendance"
 *   would join an empty collection without raising any error, and every
 *   attendance figure would silently read zero.
 *
 * @file    app_api/reports/pipelines.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const { centsExpression } = require('../utils/money');

/** Condition: an array element's active flag is true. */
const isActive = (variable) => ({ $eq: [`$$${variable}.active`, true] });

/** Condition: an attendance record is active and marked present. */
const isPresentAndActive = (variable) => ({
    $and: [isActive(variable), { $eq: [`$$${variable}.present`, true] }]
});

/**
 * Outstanding balance per student.
 *
 * Runs on: students.
 *
 * Joins each student to their attendance, to the sessions they attended, and to
 * their payments, then computes what was billed, what was paid and the
 * difference. Matches the approved Module One design: match students, look up
 * payments, look up attendance, look up the attended sessions, add fields.
 *
 * Which students appear: every active student, including those owing nothing,
 * and any withdrawn student whose balance is not exactly zero. A student who
 * leaves still owing money is precisely the case an accountant must see, so
 * withdrawal alone never hides a debt or a credit. The exactness of cents
 * matters here: with floating point, a settled account can come out a few
 * quadrillionths of a unit away from zero (10.05 + 16.85 - 26.90 gives
 * 0.0000000000000036), which is not zero, so a fully paid former student would
 * wrongly remain on the report.
 *
 * Cost: one indexed lookup per student into attendance, sessions and payments,
 * via the indexes on attendance.studentId, payments.studentId and sessions._id.
 * O(S log N + R) for S students, N records per collection, and R related records.
 *
 * @param   {object} collections - Collection names, from the models.
 * @returns {object[]} The pipeline.
 */
const studentBalancesPipeline = ({ collections }) => [
    {
        $lookup: {
            from: collections.attendance,
            localField: '_id',
            foreignField: 'studentId',
            as: 'attendanceRecords'
        }
    },
    {
        $addFields: {
            attendedRecords: {
                $filter: { input: '$attendanceRecords', as: 'a', cond: isPresentAndActive('a') }
            }
        }
    },
    {
        $lookup: {
            from: collections.classSessions,
            localField: 'attendedRecords.classSessionId',
            foreignField: '_id',
            as: 'attendedSessions'
        }
    },
    {
        $lookup: {
            from: collections.payments,
            localField: '_id',
            foreignField: 'studentId',
            as: 'paymentRecords'
        }
    },
    {
        $project: {
            firstName: 1,
            lastName: 1,
            email: 1,
            active: 1,
            billableSessions: {
                $filter: { input: '$attendedSessions', as: 's', cond: isActive('s') }
            },
            activePayments: {
                $filter: { input: '$paymentRecords', as: 'p', cond: isActive('p') }
            }
        }
    },
    {
        $project: {
            firstName: 1,
            lastName: 1,
            email: 1,
            active: 1,
            classesAttended: { $size: '$billableSessions' },
            billedCents: {
                $sum: { $map: { input: '$billableSessions', as: 's', in: centsExpression('$$s.ratePerClass') } }
            },
            paidCents: {
                $sum: { $map: { input: '$activePayments', as: 'p', in: centsExpression('$$p.amount') } }
            }
        }
    },
    { $addFields: { outstandingCents: { $subtract: ['$billedCents', '$paidCents'] } } },
    { $match: { $or: [{ active: true }, { outstandingCents: { $ne: 0 } }] } },
    { $sort: { outstandingCents: -1, lastName: 1, firstName: 1 } }
];

/**
 * Money received in a period, one row per student.
 *
 * Runs on: payments.
 *
 * Filtering first and grouping second means only the period's payments are
 * read. The filter on paidOn is served by the index on that field: O(log N + m)
 * for m payments in the period.
 *
 * A payment whose student record cannot be found is kept rather than dropped,
 * so the report's total always equals the money actually received.
 *
 * @param   {object} params
 * @param   {Date}   params.from - Start of the period, inclusive.
 * @param   {Date}   params.to   - End of the period, exclusive.
 * @param   {object} params.collections - Collection names, from the models.
 * @returns {object[]} The pipeline.
 */
const revenueByStudentPipeline = ({ from, to, collections }) => [
    { $match: { active: true, paidOn: { $gte: from, $lt: to } } },
    {
        $group: {
            _id: '$studentId',
            payments: { $sum: 1 },
            collectedCents: { $sum: centsExpression('$amount') }
        }
    },
    {
        $lookup: {
            from: collections.students,
            localField: '_id',
            foreignField: '_id',
            as: 'student'
        }
    },
    { $unwind: { path: '$student', preserveNullAndEmptyArrays: true } },
    {
        $project: {
            _id: 0,
            studentId: '$_id',
            firstName: '$student.firstName',
            lastName: '$student.lastName',
            email: '$student.email',
            payments: 1,
            collectedCents: 1
        }
    },
    { $sort: { lastName: 1, firstName: 1 } }
];

/**
 * Money received per calendar month across a year.
 *
 * Runs on: payments.
 *
 * Groups by the month of the payment date in UTC, because payment dates are
 * calendar dates stored as midnight UTC (see periods.js). The time zone is
 * written as "+00:00" rather than relying on the default, so the intent is
 * explicit and the result cannot depend on any server setting.
 *
 * Months with no payments produce no group; the service fills them with zero
 * so every report shows all twelve months.
 *
 * @param   {object} params
 * @param   {Date}   params.from - Start of the year, inclusive.
 * @param   {Date}   params.to   - Start of the next year, exclusive.
 * @returns {object[]} The pipeline.
 */
const revenueByMonthPipeline = ({ from, to }) => [
    { $match: { active: true, paidOn: { $gte: from, $lt: to } } },
    {
        $group: {
            _id: { $month: { date: '$paidOn', timezone: '+00:00' } },
            payments: { $sum: 1 },
            collectedCents: { $sum: centsExpression('$amount') }
        }
    },
    { $sort: { _id: 1 } }
];

/**
 * Attendance and earnings per class across a period, for the owner.
 *
 * Runs on: classsessions.
 *
 * Answers the owner's real question, whether a class is worth continuing to
 * run, by putting attendance and earnings side by side. Sessions sharing a title
 * are treated as one class.
 *
 * Attendance rate is present divided by recorded. A class whose attendance has
 * never been taken has no rate rather than a rate of zero: zero would claim
 * nobody came, when in fact nobody was counted. Division happens only when the
 * divisor is non-zero, and the divisor is additionally held to at least one,
 * so the stage can never divide by zero.
 *
 * Earnings here are amounts billed for attendance, not payments received.
 * Payments are made by students, not attributed to classes, so earnings are
 * the measure that can be divided between classes.
 *
 * Cost: the $match is served by the { active, startTime } index, then one
 * indexed lookup per session into attendance by classSessionId.
 *
 * @param   {object} params
 * @param   {Date}   params.from - Start of the period, inclusive.
 * @param   {Date}   params.to   - End of the period, exclusive.
 * @param   {object} params.collections - Collection names, from the models.
 * @returns {object[]} The pipeline.
 */
const classSummaryPipeline = ({ from, to, collections }) => [
    { $match: { active: true, startTime: { $gte: from, $lt: to } } },
    {
        $lookup: {
            from: collections.attendance,
            localField: '_id',
            foreignField: 'classSessionId',
            as: 'records'
        }
    },
    {
        $project: {
            title: 1,
            rateCents: centsExpression('$ratePerClass'),
            recorded: { $size: { $filter: { input: '$records', as: 'r', cond: isActive('r') } } },
            present: { $size: { $filter: { input: '$records', as: 'r', cond: isPresentAndActive('r') } } }
        }
    },
    {
        $group: {
            _id: '$title',
            sessions: { $sum: 1 },
            recorded: { $sum: '$recorded' },
            present: { $sum: '$present' },
            billedCents: { $sum: { $multiply: ['$present', '$rateCents'] } }
        }
    },
    {
        $project: {
            _id: 0,
            title: '$_id',
            sessions: 1,
            recorded: 1,
            present: 1,
            billedCents: 1,
            attendanceRate: {
                $cond: [
                    { $eq: ['$recorded', 0] },
                    null,
                    { $round: [{ $divide: ['$present', { $max: ['$recorded', 1] }] }, 4] }
                ]
            }
        }
    },
    { $sort: { title: 1 } }
];

/**
 * One teacher's sessions in a period, with each session's roster.
 *
 * Runs on: classsessions.
 *
 * The teacherId comes from the caller's verified token, never from the request,
 * so a teacher can only ever see their own sessions. The roster carries only
 * each student's name and whether they were present: no contact details and no
 * financial information reach a teacher.
 *
 * Cost: the $match is served by the { teacherId, active, startTime } index
 * built for conflict detection, which matches this query exactly: two equality
 * conditions followed by a range.
 *
 * @param   {object} params
 * @param   {*}      params.teacherId - The teacher, as an identifier.
 * @param   {Date}   params.from - Start of the period, inclusive.
 * @param   {Date}   params.to   - End of the period, exclusive.
 * @param   {object} params.collections - Collection names, from the models.
 * @returns {object[]} The pipeline.
 */
const attendanceSheetPipeline = ({ teacherId, from, to, collections }) => [
    { $match: { teacherId, active: true, startTime: { $gte: from, $lt: to } } },
    { $sort: { startTime: 1 } },
    {
        $lookup: {
            from: collections.attendance,
            let: { sessionId: '$_id' },
            pipeline: [
                { $match: { $expr: { $eq: ['$classSessionId', '$$sessionId'] } } },
                { $match: { active: true } },
                {
                    $lookup: {
                        from: collections.students,
                        localField: 'studentId',
                        foreignField: '_id',
                        as: 'student'
                    }
                },
                { $unwind: '$student' },
                {
                    $project: {
                        _id: 0,
                        present: 1,
                        firstName: '$student.firstName',
                        lastName: '$student.lastName'
                    }
                },
                { $sort: { lastName: 1, firstName: 1 } }
            ],
            as: 'roster'
        }
    },
    {
        $project: {
            title: 1,
            startTime: 1,
            endTime: 1,
            room: 1,
            roster: 1,
            recorded: { $size: '$roster' },
            present: {
                $size: { $filter: { input: '$roster', as: 'r', cond: { $eq: ['$$r.present', true] } } }
            }
        }
    }
];

module.exports = {
    studentBalancesPipeline,
    revenueByStudentPipeline,
    revenueByMonthPipeline,
    classSummaryPipeline,
    attendanceSheetPipeline
};
