/**
 * CSV export.
 *
 * Produces comma-separated files that open correctly and safely in a
 * spreadsheet program.
 *
 * Formula injection. A spreadsheet program treats any cell beginning with "=",
 * "+", "-" or "@" as a formula, and a leading tab or carriage return can be
 * used to reach the same behavior. Student names are free text entered
 * through the application, so a name such as =HYPERLINK("http://...","Pay here")
 * would become a live formula the moment an accountant opened the export. This
 * is known as CSV or formula injection. Every text cell that begins with one of
 * those characters is prefixed with a single quote, which tells the spreadsheet
 * to display it as plain text.
 *
 * Numeric columns are formatted by this module from integer cents and are never
 * user input, so they are not prefixed; a negative balance therefore stays a
 * number the accountant can add up.
 *
 * Quoting follows RFC 4180: a cell containing a comma, quote or line break is
 * wrapped in quotes, and quotes inside it are doubled.
 *
 * The file begins with a UTF-8 byte order mark, without which Excel misreads
 * names written in non-Latin scripts.
 *
 * @file    app_api/reports/csv.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const { formatCents } = require('../utils/money');

/** Characters that make a spreadsheet interpret a cell as a formula. */
const FORMULA_TRIGGER = /^[=+\-@\t\r]/;

/** UTF-8 byte order mark. */
const BOM = '\uFEFF';

/** Neutralizes a text value that a spreadsheet would treat as a formula. */
const neutralizeFormula = (text) => (FORMULA_TRIGGER.test(text) ? `'${text}` : text);

/** Wraps a cell in quotes when its content requires it. */
const quoteIfNeeded = (text) => (/[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text);

/**
 * Formats one cell according to its column type.
 *
 * @param   {*}      value - The raw value.
 * @param   {string} type  - 'text', 'integer' or 'cents'.
 * @returns {string} The cell as it should appear in the file.
 */
const formatCell = (value, type) => {
    if (value === null || value === undefined) {
        return '';
    }
    if (type === 'cents') {
        return formatCents(value);
    }
    if (type === 'integer') {
        return String(Math.trunc(Number(value) || 0));
    }
    return quoteIfNeeded(neutralizeFormula(String(value)));
};

/**
 * Builds a CSV document.
 *
 * @param   {{ header: string, key: string, type?: string }[]} columns
 * @param   {object[]} rows - Records keyed by each column's key.
 * @returns {string} The CSV text, with a byte order mark and CRLF line endings.
 */
const toCsv = (columns, rows) => {
    const headerLine = columns.map((column) => formatCell(column.header, 'text')).join(',');
    const lines = rows.map((row) =>
        columns.map((column) => formatCell(row[column.key], column.type || 'text')).join(','));
    return `${BOM}${[headerLine, ...lines].join('\r\n')}\r\n`;
};

module.exports = { toCsv, formatCell, neutralizeFormula, FORMULA_TRIGGER };
