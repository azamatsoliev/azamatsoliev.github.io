/**
 * Minimal HTTP client for tests.
 *
 * Starts an Express application on a free port, sends one request, and returns
 * the status, headers and parsed body. Used by the tests that exercise the real
 * routing and middleware rather than a single handler.
 *
 * @file    app_api/tests/helpers/httpClient.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const http = require('node:http');

/**
 * Sends one request to an application.
 *
 * @param   {Function} app - An Express application.
 * @param   {object}   options
 * @param   {string}   [options.method='GET'] - HTTP method.
 * @param   {string}   options.path           - Request path, including any query.
 * @param   {object}   [options.headers]      - Request headers.
 * @param   {*}        [options.body]         - Object to send as JSON, or a raw string.
 * @returns {Promise<{status: number, headers: object, body: *}>}
 */
const request = (app, { method = 'GET', path, headers = {}, body } = {}) => new Promise((resolve, reject) => {
    const server = http.createServer(app).listen(0, () => {
        const payload = body === undefined ? null : (typeof body === 'string' ? body : JSON.stringify(body));
        const requestHeaders = { ...headers };

        if (payload !== null) {
            requestHeaders['Content-Type'] = requestHeaders['Content-Type'] || 'application/json';
            requestHeaders['Content-Length'] = Buffer.byteLength(payload);
        }

        const req = http.request(
            { port: server.address().port, method, path, headers: requestHeaders },
            (res) => {
                let raw = '';
                res.setEncoding('utf8');
                res.on('data', (chunk) => { raw += chunk; });
                res.on('end', () => {
                    server.close();
                    let parsed = raw;
                    try {
                        parsed = raw ? JSON.parse(raw) : null;
                    } catch (error) {
                        // Not JSON; the raw text is returned instead.
                    }
                    resolve({ status: res.statusCode, headers: res.headers, body: parsed });
                });
            }
        );

        req.on('error', (error) => { server.close(); reject(error); });

        if (payload !== null) {
            req.write(payload);
        }
        req.end();
    });
});

module.exports = { request };
