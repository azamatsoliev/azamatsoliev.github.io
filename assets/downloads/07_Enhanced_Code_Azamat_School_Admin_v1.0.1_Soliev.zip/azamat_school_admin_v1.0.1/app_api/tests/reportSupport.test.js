/**
 * Tests for report parameters, money arithmetic and CSV export.
 *
 * @file    app_api/tests/reportSupport.test.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const {
    parseMonth, parseYear, utcMonthRange, localMonthRange, ReportParameterError
} = require('../reports/periods');
const { isWholeCents, fromCents, formatCents } = require('../utils/money');
const { toCsv } = require('../reports/csv');

// ---------------------------------------------------------------------------
// Parameters
// ---------------------------------------------------------------------------

test('a well-formed month is accepted', () => {
    assert.deepStrictEqual(parseMonth('2026-10'), { year: 2026, month: 10 });
    assert.deepStrictEqual(parseMonth('2026-01'), { year: 2026, month: 1 });
});

test('malformed months are refused with a 400', () => {
    for (const bad of ['2026-13', '2026-00', '2026-1', '26-10', '2026/10', '2026-10x', ' 2026-10', '']) {
        assert.throws(() => parseMonth(bad), ReportParameterError, `should refuse ${JSON.stringify(bad)}`);
    }
});

test('a month that is not a string is refused, so no object can reach a filter', () => {
    assert.throws(() => parseMonth({ $gt: '' }), ReportParameterError);
    assert.throws(() => parseMonth(['2026-10', '2026-11']), ReportParameterError);
    assert.throws(() => parseMonth(undefined), ReportParameterError);
});

test('years outside the supported range are refused', () => {
    assert.strictEqual(parseYear('2026'), 2026);
    assert.throws(() => parseYear('1999'), ReportParameterError);
    assert.throws(() => parseYear('2101'), ReportParameterError);
    assert.throws(() => parseYear('20260'), ReportParameterError);
});

test('a refused parameter carries a 400 status', () => {
    try {
        parseMonth('nope');
        assert.fail('expected an error');
    } catch (error) {
        assert.strictEqual(error.status, 400);
    }
});

test('payment months are cut at midnight UTC', () => {
    const { from, to } = utcMonthRange({ year: 2026, month: 12 });
    assert.strictEqual(from.toISOString(), '2026-12-01T00:00:00.000Z');
    assert.strictEqual(to.toISOString(), '2027-01-01T00:00:00.000Z', 'December rolls into January');
});

test('session months are cut at local midnight', () => {
    const { from, to } = localMonthRange({ year: 2026, month: 10 });
    assert.strictEqual(from.getTime(), new Date(2026, 9, 1).getTime());
    assert.strictEqual(to.getTime(), new Date(2026, 10, 1).getTime());
});

// ---------------------------------------------------------------------------
// Money
// ---------------------------------------------------------------------------

test('whole cents are recognized, including values floating point cannot store exactly', () => {
    assert.strictEqual(isWholeCents(25), true);
    assert.strictEqual(isWholeCents(12.1), true);
    assert.strictEqual(isWholeCents(0.29), true, '0.29 * 100 is 28.999999999999996');
    assert.strictEqual(isWholeCents(10.005), false);
    assert.strictEqual(isWholeCents(Number.NaN), false);
    assert.strictEqual(isWholeCents(undefined), true, 'absence is left to the required rule');
});

test('cents convert back to exact amounts and fixed two-place strings', () => {
    assert.strictEqual(fromCents(2430), 24.3);
    assert.strictEqual(formatCents(2430), '24.30');
    assert.strictEqual(formatCents(-1500), '-15.00');
    assert.strictEqual(formatCents(5), '0.05');
    assert.strictEqual(formatCents(0), '0.00');
});

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------

const columns = [
    { header: 'Last name', key: 'lastName' },
    { header: 'Payments', key: 'payments', type: 'integer' },
    { header: 'Collected', key: 'cents', type: 'cents' }
];

const lines = (csv) => csv.replace(/^\uFEFF/, '').trimEnd().split('\r\n');

test('a name beginning with a formula character is neutralized', () => {
    for (const hostile of ['=HYPERLINK("http://x","Pay")', '+1+1', '-2+3', '@SUM(A1:A2)', '\tcmd']) {
        const [, row] = lines(toCsv(columns, [{ lastName: hostile, payments: 1, cents: 100 }]));
        const firstCell = row.replace(/^"/, '');
        assert.ok(firstCell.startsWith("'"), `${JSON.stringify(hostile)} must be prefixed with a quote`);
    }
});

test('ordinary names are left untouched', () => {
    const [, row] = lines(toCsv(columns, [{ lastName: 'Rahimova', payments: 1, cents: 5000 }]));
    assert.strictEqual(row, 'Rahimova,1,50.00');
});

test('negative money stays a number rather than being treated as a formula', () => {
    const [, row] = lines(toCsv(columns, [{ lastName: 'Yusupova', payments: 1, cents: -1500 }]));
    assert.strictEqual(row, 'Yusupova,1,-15.00');
});

test('commas and quotes inside a value are quoted correctly', () => {
    const [, row] = lines(toCsv(columns, [{ lastName: 'O"Neil, Jr', payments: 0, cents: 0 }]));
    assert.strictEqual(row, '"O""Neil, Jr",0,0.00');
});

test('the file starts with a byte order mark and uses CRLF line endings', () => {
    const csv = toCsv(columns, []);
    assert.ok(csv.startsWith('\uFEFF'), 'without it, Excel misreads non-Latin names');
    assert.ok(csv.endsWith('\r\n'));
});
