/**
 * Tests for account credentials and token contents.
 *
 * Covers the two security changes made to the user model: the raised password
 * work factor with backward compatibility for existing hashes, and the role
 * carried in the signed token.
 *
 * Changed in version 1.0.1: the legacy-credential tests now load the account
 * the way a database query returns it. The earlier versions built the account
 * in memory and cleared its work factor by hand, which skipped the step where
 * Mongoose fills in schema defaults. They passed while a real account stored at
 * the original work factor could not sign in.
 *
 * @file    app_api/tests/user.test.js
 * @author  Azamat Soliev
 * @version 4.1
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');
const crypto = require('node:crypto');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-unit-tests';

const mongoose = require('mongoose');
const User = require('../models/user');
const { ROLES } = require('../config/roles');

const PBKDF2_ITERATIONS = User.PBKDF2_ITERATIONS;
const LEGACY_PBKDF2_ITERATIONS = User.LEGACY_PBKDF2_ITERATIONS;

test('the work factor meets current guidance for PBKDF2-HMAC-SHA512', () => {
    assert.strictEqual(PBKDF2_ITERATIONS, 210000);
    assert.ok(PBKDF2_ITERATIONS > LEGACY_PBKDF2_ITERATIONS * 100,
        'the new factor should be orders of magnitude above the original 1,000');
});

test('a new account defaults to the least privileged role', () => {
    const user = new User({ email: 'new@example.com', name: 'New Account' });
    assert.strictEqual(user.role, ROLES.TEACHER);
});

test('setting a password stores a salt, a hash and the iteration count', () => {
    const user = new User({ email: 'a@example.com', name: 'A' });
    user.setPassword('correct-horse-battery');

    assert.ok(user.salt && user.salt.length > 0);
    assert.ok(user.hash && user.hash.length > 0);
    assert.strictEqual(user.iterations, PBKDF2_ITERATIONS);
    assert.notStrictEqual(user.hash, 'correct-horse-battery');
});

test('the correct password verifies and an incorrect one does not', () => {
    const user = new User({ email: 'a@example.com', name: 'A' });
    user.setPassword('correct-horse-battery');

    assert.strictEqual(user.validPassword('correct-horse-battery'), true);
    assert.strictEqual(user.validPassword('wrong-password'), false);
    assert.strictEqual(user.validPassword(''), false);
});

test('two accounts with the same password produce different hashes', () => {
    const first = new User({ email: 'a@example.com', name: 'A' });
    const second = new User({ email: 'b@example.com', name: 'B' });
    first.setPassword('same-password');
    second.setPassword('same-password');

    assert.notStrictEqual(first.salt, second.salt, 'each account should get its own salt');
    assert.notStrictEqual(first.hash, second.hash);
});

/**
 * An account written before the iteration count was stored, loaded the way a
 * query returns it. hydrate() applies the same schema defaults as a real query,
 * so these tests see exactly what the sign-in code sees.
 */
const legacyAccount = (password) => {
    const salt = crypto.randomBytes(16).toString('hex');
    return User.hydrate({
        _id: new mongoose.Types.ObjectId(),
        email: 'legacy@example.com',
        name: 'Legacy',
        role: ROLES.OWNER,
        salt,
        hash: crypto.pbkdf2Sync(password, salt, LEGACY_PBKDF2_ITERATIONS, 64, 'sha512').toString('hex')
    });
};

test('a credential stored at the original work factor still verifies after loading', () => {
    const legacy = legacyAccount('legacy-password');

    assert.strictEqual(legacy.iterations, undefined,
        'a record without a stored work factor must not be given the new one when loaded');
    assert.strictEqual(legacy.validPassword('legacy-password'), true,
        'raising the work factor must not lock out existing accounts');
    assert.strictEqual(legacy.validPassword('wrong'), false);
});

test('a legacy credential is flagged for upgrade and a current one is not', () => {
    const legacy = legacyAccount('legacy-password');
    assert.strictEqual(legacy.needsRehash(), true);

    const current = new User({ email: 'current@example.com', name: 'Current' });
    current.setPassword('a-new-password');
    assert.strictEqual(current.needsRehash(), false);
});

test('verification fails safely when no credential is stored', () => {
    const user = new User({ email: 'empty@example.com', name: 'Empty' });
    assert.strictEqual(user.validPassword('anything'), false);
});

test('the signed token carries the role and never carries credential material', () => {
    const user = new User({ email: 'owner@example.com', name: 'Owner', role: ROLES.OWNER });
    user.setPassword('owner-password');

    const payload = jwt.verify(user.generateJWT(), process.env.JWT_SECRET);

    assert.strictEqual(payload.role, ROLES.OWNER);
    assert.strictEqual(payload.email, 'owner@example.com');
    assert.strictEqual(payload.hash, undefined, 'the hash must never reach the client');
    assert.strictEqual(payload.salt, undefined, 'the salt must never reach the client');
    assert.ok(payload.exp, 'the token must expire');
});
