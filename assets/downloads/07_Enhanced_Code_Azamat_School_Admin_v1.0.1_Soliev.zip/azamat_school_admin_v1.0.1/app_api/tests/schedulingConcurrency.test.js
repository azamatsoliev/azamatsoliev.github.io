/**
 * Concurrency tests for class-session booking.
 *
 * A conflict check followed by a save is a check-then-act sequence. These tests
 * send two overlapping bookings for the same teacher at the same moment,
 * through the real controller factory and the real conflict check, backed by an
 * in-memory store that pauses on every read and write the way a database round
 * trip does. Those pauses are where one request's check can slip in between
 * another request's check and its save.
 *
 * The first test runs without the lock and shows the double booking actually
 * happens. It exists so that the second test, run with the production lock key,
 * demonstrates that the lock is what prevents it, rather than the scenario
 * simply never arising.
 *
 * @file    app_api/tests/schedulingConcurrency.test.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const createCrudController = require('../controllers/crudControllerFactory');
const { createScheduleConflictCheck } = require('../scheduling/conflictDetection');
const { ROLES } = require('../config/roles');
const ENTITIES = require('../config/entities');

/** Stands in for a database round trip. */
const roundTrip = () => new Promise((resolve) => setImmediate(resolve));

/** Evaluates the subset of MongoDB filter syntax the conflict query uses. */
const matches = (doc, filter) => Object.entries(filter).every(([field, condition]) => {
    const value = doc[field];
    if (condition && typeof condition === 'object' && !(condition instanceof Date)) {
        const time = value instanceof Date ? value.getTime() : value;
        const operand = (x) => (x instanceof Date ? x.getTime() : x);
        if ('$gt' in condition && !(time > operand(condition.$gt))) return false;
        if ('$lt' in condition && !(time < operand(condition.$lt))) return false;
        if ('$ne' in condition && String(value) === String(condition.$ne)) return false;
        return true;
    }
    return String(value) === String(condition);
});

/** An in-memory model with database-like latency on every operation. */
const createStore = () => {
    const documents = [];
    let nextId = 1;

    return {
        documents,
        async find(filter) {
            await roundTrip();
            return documents
                .filter((doc) => matches(doc, filter))
                .sort((a, b) => a.startTime - b.startTime)
                .map((doc) => ({ ...doc }));
        },
        async create(data) {
            await roundTrip();
            const doc = {
                _id: `session-${nextId++}`,
                active: true,
                ...data,
                startTime: new Date(data.startTime),
                endTime: new Date(data.endTime)
            };
            documents.push(doc);
            return doc;
        }
    };
};

const createResponse = () => {
    const response = { statusCode: null, body: null };
    response.status = (code) => { response.statusCode = code; return response; };
    response.json = (payload) => { response.body = payload; return response; };
    return response;
};

const OWNER = { id: 'u1', role: ROLES.OWNER };

const controllerFor = (store, { withLock }) => createCrudController(store, {
    name: 'classsessions',
    permissions: { list: [ROLES.OWNER], create: [ROLES.OWNER], update: [ROLES.OWNER], remove: [ROLES.OWNER] },
    writableFields: ['title', 'teacherId', 'startTime', 'endTime', 'ratePerClass', 'room'],
    softDelete: true,
    preSaveChecks: [createScheduleConflictCheck(store)],
    lockKey: withLock ? ENTITIES.classsessions.lockKey : null
});

const booking = (title, teacherId, start, end) => ({
    auth: OWNER,
    body: {
        title,
        teacherId,
        startTime: `2026-09-21T${start}:00`,
        endTime: `2026-09-21T${end}:00`,
        ratePerClass: 25
    }
});

test('without the lock, two simultaneous overlapping bookings both succeed', async () => {
    const store = createStore();
    const controller = controllerFor(store, { withLock: false });
    const first = createResponse();
    const second = createResponse();

    await Promise.all([
        controller.create(booking('Morning group', 't-1', '09:00', '11:00'), first),
        controller.create(booking('Private lesson', 't-1', '10:00', '12:00'), second)
    ]);

    // This is the defect the lock exists to prevent: an overlapping pair saved.
    assert.strictEqual(first.statusCode, 201);
    assert.strictEqual(second.statusCode, 201);
    assert.strictEqual(store.documents.length, 2, 'the race produced a double booking');
});

test('with the lock, exactly one of two simultaneous overlapping bookings succeeds', async () => {
    const store = createStore();
    const controller = controllerFor(store, { withLock: true });
    const first = createResponse();
    const second = createResponse();

    await Promise.all([
        controller.create(booking('Morning group', 't-1', '09:00', '11:00'), first),
        controller.create(booking('Private lesson', 't-1', '10:00', '12:00'), second)
    ]);

    const codes = [first.statusCode, second.statusCode].sort();
    assert.deepStrictEqual(codes, [201, 409]);
    assert.strictEqual(store.documents.length, 1, 'only one session may be saved');
});

test('with the lock, ten simultaneous bookings of one slot yield a single success', async () => {
    const store = createStore();
    const controller = controllerFor(store, { withLock: true });
    const responses = Array.from({ length: 10 }, createResponse);

    await Promise.all(responses.map((res, i) =>
        controller.create(booking(`Attempt ${i}`, 't-1', '09:00', '10:00'), res)));

    assert.strictEqual(responses.filter((r) => r.statusCode === 201).length, 1);
    assert.strictEqual(responses.filter((r) => r.statusCode === 409).length, 9);
    assert.strictEqual(store.documents.length, 1);
});

test('the lock does not block bookings for different teachers', async () => {
    const store = createStore();
    const controller = controllerFor(store, { withLock: true });
    const first = createResponse();
    const second = createResponse();

    await Promise.all([
        controller.create(booking('Group A', 't-1', '09:00', '11:00'), first),
        controller.create(booking('Group B', 't-2', '09:00', '11:00'), second)
    ]);

    assert.strictEqual(first.statusCode, 201);
    assert.strictEqual(second.statusCode, 201);
});

test('back-to-back bookings for the same teacher are both accepted', async () => {
    const store = createStore();
    const controller = controllerFor(store, { withLock: true });
    const first = createResponse();
    const second = createResponse();

    await Promise.all([
        controller.create(booking('First', 't-1', '09:00', '11:00'), first),
        controller.create(booking('Second', 't-1', '11:00', '12:00'), second)
    ]);

    assert.strictEqual(first.statusCode, 201);
    assert.strictEqual(second.statusCode, 201);
});
