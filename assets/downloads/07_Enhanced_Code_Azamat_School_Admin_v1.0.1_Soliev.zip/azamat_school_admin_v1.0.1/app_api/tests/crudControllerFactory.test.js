/**
 * Tests for the generic CRUD controller factory.
 *
 * These run against stub models rather than a live database. The behavior
 * under test is the factory's own decision-making: whether it authorizes,
 * whether it narrows a query to the caller's records, whether it discloses the
 * existence of a record it will not return, and whether it writes only
 * permitted fields. None of that depends on MongoDB being reachable, and
 * testing it in isolation keeps the suite fast and deterministic.
 *
 * Run with: npm test
 *
 * @file    app_api/tests/crudControllerFactory.test.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const createCrudController = require('../controllers/crudControllerFactory');
const { ROLES } = require('../config/roles');

/** Captures the status and body a handler responds with. */
const createResponse = () => {
    const response = { statusCode: null, body: null };
    response.status = (code) => {
        response.statusCode = code;
        return response;
    };
    response.json = (payload) => {
        response.body = payload;
        return response;
    };
    return response;
};

/**
 * A stub model that records the filters it was queried with, so a test can
 * assert what the factory asked the database for rather than only what it
 * returned.
 */
const createStubModel = ({ findResult = [], findOneResult = null } = {}) => ({
    calls: { find: [], findOne: [], create: [], deleteOne: [] },
    find(filter) {
        this.calls.find.push(filter);
        return Promise.resolve(findResult);
    },
    findOne(filter) {
        this.calls.findOne.push(filter);
        return Promise.resolve(findOneResult);
    },
    create(data) {
        this.calls.create.push(data);
        return Promise.resolve({ _id: 'new-id', ...data });
    },
    deleteOne(filter) {
        this.calls.deleteOne.push(filter);
        return Promise.resolve({ deletedCount: 1 });
    }
});

const OWNER = { id: 'u1', role: ROLES.OWNER, teacherId: null };
const TEACHER = { id: 'u2', role: ROLES.TEACHER, teacherId: 't-100' };
const OTHER_TEACHER = { id: 'u3', role: ROLES.TEACHER, teacherId: 't-999' };

/** Configuration mirroring the class-session entity. */
const sessionConfig = {
    name: 'classsessions',
    permissions: {
        list: [ROLES.OWNER, ROLES.TEACHER],
        create: [ROLES.OWNER],
        update: [ROLES.OWNER, ROLES.TEACHER],
        remove: [ROLES.OWNER]
    },
    writableFields: ['title', 'teacherId', 'startTime', 'endTime', 'ratePerClass'],
    scopeRule: (user) => (user.role === ROLES.TEACHER ? { teacherId: user.teacherId } : {}),
    softDelete: true
};

// ---------------------------------------------------------------------------
// Role-level authorization
// ---------------------------------------------------------------------------

test('a request with no verified token is refused with 401', async () => {
    const controller = createCrudController(createStubModel(), sessionConfig);
    const res = createResponse();

    await controller.list({ auth: undefined }, res);

    assert.strictEqual(res.statusCode, 401);
});

test('a teacher is refused 403 when creating, which is owner-only', async () => {
    const controller = createCrudController(createStubModel(), sessionConfig);
    const res = createResponse();

    await controller.create({ auth: TEACHER, body: { title: 'Beginner A1' } }, res);

    assert.strictEqual(res.statusCode, 403);
});

test('an owner may create', async () => {
    const model = createStubModel();
    const controller = createCrudController(model, sessionConfig);
    const res = createResponse();

    await controller.create({ auth: OWNER, body: { title: 'Beginner A1', ratePerClass: 25 } }, res);

    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(model.calls.create.length, 1);
});

// ---------------------------------------------------------------------------
// Record-level scoping - the horizontal privilege escalation path
// ---------------------------------------------------------------------------

test('a teacher listing sessions is narrowed to their own records', async () => {
    const model = createStubModel({ findResult: [] });
    const controller = createCrudController(model, sessionConfig);

    await controller.list({ auth: TEACHER }, createResponse());

    assert.deepStrictEqual(model.calls.find[0], { teacherId: 't-100', active: true });
});

test('an owner listing sessions is not narrowed to any teacher', async () => {
    const model = createStubModel({ findResult: [] });
    const controller = createCrudController(model, sessionConfig);

    await controller.list({ auth: OWNER }, createResponse());

    assert.deepStrictEqual(model.calls.find[0], { active: true });
    assert.strictEqual(
        Object.prototype.hasOwnProperty.call(model.calls.find[0], 'teacherId'), false,
        'an owner query must not carry a teacher restriction'
    );
});

test('a teacher updating another teacher\'s session is refused', async () => {
    // findOne returns nothing because the scoped filter excludes the record.
    const model = createStubModel({ findOneResult: null });
    const controller = createCrudController(model, sessionConfig);
    const res = createResponse();

    await controller.update(
        { auth: OTHER_TEACHER, params: { id: 'session-1' }, body: { title: 'Hijacked' } },
        res
    );

    assert.strictEqual(res.statusCode, 403);
    assert.deepStrictEqual(model.calls.findOne[0], {
        teacherId: 't-999',
        _id: 'session-1',
        active: true
    });
});

test('a refused record answers 403 rather than 404, so existence is not disclosed', async () => {
    const model = createStubModel({ findOneResult: null });
    const controller = createCrudController(model, sessionConfig);
    const res = createResponse();

    await controller.getOne({ auth: TEACHER, params: { id: 'session-1' } }, res);

    assert.strictEqual(res.statusCode, 403);
    assert.notStrictEqual(res.statusCode, 404);
});

// ---------------------------------------------------------------------------
// Field-level protection
// ---------------------------------------------------------------------------

test('fields outside the writable list are discarded before saving', async () => {
    const model = createStubModel();
    const controller = createCrudController(model, sessionConfig);

    await controller.create({
        auth: OWNER,
        body: { title: 'Beginner A1', ratePerClass: 25, active: false, _id: 'forced-id' }
    }, createResponse());

    const saved = model.calls.create[0];

    assert.strictEqual(saved.title, 'Beginner A1');
    assert.strictEqual(saved.ratePerClass, 25);
    assert.strictEqual(Object.prototype.hasOwnProperty.call(saved, 'active'), false,
        'a client must not be able to set the soft-delete flag');
    assert.strictEqual(Object.prototype.hasOwnProperty.call(saved, '_id'), false,
        'a client must not be able to force a record identifier');
});

// ---------------------------------------------------------------------------
// Soft delete
// ---------------------------------------------------------------------------

test('deleting a soft-deletable record deactivates it instead of removing it', async () => {
    const record = { _id: 'session-1', active: true, save: async function () { return this; } };
    const model = createStubModel({ findOneResult: record });
    const controller = createCrudController(model, sessionConfig);
    const res = createResponse();

    await controller.remove({ auth: OWNER, params: { id: 'session-1' } }, res);

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(record.active, false, 'the record should be marked inactive');
    assert.strictEqual(model.calls.deleteOne.length, 0, 'nothing should be removed from the database');
});

test('deleting a hard-deletable record removes it', async () => {
    const record = { _id: 'p-1', save: async function () { return this; } };
    const model = createStubModel({ findOneResult: record });
    const controller = createCrudController(model, { ...sessionConfig, softDelete: false });
    const res = createResponse();

    await controller.remove({ auth: OWNER, params: { id: 'p-1' } }, res);

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(model.calls.deleteOne.length, 1);
});

// ---------------------------------------------------------------------------
// Pre-save checks - the extension point for model-specific rules
// ---------------------------------------------------------------------------

test('a failing pre-save check stops the write and returns its own status', async () => {
    const model = createStubModel();
    const controller = createCrudController(model, {
        ...sessionConfig,
        preSaveChecks: [async () => ({ status: 409, message: 'That slot is already taken.' })]
    });
    const res = createResponse();

    await controller.create({ auth: OWNER, body: { title: 'Beginner A1' } }, res);

    assert.strictEqual(res.statusCode, 409);
    assert.strictEqual(model.calls.create.length, 0, 'nothing should be written when a check fails');
});

test('pre-save checks run on create as well as update', async () => {
    let createChecked = false;
    const controller = createCrudController(createStubModel(), {
        ...sessionConfig,
        preSaveChecks: [async () => { createChecked = true; return null; }]
    });

    await controller.create({ auth: OWNER, body: { title: 'Beginner A1' } }, createResponse());

    assert.strictEqual(createChecked, true,
        'a conflict or integrity rule that only ran on update would leave creation unguarded');
});

test('passing pre-save checks allow the write to proceed', async () => {
    const model = createStubModel();
    const controller = createCrudController(model, {
        ...sessionConfig,
        preSaveChecks: [async () => null, async () => null]
    });
    const res = createResponse();

    await controller.create({ auth: OWNER, body: { title: 'Beginner A1' } }, res);

    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(model.calls.create.length, 1);
});

// ---------------------------------------------------------------------------
// Field-level projection - least privilege on reads
// ---------------------------------------------------------------------------

/**
 * A query stand-in that records any projection applied to it and resolves to
 * a fixed result, as a Mongoose query does when awaited.
 */
const createQueryStub = (result) => ({
    selected: null,
    select(projection) {
        this.selected = projection;
        return this;
    },
    then(resolve, reject) {
        return Promise.resolve(result).then(resolve, reject);
    }
});

/** A stub model whose queries can be inspected for projections. */
const createProjectingModel = () => {
    const model = { queries: [] };
    model.find = () => { const query = createQueryStub([]); model.queries.push(query); return query; };
    model.findOne = () => { const query = createQueryStub({ _id: 'st-1' }); model.queries.push(query); return query; };
    return model;
};

/** Configuration mirroring the student entity. */
const studentConfig = {
    name: 'students',
    permissions: {
        list: [ROLES.OWNER, ROLES.ACCOUNTANT, ROLES.TEACHER],
        create: [ROLES.OWNER],
        update: [ROLES.OWNER],
        remove: [ROLES.OWNER]
    },
    writableFields: ['firstName', 'lastName', 'email', 'phone', 'enrolledOn'],
    softDelete: true,
    projectionByRole: { [ROLES.TEACHER]: 'firstName lastName' }
};

test('a teacher listing students receives names only', async () => {
    const model = createProjectingModel();
    const controller = createCrudController(model, studentConfig);
    const res = createResponse();

    await controller.list({ auth: TEACHER }, res);

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(model.queries[0].selected, 'firstName lastName');
});

test('a teacher reading one student receives names only', async () => {
    const model = createProjectingModel();
    const controller = createCrudController(model, studentConfig);

    await controller.getOne({ auth: TEACHER, params: { id: 'st-1' } }, createResponse());

    assert.strictEqual(model.queries[0].selected, 'firstName lastName');
});

test('an owner, who inherits teacher permissions, still receives every field', async () => {
    const model = createProjectingModel();
    const controller = createCrudController(model, studentConfig);

    await controller.list({ auth: OWNER }, createResponse());

    assert.strictEqual(model.queries[0].selected, null,
        'a projection meant for teachers must not narrow a broader role');
});

test('an accountant receives every field', async () => {
    const model = createProjectingModel();
    const controller = createCrudController(model, studentConfig);

    await controller.list({ auth: { id: 'u4', role: ROLES.ACCOUNTANT } }, createResponse());

    assert.strictEqual(model.queries[0].selected, null);
});

test('reading names does not let a teacher change a student', async () => {
    const model = createProjectingModel();
    const controller = createCrudController(model, studentConfig);
    const res = createResponse();

    await controller.update({ auth: TEACHER, params: { id: 'st-1' }, body: { phone: '000' } }, res);

    assert.strictEqual(res.statusCode, 403);
});

test('the live configuration limits teachers to names of students and teachers', () => {
    const ENTITIES = require('../config/entities');

    for (const key of ['students', 'teachers']) {
        assert.ok(ENTITIES[key].permissions.list.includes(ROLES.TEACHER), `${key}: teachers may read`);
        assert.deepStrictEqual(ENTITIES[key].permissions.create, [ROLES.OWNER], `${key}: only owners create`);
        assert.deepStrictEqual(ENTITIES[key].permissions.update, [ROLES.OWNER], `${key}: only owners edit`);
        assert.strictEqual(ENTITIES[key].projectionByRole[ROLES.TEACHER], 'firstName lastName');
    }
});

test('no other entity narrows the fields an owner or accountant receives', () => {
    const ENTITIES = require('../config/entities');

    Object.values(ENTITIES).forEach((entity) => {
        const projections = entity.projectionByRole || {};
        assert.strictEqual(projections[ROLES.OWNER], undefined);
        assert.strictEqual(projections[ROLES.ACCOUNTANT], undefined);
    });
});
