/**
 * Tests for scheduling conflict detection.
 *
 * Three groups:
 *
 *   1. The overlap predicate on its boundary cases, where interval logic
 *      usually breaks: sessions that touch, sessions that contain one another,
 *      and partial overlap at either edge.
 *
 *   2. The query bounds: that the filter carries both a lower and an upper
 *      bound on startTime, since dropping the lower bound silently returns the
 *      algorithm to O(n).
 *
 *   3. The pre-save check itself, against a stub model, including update
 *      semantics: merging a partial update with the stored record, excluding
 *      the session from conflicting with itself, and skipping the query when
 *      nothing time-related changed.
 *
 * @file    app_api/tests/conflictDetection.test.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const {
    CONFLICT_STATUS,
    toTime,
    intervalsOverlap,
    candidateWindow,
    buildCandidateFilter,
    findFirstOverlap,
    createScheduleConflictCheck
} = require('../scheduling/conflictDetection');
const { MAX_SESSION_DURATION_MS } = require('../models/classSession');

/** Builds a timestamp on a fixed day from "HH:MM". */
const at = (hhmm) => new Date(`2026-09-21T${hhmm}:00`).getTime();

// ---------------------------------------------------------------------------
// 1. The overlap predicate
// ---------------------------------------------------------------------------

test('sessions that touch end to start do not overlap', () => {
    assert.strictEqual(intervalsOverlap(at('09:00'), at('11:00'), at('11:00'), at('12:00')), false);
    assert.strictEqual(intervalsOverlap(at('11:00'), at('12:00'), at('09:00'), at('11:00')), false);
});

test('a session fully inside another overlaps it', () => {
    assert.strictEqual(intervalsOverlap(at('10:00'), at('10:30'), at('09:00'), at('12:00')), true);
});

test('a session fully containing another overlaps it', () => {
    assert.strictEqual(intervalsOverlap(at('09:00'), at('12:00'), at('10:00'), at('10:30')), true);
});

test('partial overlap is detected at the leading edge', () => {
    assert.strictEqual(intervalsOverlap(at('08:30'), at('09:30'), at('09:00'), at('11:00')), true);
});

test('partial overlap is detected at the trailing edge', () => {
    assert.strictEqual(intervalsOverlap(at('10:30'), at('11:30'), at('09:00'), at('11:00')), true);
});

test('identical sessions overlap', () => {
    assert.strictEqual(intervalsOverlap(at('09:00'), at('11:00'), at('09:00'), at('11:00')), true);
});

test('separated sessions do not overlap', () => {
    assert.strictEqual(intervalsOverlap(at('09:00'), at('10:00'), at('13:00'), at('14:00')), false);
});

test('the predicate accepts Date objects and strings as well as timestamps', () => {
    assert.strictEqual(
        intervalsOverlap(new Date(at('09:00')), '2026-09-21T11:00:00', at('10:00'), at('10:30')),
        true
    );
});

test('an absent or invalid time converts to NaN rather than to zero', () => {
    assert.ok(Number.isNaN(toTime(null)));
    assert.ok(Number.isNaN(toTime(undefined)));
    assert.ok(Number.isNaN(toTime('')));
    assert.ok(Number.isNaN(toTime('not a date')));
});

// ---------------------------------------------------------------------------
// 2. The query bounds
// ---------------------------------------------------------------------------

test('the candidate window reaches back exactly one maximum session length', () => {
    const window = candidateWindow(at('14:00'), at('15:00'));
    assert.strictEqual(window.lowerExclusive, at('14:00') - MAX_SESSION_DURATION_MS);
    assert.strictEqual(window.lowerExclusive, at('10:00'));
    assert.strictEqual(window.upperExclusive, at('15:00'));
});

test('the filter bounds startTime on both sides', () => {
    const filter = buildCandidateFilter({ teacherId: 't-1', start: at('14:00'), end: at('15:00') });

    assert.ok(filter.startTime.$gt instanceof Date, 'a lower bound is required for an O(log n + k) scan');
    assert.ok(filter.startTime.$lt instanceof Date, 'an upper bound is required');
    assert.strictEqual(filter.startTime.$gt.getTime(), at('10:00'));
    assert.strictEqual(filter.startTime.$lt.getTime(), at('15:00'));
});

test('the filter matches only the teacher\'s active sessions', () => {
    const filter = buildCandidateFilter({ teacherId: 't-1', start: at('14:00'), end: at('15:00') });
    assert.strictEqual(filter.teacherId, 't-1');
    assert.strictEqual(filter.active, true, 'withdrawn sessions must not block new bookings');
});

test('the filter leaves endTime out, because the index cannot use it', () => {
    const filter = buildCandidateFilter({ teacherId: 't-1', start: at('14:00'), end: at('15:00') });
    assert.strictEqual(Object.prototype.hasOwnProperty.call(filter, 'endTime'), false);
});

test('a session being rescheduled is excluded from its own conflict search', () => {
    const filter = buildCandidateFilter({
        teacherId: 't-1', start: at('14:00'), end: at('15:00'), excludeId: 'session-7'
    });
    assert.deepStrictEqual(filter._id, { $ne: 'session-7' });
});

test('a new session carries no exclusion', () => {
    const filter = buildCandidateFilter({ teacherId: 't-1', start: at('14:00'), end: at('15:00') });
    assert.strictEqual(Object.prototype.hasOwnProperty.call(filter, '_id'), false);
});

test('the first overlap returned is the earliest one', () => {
    const candidates = [
        { title: 'A', startTime: at('09:00'), endTime: at('10:00') },
        { title: 'B', startTime: at('10:00'), endTime: at('11:00') },
        { title: 'C', startTime: at('11:00'), endTime: at('12:00') }
    ];
    assert.strictEqual(findFirstOverlap(candidates, at('10:30'), at('11:30')).title, 'B');
    assert.strictEqual(findFirstOverlap(candidates, at('12:00'), at('13:00')), null);
});

// ---------------------------------------------------------------------------
// 3. The pre-save check
// ---------------------------------------------------------------------------

/** A stub model recording each query and answering with fixed candidates. */
const stubModel = (candidates = []) => ({
    calls: [],
    find(filter, projection, options) {
        this.calls.push({ filter, projection, options });
        return Promise.resolve(candidates);
    }
});

const proposal = (start, end, extra = {}) => ({
    title: 'Beginner English A1',
    teacherId: 't-1',
    startTime: `2026-09-21T${start}:00`,
    endTime: `2026-09-21T${end}:00`,
    ...extra
});

test('a proposal with no candidates passes', async () => {
    const check = createScheduleConflictCheck(stubModel([]));
    assert.strictEqual(await check(proposal('09:00', '11:00'), {}), null);
});

test('an overlapping candidate is refused with 409 and named in the message', async () => {
    const model = stubModel([
        { title: 'Intermediate B1', startTime: new Date(at('10:00')), endTime: new Date(at('12:00')) }
    ]);
    const failure = await createScheduleConflictCheck(model)(proposal('09:00', '11:00'), {});

    assert.strictEqual(failure.status, CONFLICT_STATUS);
    assert.strictEqual(failure.status, 409);
    assert.match(failure.message, /Intermediate B1/);
});

test('a candidate that only touches the proposal is not a conflict', async () => {
    // The window query can return a session ending exactly as the proposal
    // begins. The exact overlap test must then let it through.
    const model = stubModel([
        { title: 'Earlier lesson', startTime: new Date(at('07:00')), endTime: new Date(at('09:00')) }
    ]);
    assert.strictEqual(await createScheduleConflictCheck(model)(proposal('09:00', '11:00'), {}), null);
});

test('the query projects only the fields it needs and sorts by start time', async () => {
    const model = stubModel([]);
    await createScheduleConflictCheck(model)(proposal('09:00', '11:00'), {});

    const { projection, options } = model.calls[0];
    assert.strictEqual(projection, 'title startTime endTime');
    assert.deepStrictEqual(options.sort, { startTime: 1 });
    assert.strictEqual(options.lean, true);
});

test('a partial update is checked against the session as it will be saved', async () => {
    const model = stubModel([]);
    const existing = {
        _id: 'session-7',
        teacherId: 't-1',
        startTime: new Date(at('09:00')),
        endTime: new Date(at('11:00'))
    };

    // Only the end time is submitted; teacher and start come from the record.
    await createScheduleConflictCheck(model)(
        { endTime: '2026-09-21T12:00:00' },
        { existing }
    );

    const { filter } = model.calls[0];
    assert.strictEqual(filter.teacherId, 't-1');
    assert.strictEqual(filter.startTime.$lt.getTime(), at('12:00'));
    assert.deepStrictEqual(filter._id, { $ne: 'session-7' });
});

test('an update that leaves the teacher and times unchanged runs no query', async () => {
    const model = stubModel([]);
    const existing = {
        _id: 'session-7',
        teacherId: 't-1',
        startTime: new Date(at('09:00')),
        endTime: new Date(at('11:00'))
    };

    const failure = await createScheduleConflictCheck(model)(
        { ...proposal('09:00', '11:00'), room: 'Room 4' },
        { existing }
    );

    assert.strictEqual(failure, null);
    assert.strictEqual(model.calls.length, 0, 'editing only the room should cost no query');
});

test('a proposal that validation will reject is left to validation', async () => {
    const model = stubModel([]);
    const check = createScheduleConflictCheck(model);

    assert.strictEqual(await check(proposal('09:00', '18:00'), {}), null, 'over the maximum');
    assert.strictEqual(await check(proposal('09:00', '09:10'), {}), null, 'under the minimum');
    assert.strictEqual(await check(proposal('11:00', '09:00'), {}), null, 'end before start');
    assert.strictEqual(await check({ teacherId: 't-1' }, {}), null, 'no times at all');

    assert.strictEqual(model.calls.length, 0,
        'no query should run for a session that cannot be saved anyway');
});
