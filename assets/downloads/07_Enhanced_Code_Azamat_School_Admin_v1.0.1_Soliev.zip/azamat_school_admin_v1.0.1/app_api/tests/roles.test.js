/**
 * Tests for the role and permission system.
 *
 * Every role is checked against every action, and the cases that must be
 * refused are tested as deliberately as the cases that must be allowed. A
 * permission system is only as good as its denials, and a test suite that only
 * confirms the happy path would pass just as readily against a function that
 * always returned true.
 *
 * Run with: npm test
 *
 * @file    app_api/tests/roles.test.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const { ROLES, DEFAULT_ROLE, expandRole, isAuthorized, isValidRole } = require('../config/roles');

test('owner inherits both subordinate roles', () => {
    const effective = expandRole(ROLES.OWNER);

    assert.ok(effective.includes(ROLES.OWNER), 'owner should include its own role');
    assert.ok(effective.includes(ROLES.ACCOUNTANT), 'owner should inherit accountant');
    assert.ok(effective.includes(ROLES.TEACHER), 'owner should inherit teacher');
});

test('subordinate roles inherit nothing', () => {
    assert.deepStrictEqual(expandRole(ROLES.ACCOUNTANT), [ROLES.ACCOUNTANT]);
    assert.deepStrictEqual(expandRole(ROLES.TEACHER), [ROLES.TEACHER]);
});

test('an unrecognized role expands to nothing', () => {
    assert.deepStrictEqual(expandRole('superuser'), []);
    assert.deepStrictEqual(expandRole(undefined), []);
    assert.deepStrictEqual(expandRole(null), []);
});

test('owner is authorized for every action any role may perform', () => {
    [[ROLES.OWNER], [ROLES.ACCOUNTANT], [ROLES.TEACHER], [ROLES.ACCOUNTANT, ROLES.TEACHER]]
        .forEach((allowed) => {
            assert.strictEqual(
                isAuthorized(ROLES.OWNER, allowed), true,
                `owner should be allowed when permitted roles are ${allowed.join(', ')}`
            );
        });
});

test('accountant is refused teacher-only and owner-only actions', () => {
    assert.strictEqual(isAuthorized(ROLES.ACCOUNTANT, [ROLES.TEACHER]), false);
    assert.strictEqual(isAuthorized(ROLES.ACCOUNTANT, [ROLES.OWNER]), false);
});

test('accountant is allowed accountant actions', () => {
    assert.strictEqual(isAuthorized(ROLES.ACCOUNTANT, [ROLES.ACCOUNTANT]), true);
    assert.strictEqual(isAuthorized(ROLES.ACCOUNTANT, [ROLES.OWNER, ROLES.ACCOUNTANT]), true);
});

test('teacher is refused accountant-only and owner-only actions', () => {
    assert.strictEqual(isAuthorized(ROLES.TEACHER, [ROLES.ACCOUNTANT]), false);
    assert.strictEqual(isAuthorized(ROLES.TEACHER, [ROLES.OWNER]), false);
    assert.strictEqual(isAuthorized(ROLES.TEACHER, [ROLES.OWNER, ROLES.ACCOUNTANT]), false);
});

test('teacher is allowed teacher actions', () => {
    assert.strictEqual(isAuthorized(ROLES.TEACHER, [ROLES.TEACHER]), true);
    assert.strictEqual(isAuthorized(ROLES.TEACHER, [ROLES.OWNER, ROLES.TEACHER]), true);
});

test('an absent or unknown role is never authorized', () => {
    assert.strictEqual(isAuthorized(undefined, [ROLES.TEACHER]), false);
    assert.strictEqual(isAuthorized(null, [ROLES.OWNER]), false);
    assert.strictEqual(isAuthorized('', [ROLES.TEACHER]), false);
    assert.strictEqual(isAuthorized('superuser', [ROLES.OWNER, ROLES.TEACHER]), false);
});

test('an empty or malformed permission list refuses everyone, including owner', () => {
    assert.strictEqual(isAuthorized(ROLES.OWNER, []), false);
    assert.strictEqual(isAuthorized(ROLES.OWNER, undefined), false);
    assert.strictEqual(isAuthorized(ROLES.OWNER, null), false);
});

test('the default role for a new account is the least privileged', () => {
    assert.strictEqual(DEFAULT_ROLE, ROLES.TEACHER);
    assert.notStrictEqual(DEFAULT_ROLE, ROLES.OWNER);
});

test('role validation accepts only defined roles', () => {
    assert.strictEqual(isValidRole(ROLES.OWNER), true);
    assert.strictEqual(isValidRole(ROLES.ACCOUNTANT), true);
    assert.strictEqual(isValidRole(ROLES.TEACHER), true);
    assert.strictEqual(isValidRole('administrator'), false);
    assert.strictEqual(isValidRole(''), false);
    assert.strictEqual(isValidRole(undefined), false);
});
