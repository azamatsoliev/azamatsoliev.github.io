/**
 * Tests for the attendance write policy.
 *
 * @file    app_api/tests/attendancePolicy.test.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const { createAttendanceWritePolicy } = require('../scheduling/attendancePolicy');
const createCrudController = require('../controllers/crudControllerFactory');
const { ROLES } = require('../config/roles');

const OWN_SESSION = 'c00000000000000000000001';
const FOREIGN_SESSION = 'c00000000000000000000003';
const DILNOZA = { id: 'u2', role: ROLES.TEACHER, teacherId: 't-dilnoza' };

/** A ClassSession stub that knows which teacher owns which session. */
const sessions = () => {
    const owners = { [OWN_SESSION]: 't-dilnoza', [FOREIGN_SESSION]: 't-jasur' };
    return {
        queries: [],
        async findOne(filter) {
            this.queries.push(filter);
            const owner = owners[filter._id];
            return owner && owner === filter.teacherId && filter.active === true ? { _id: filter._id } : null;
        }
    };
};

test('a teacher may record attendance for their own session', async () => {
    const policy = createAttendanceWritePolicy(sessions());
    assert.strictEqual(await policy({ classSessionId: OWN_SESSION }, { user: DILNOZA }), null);
});

test('a teacher may not record attendance for a colleague\'s session', async () => {
    const policy = createAttendanceWritePolicy(sessions());
    const failure = await policy({ classSessionId: FOREIGN_SESSION }, { user: DILNOZA });
    assert.strictEqual(failure.status, 403);
});

test('a teacher may not move their own record onto a colleague\'s session', async () => {
    const policy = createAttendanceWritePolicy(sessions());
    const existing = { _id: 'a1', classSessionId: OWN_SESSION };
    const failure = await policy({ classSessionId: FOREIGN_SESSION }, { user: DILNOZA, existing });
    assert.strictEqual(failure.status, 403);
});

test('an update that leaves the session unchanged is checked against the stored session', async () => {
    const model = sessions();
    const policy = createAttendanceWritePolicy(model);
    const existing = { _id: 'a1', classSessionId: OWN_SESSION };

    assert.strictEqual(await policy({ present: false }, { user: DILNOZA, existing }), null);
    assert.strictEqual(model.queries[0]._id, OWN_SESSION);
});

test('the ownership query requires the session to be active and the teacher\'s own', async () => {
    const model = sessions();
    await createAttendanceWritePolicy(model)({ classSessionId: OWN_SESSION }, { user: DILNOZA });
    assert.deepStrictEqual(model.queries[0], { _id: OWN_SESSION, teacherId: 't-dilnoza', active: true });
});

test('a teacher account with no teacher record is refused', async () => {
    const policy = createAttendanceWritePolicy(sessions());
    const failure = await policy({ classSessionId: OWN_SESSION }, { user: { id: 'u9', role: ROLES.TEACHER } });
    assert.strictEqual(failure.status, 403);
});

test('an owner is not restricted and causes no query', async () => {
    const model = sessions();
    const policy = createAttendanceWritePolicy(model);
    assert.strictEqual(await policy({ classSessionId: FOREIGN_SESSION }, { user: { id: 'u1', role: ROLES.OWNER } }), null);
    assert.strictEqual(model.queries.length, 0);
});

test('through the controller, a cross-teacher attendance record is refused and never saved', async () => {
    let created = false;
    const controller = createCrudController({ create: async () => { created = true; } }, {
        name: 'attendance',
        permissions: { create: [ROLES.OWNER, ROLES.TEACHER] },
        writableFields: ['studentId', 'classSessionId', 'present'],
        preSaveChecks: [createAttendanceWritePolicy(sessions())]
    });
    const res = { status(c) { this.code = c; return this; }, json(b) { this.body = b; return this; } };

    await controller.create({ auth: DILNOZA, body: { studentId: 's1', classSessionId: FOREIGN_SESSION, present: true } }, res);

    assert.strictEqual(res.code, 403);
    assert.strictEqual(created, false, 'no attendance, and so no charge, may be recorded');
});
