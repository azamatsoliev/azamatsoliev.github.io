/**
 * Tests for the class session edit policy.
 *
 * @file    app_api/tests/sessionEditPolicy.test.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const { restrictTeacherSessionEdits } = require('../scheduling/sessionEditPolicy');
const { ROLES } = require('../config/roles');

const TEACHER = { id: 'u2', role: ROLES.TEACHER, teacherId: 't-100' };
const OWNER = { id: 'u1', role: ROLES.OWNER };

const existing = {
    _id: 'session-1',
    teacherId: 't-100',
    ratePerClass: 25,
    title: 'Beginner English A1',
    room: 'Room 1'
};

test('a teacher may not reassign their session to another teacher', async () => {
    const failure = await restrictTeacherSessionEdits({ teacherId: 't-999' }, { user: TEACHER, existing });
    assert.strictEqual(failure.status, 403);
});

test('a teacher may not change the rate students are charged', async () => {
    const failure = await restrictTeacherSessionEdits({ ratePerClass: 40 }, { user: TEACHER, existing });
    assert.strictEqual(failure.status, 403);
});

test('a teacher may reschedule and rename their session', async () => {
    const failure = await restrictTeacherSessionEdits(
        { title: 'Beginner A1 (moved)', startTime: '2026-09-22T09:00', endTime: '2026-09-22T11:00', room: 'Room 3' },
        { user: TEACHER, existing }
    );
    assert.strictEqual(failure, null);
});

test('unchanged locked fields sent by the interface are accepted', async () => {
    // The edit form submits every field. Resending the stored values is not a change.
    const failure = await restrictTeacherSessionEdits(
        { teacherId: 't-100', ratePerClass: 25, room: 'Room 2' },
        { user: TEACHER, existing }
    );
    assert.strictEqual(failure, null);
});

test('the same value in a different form is not treated as a change', async () => {
    const failure = await restrictTeacherSessionEdits(
        { teacherId: { toString: () => 't-100' }, ratePerClass: '25' },
        { user: TEACHER, existing }
    );
    assert.strictEqual(failure, null);
});

test('an owner may reassign and reprice a session', async () => {
    const failure = await restrictTeacherSessionEdits(
        { teacherId: 't-999', ratePerClass: 40 },
        { user: OWNER, existing }
    );
    assert.strictEqual(failure, null);
});

test('the policy does not apply to creation', async () => {
    const failure = await restrictTeacherSessionEdits({ teacherId: 't-999' }, { user: TEACHER });
    assert.strictEqual(failure, null);
});
