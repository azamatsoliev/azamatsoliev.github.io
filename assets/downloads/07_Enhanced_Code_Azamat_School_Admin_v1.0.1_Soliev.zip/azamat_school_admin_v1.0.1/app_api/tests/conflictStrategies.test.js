/**
 * Correctness and complexity tests for the conflict-detection strategies.
 *
 * Differential testing: the naive scan is simple enough to be obviously
 * correct, so it serves as the reference. The optimized bounded scan is run
 * against it on thousands of randomly generated schedules and proposals, and
 * must reach the same verdict every time. A single disagreement would mean the
 * optimization had changed the answer, not just the speed.
 *
 * Property testing: across every generated case, the number of candidates the
 * bounded scan examines must never exceed the proven bound of 32. A dense,
 * adversarial schedule then shows the bound is actually reachable, so it is a
 * tight bound rather than a loose one.
 *
 * The final test demonstrates the trade-off. It shows the bounded scan missing
 * a conflict when a session exceeds the maximum duration, which is precisely
 * why that maximum is enforced on every write.
 *
 * Every random case derives from a fixed seed, so any failure is reproducible.
 *
 * @file    app_api/tests/conflictStrategies.test.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const {
    MINUTE_MS,
    createRandom,
    generateSchedule,
    randomProposal,
    forwardProposal
} = require('../tools/benchmark/scheduleGenerator');
const {
    naiveScan,
    unboundedIndexScan,
    boundedIndexScan
} = require('../tools/benchmark/strategies');
const {
    MAX_SESSION_DURATION_MS,
    MIN_SESSION_DURATION_MS
} = require('../models/classSession');

/** The derived ceiling on candidates: an 8-hour window of 15-minute sessions. */
const PROVEN_CANDIDATE_BOUND = (2 * MAX_SESSION_DURATION_MS) / MIN_SESSION_DURATION_MS;

test('the proven candidate bound is 32', () => {
    assert.strictEqual(PROVEN_CANDIDATE_BOUND, 32);
});

test('generated schedules satisfy the rules the application enforces', () => {
    const schedule = generateSchedule(5000, { seed: 11 });

    for (let i = 0; i < schedule.length; i += 1) {
        const duration = schedule[i].endTime - schedule[i].startTime;
        assert.ok(duration >= MIN_SESSION_DURATION_MS, `session ${i} is too short`);
        assert.ok(duration <= MAX_SESSION_DURATION_MS, `session ${i} is too long`);
        if (i > 0) {
            assert.ok(schedule[i].startTime >= schedule[i - 1].endTime, `sessions ${i - 1} and ${i} overlap`);
        }
    }
});

test('the bounded scan agrees with the naive scan on 5,000 random cases', () => {
    let disagreements = 0;
    let conflictsSeen = 0;

    for (let trial = 0; trial < 50; trial += 1) {
        const schedule = generateSchedule(500, { seed: 1000 + trial });
        const random = createRandom(9000 + trial);

        for (let q = 0; q < 100; q += 1) {
            const p = q % 2 === 0 ? randomProposal(random, schedule) : forwardProposal(random, schedule);
            const reference = naiveScan(schedule, p.startTime, p.endTime).conflict;
            const optimized = boundedIndexScan(schedule, p.startTime, p.endTime).conflict;

            if (reference !== optimized) {
                disagreements += 1;
            }
            if (reference) {
                conflictsSeen += 1;
            }
        }
    }

    assert.strictEqual(disagreements, 0, 'the optimization must never change the answer');
    assert.ok(conflictsSeen > 500, 'the test must exercise many real conflicts, not only clear schedules');
});

test('the unbounded scan also agrees, confirming it is correct but slow', () => {
    const schedule = generateSchedule(500, { seed: 77 });
    const random = createRandom(78);

    for (let q = 0; q < 1000; q += 1) {
        const p = randomProposal(random, schedule);
        assert.strictEqual(
            unboundedIndexScan(schedule, p.startTime, p.endTime).conflict,
            naiveScan(schedule, p.startTime, p.endTime).conflict
        );
    }
});

test('the candidate set never exceeds the proven bound on random schedules', () => {
    let largest = 0;

    for (let trial = 0; trial < 20; trial += 1) {
        const schedule = generateSchedule(2000, { seed: 500 + trial, maxGapMinutes: 30 });
        const random = createRandom(600 + trial);

        for (let q = 0; q < 200; q += 1) {
            const p = randomProposal(random, schedule);
            largest = Math.max(largest, boundedIndexScan(schedule, p.startTime, p.endTime).candidates);
        }
    }

    assert.ok(largest <= PROVEN_CANDIDATE_BOUND, `saw ${largest} candidates, above the bound`);
});

test('the bound is tight: a dense schedule reaches exactly 32 candidates', () => {
    // Worst case by construction: back-to-back sessions of the minimum length,
    // and a proposal of the maximum length placed off the quarter-hour grid so
    // the candidate window captures as many start times as it possibly can.
    const count = 400;
    const origin = Date.UTC(2026, 0, 5, 0, 0, 0);
    const dense = Array.from({ length: count }, (_, i) => ({
        startTime: origin + i * MIN_SESSION_DURATION_MS,
        endTime: origin + (i + 1) * MIN_SESSION_DURATION_MS
    }));

    const start = origin + 100 * MIN_SESSION_DURATION_MS + MINUTE_MS;
    const result = boundedIndexScan(dense, start, start + MAX_SESSION_DURATION_MS);

    assert.strictEqual(result.candidates, PROVEN_CANDIDATE_BOUND);
    assert.strictEqual(result.conflict, true);
});

test('examinations grow logarithmically for the bounded scan and linearly for the others', () => {
    const cost = (n) => {
        const schedule = generateSchedule(n, { seed: 42 });
        const random = createRandom(43);
        const p = forwardProposal(random, schedule);
        return {
            naive: naiveScan(schedule, p.startTime, p.endTime).examined,
            unbounded: unboundedIndexScan(schedule, p.startTime, p.endTime).examined,
            bounded: boundedIndexScan(schedule, p.startTime, p.endTime).examined
        };
    };

    const small = cost(1000);
    const large = cost(100000);

    // A hundredfold increase in history multiplies linear work by about 100...
    assert.ok(large.naive / small.naive >= 99);
    assert.ok(large.unbounded / small.unbounded >= 90);

    // ...but adds only a handful of steps to logarithmic work: log2(100) is about 6.6.
    assert.ok(large.bounded - small.bounded <= 12,
        `bounded work grew from ${small.bounded} to ${large.bounded}`);
});

test('the trade-off: the bounded scan misses a conflict if the maximum duration is not enforced', () => {
    // A six-hour session, which the schema would refuse. The proposal starts at
    // 13:00, so the window's lower edge is 13:00 minus four hours, 09:00. The
    // illegal session starts at 08:00, before that edge, so the bounded scan
    // never looks at it. The naive scan finds the conflict.
    const day = (hhmm) => new Date(`2026-09-21T${hhmm}:00`).getTime();
    const illegal = [{ startTime: day('08:00'), endTime: day('14:00') }];
    const start = day('13:00');
    const end = day('14:00');

    assert.strictEqual(naiveScan(illegal, start, end).conflict, true);
    assert.strictEqual(boundedIndexScan(illegal, start, end).conflict, false,
        'this is why the maximum session length must be enforced on every write');
});
