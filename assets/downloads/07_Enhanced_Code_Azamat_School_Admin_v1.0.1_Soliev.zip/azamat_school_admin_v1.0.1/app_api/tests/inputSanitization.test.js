/**
 * Tests for NoSQL operator-injection defenses.
 *
 * MongoDB interprets any object with a "$"-prefixed key as a query operator.
 * These tests confirm that such values are refused at the boundary, before any
 * pre-save check or database query can run with them.
 *
 * @file    app_api/tests/inputSanitization.test.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const createCrudController = require('../controllers/crudControllerFactory');
const { containsOperatorKey } = require('../controllers/crudControllerFactory');
const { ROLES } = require('../config/roles');

const createResponse = () => {
    const response = { statusCode: null, body: null };
    response.status = (code) => { response.statusCode = code; return response; };
    response.json = (payload) => { response.body = payload; return response; };
    return response;
};

test('plain values contain no operator', () => {
    assert.strictEqual(containsOperatorKey({ title: 'A1', ratePerClass: 25, subjects: ['English'] }), false);
    assert.strictEqual(containsOperatorKey({ startTime: new Date() }), false);
    assert.strictEqual(containsOperatorKey('$not-an-object'), false, 'a string starting with $ is just text');
});

test('an operator at any depth is detected', () => {
    assert.strictEqual(containsOperatorKey({ teacherId: { $ne: null } }), true);
    assert.strictEqual(containsOperatorKey({ a: { b: { $gt: 1 } } }), true);
    assert.strictEqual(containsOperatorKey({ list: [{ $where: 'sleep(1000)' }] }), true);
});

test('a dotted key is detected, since MongoDB reads it as a nested path', () => {
    assert.strictEqual(containsOperatorKey({ 'profile.role': 'owner' }), true);
});

test('a create carrying an operator is refused before any check or query runs', async () => {
    let checksRun = 0;
    const model = { create: async () => { throw new Error('must not be called'); } };
    const controller = createCrudController(model, {
        name: 'classsessions',
        permissions: { create: [ROLES.OWNER] },
        writableFields: ['title', 'teacherId'],
        preSaveChecks: [async () => { checksRun += 1; return null; }]
    });
    const res = createResponse();

    await controller.create({
        auth: { id: 'u1', role: ROLES.OWNER },
        body: { title: 'A1', teacherId: { $ne: null } }
    }, res);

    assert.strictEqual(res.statusCode, 400);
    assert.strictEqual(checksRun, 0, 'no check may run with an operator in hand');
});

test('an update carrying an operator is refused before it is written', async () => {
    let saved = false;
    const record = { _id: 's1', teacherId: 't1', save: async () => { saved = true; } };
    const model = { findOne: async () => record };
    const controller = createCrudController(model, {
        name: 'classsessions',
        permissions: { update: [ROLES.OWNER] },
        writableFields: ['title', 'teacherId']
    });
    const res = createResponse();

    await controller.update({
        auth: { id: 'u1', role: ROLES.OWNER },
        params: { id: 's1' },
        body: { teacherId: { $gt: '' } }
    }, res);

    assert.strictEqual(res.statusCode, 400);
    assert.strictEqual(saved, false);
});
