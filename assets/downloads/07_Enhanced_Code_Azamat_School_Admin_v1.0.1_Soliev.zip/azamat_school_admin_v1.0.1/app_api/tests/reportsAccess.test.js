/**
 * Tests for report access control and request handling.
 *
 * Two layers are tested. The routes decide which roles may reach each report,
 * and are tested through real HTTP requests with signed tokens; refused requests
 * never reach the database, so these run without one. The controller decides
 * what an admitted request may ask for, and is tested with a fake service that
 * records what it was asked.
 *
 * @file    app_api/tests/reportsAccess.test.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const express = require('express');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-unit-tests';

const { ROLES } = require('../config/roles');
const { createReportsController } = require('../controllers/reports');

const TEACHER_ID = 'a00000000000000000000001';
const OTHER_TEACHER_ID = 'a00000000000000000000002';

const tokenFor = (role, extra = {}) =>
    jwt.sign({ id: 'u1', role, ...extra }, process.env.JWT_SECRET, { expiresIn: '1h' });

/** Sends a GET request through the real API routes and resolves with the status. */
const statusFor = (path, token) => new Promise((resolve, reject) => {
    const app = express();
    app.set('query parser', 'simple');
    app.use('/api', require('../routes/index'));
    const server = http.createServer(app).listen(0, () => {
        const headers = token ? { Authorization: `Bearer ${token}` } : {};
        http.get({ port: server.address().port, path, headers }, (res) => {
            res.resume();
            server.close();
            resolve(res.statusCode);
        }).on('error', (error) => { server.close(); reject(error); });
    });
});

// ---------------------------------------------------------------------------
// Routes: which roles may reach which report
// ---------------------------------------------------------------------------

test('every report refuses a request with no token', async () => {
    for (const path of ['/api/reports/balances', '/api/reports/revenue?month=2026-10',
        '/api/reports/revenue.csv?month=2026-10', '/api/reports/revenue-by-month?year=2026',
        '/api/reports/classes?month=2026-10', '/api/reports/attendance-sheet?month=2026-10']) {
        assert.strictEqual(await statusFor(path), 401, path);
    }
});

test('a teacher cannot reach any financial report', async () => {
    const token = tokenFor(ROLES.TEACHER, { teacherId: TEACHER_ID });
    for (const path of ['/api/reports/balances', '/api/reports/revenue?month=2026-10',
        '/api/reports/revenue.csv?month=2026-10', '/api/reports/revenue-by-month?year=2026']) {
        assert.strictEqual(await statusFor(path, token), 403, path);
    }
});

test('a teacher cannot reach the owner\'s class summary', async () => {
    const token = tokenFor(ROLES.TEACHER, { teacherId: TEACHER_ID });
    assert.strictEqual(await statusFor('/api/reports/classes?month=2026-10', token), 403);
});

test('an accountant cannot reach the class summary or attendance sheets', async () => {
    const token = tokenFor(ROLES.ACCOUNTANT);
    assert.strictEqual(await statusFor('/api/reports/classes?month=2026-10', token), 403);
    assert.strictEqual(await statusFor('/api/reports/attendance-sheet?month=2026-10', token), 403);
});

// ---------------------------------------------------------------------------
// Controller: what an admitted request may ask for
// ---------------------------------------------------------------------------

/** A fake service that records its calls and returns canned data. */
const fakeService = (overrides = {}) => {
    const calls = [];
    const record = (name, value) => async (args) => { calls.push({ name, args }); return value; };
    return {
        calls,
        studentBalances: record('studentBalances', { rows: [] }),
        revenueByStudent: record('revenueByStudent', {
            month: '2026-10',
            rows: [{ lastName: '=HYPERLINK("http://x","Pay")', firstName: 'A', email: 'a@x.test', payments: 1, collected: 50 }],
            totals: { payments: 1, collected: 50 }
        }),
        revenueByMonth: record('revenueByMonth', { months: [] }),
        classSummary: record('classSummary', { rows: [] }),
        attendanceSheet: record('attendanceSheet', { sessions: [] }),
        ...overrides
    };
};

const createResponse = () => {
    const response = { statusCode: null, body: null, headers: {} };
    response.status = (code) => { response.statusCode = code; return response; };
    response.json = (payload) => { response.body = payload; return response; };
    response.send = (payload) => { response.body = payload; return response; };
    response.set = (name, value) => { response.headers[name.toLowerCase()] = value; return response; };
    return response;
};

test('a teacher always receives their own sheet, whatever teacherId they send', async () => {
    const service = fakeService();
    const reports = createReportsController(service);
    const res = createResponse();

    await reports.attendanceSheet({
        auth: { role: ROLES.TEACHER, teacherId: TEACHER_ID },
        query: { month: '2026-10', teacherId: OTHER_TEACHER_ID }
    }, res);

    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(service.calls[0].args.teacherId, TEACHER_ID,
        'the identifier must come from the signed token, never from the query');
});

test('a teacher account with no linked teacher record is refused', async () => {
    const res = createResponse();
    await createReportsController(fakeService()).attendanceSheet({
        auth: { role: ROLES.TEACHER, teacherId: null }, query: { month: '2026-10' }
    }, res);
    assert.strictEqual(res.statusCode, 403);
});

test('an owner must name a valid teacher', async () => {
    const reports = createReportsController(fakeService());

    for (const teacherId of [undefined, 'not-an-id', { $ne: null }, ['a', 'b']]) {
        const res = createResponse();
        await reports.attendanceSheet({ auth: { role: ROLES.OWNER }, query: { month: '2026-10', teacherId } }, res);
        assert.strictEqual(res.statusCode, 400, `should refuse ${JSON.stringify(teacherId)}`);
    }

    const service = fakeService();
    const res = createResponse();
    await createReportsController(service).attendanceSheet({
        auth: { role: ROLES.OWNER }, query: { month: '2026-10', teacherId: OTHER_TEACHER_ID }
    }, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(service.calls[0].args.teacherId, OTHER_TEACHER_ID);
});

test('a malformed month never reaches the service', async () => {
    const service = fakeService();
    const res = createResponse();
    await createReportsController(service).revenue({ auth: { role: ROLES.OWNER }, query: { month: '2026-13' } }, res);

    assert.strictEqual(res.statusCode, 400);
    assert.strictEqual(service.calls.length, 0);
});

test('report responses are marked not to be cached', async () => {
    const res = createResponse();
    await createReportsController(fakeService()).balances({ auth: { role: ROLES.OWNER }, query: {} }, res);
    assert.strictEqual(res.headers['cache-control'], 'no-store');
});

test('an unexpected failure is reported without exposing its details', async () => {
    const res = createResponse();
    const failing = fakeService({ studentBalances: async () => { throw new Error('connection to 10.0.0.5 refused'); } });
    const originalError = console.error;
    console.error = () => {};
    try {
        await createReportsController(failing).balances({ auth: { role: ROLES.OWNER }, query: {} }, res);
    } finally {
        console.error = originalError;
    }

    assert.strictEqual(res.statusCode, 500);
    assert.ok(!JSON.stringify(res.body).includes('10.0.0.5'), 'internal details must not reach the client');
});

test('the CSV export is a downloadable file with a total row and neutralized names', async () => {
    const res = createResponse();
    await createReportsController(fakeService()).revenueCsv({ auth: { role: ROLES.OWNER }, query: { month: '2026-10' } }, res);

    assert.strictEqual(res.statusCode, 200);
    assert.match(res.headers['content-type'], /^text\/csv/);
    assert.strictEqual(res.headers['content-disposition'], 'attachment; filename="revenue-2026-10.csv"');
    assert.strictEqual(res.headers['cache-control'], 'no-store');
    assert.match(res.body, /"'=HYPERLINK/, 'the formula must be neutralized');
    assert.match(res.body, /TOTAL,,,1,50\.00/);
});
