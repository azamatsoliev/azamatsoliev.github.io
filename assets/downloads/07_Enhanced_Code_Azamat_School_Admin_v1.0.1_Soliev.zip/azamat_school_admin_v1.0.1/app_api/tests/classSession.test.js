/**
 * Tests for class session validation.
 *
 * These cover the maximum-duration constraint, which is not an arbitrary rule.
 * Bounding session length is what will allow the scheduling conflict check to
 * search a fixed time window rather than a teacher's whole history, and the
 * guarantee only holds if the constraint is enforced on every write.
 *
 * They also guard against a regression found during testing. The hook was
 * originally written in the callback style, taking a next parameter. Current
 * Mongoose document middleware is promise-based and passes no such argument, so
 * calling it raised a TypeError, which surfaced to the user as an unexplained
 * server error rather than as a validation message.
 *
 * Validation runs without a database connection, so these need no MongoDB.
 *
 * @file    app_api/tests/classSession.test.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const ClassSession = require('../models/classSession');

const MAX_HOURS = ClassSession.MAX_SESSION_DURATION_MS / 3600000;

/** Builds a session with the given start and end, valid in every other respect. */
const sessionWith = (startTime, endTime) => new ClassSession({
    title: 'Beginner English A1',
    teacherId: '68cf1a2b3c4d5e6f77889900',
    ratePerClass: 25,
    startTime,
    endTime
});

/** Validates and returns the error, or null when the document is acceptable. */
const validationErrorFor = async (document) => {
    try {
        await document.validate();
        return null;
    } catch (error) {
        return error;
    }
};

test('the maximum duration is four hours', () => {
    assert.strictEqual(MAX_HOURS, 4);
});

test('a session of normal length is accepted', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T11:00'));
    assert.strictEqual(error, null);
});

test('a session of exactly the maximum duration is accepted', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T13:00'));
    assert.strictEqual(error, null, 'the boundary itself should be permitted');
});

test('a session one minute over the maximum is refused', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T13:01'));
    assert.ok(error, 'an over-length session must not validate');
    assert.strictEqual(error.name, 'ValidationError');
});

test('an over-length session reports a validation error, not an unexpected failure', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T18:00'));

    // The controller factory answers 400 for a ValidationError and 500 for
    // anything else, so the error type decides what the user is told.
    assert.strictEqual(error.name, 'ValidationError',
        'a TypeError here would surface to the user as an unexplained server error');
    assert.match(error.errors.endTime.message, /may not exceed 4 hours/);
});

test('an end time before the start time is refused', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T11:00', '2026-09-21T09:00'));

    assert.ok(error);
    assert.strictEqual(error.name, 'ValidationError');
    assert.match(error.errors.endTime.message, /later than the start time/);
});

test('a session ending at the moment it starts is refused', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T09:00'));
    assert.ok(error, 'a zero-length session is not a lesson');
});

test('validation does not fail when the times are absent', async () => {
    // Required-field validation reports the missing values. The duration hook
    // must not throw a separate error on its way there.
    const error = await validationErrorFor(sessionWith(undefined, undefined));

    assert.ok(error);
    assert.strictEqual(error.name, 'ValidationError');
});

test('the minimum duration is fifteen minutes', () => {
    assert.strictEqual(ClassSession.MIN_SESSION_DURATION_MS / 60000, 15);
});

test('a session one minute under the minimum is refused', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T09:14'));
    assert.ok(error);
    assert.strictEqual(error.name, 'ValidationError');
    assert.match(error.errors.endTime.message, /at least 15 minutes/);
});

test('a session of exactly the minimum duration is accepted', async () => {
    const error = await validationErrorFor(sessionWith('2026-09-21T09:00', '2026-09-21T09:15'));
    assert.strictEqual(error, null);
});

test('the conflict index orders equality fields before the range field', () => {
    // Equality-sort-range: teacherId and active are matched exactly, startTime
    // is scanned as a range, so startTime must come last.
    const conflictIndex = ClassSession.schema.indexes()
        .map(([fields]) => fields)
        .find((fields) => 'startTime' in fields);

    assert.deepStrictEqual(Object.keys(conflictIndex), ['teacherId', 'active', 'startTime']);
});

test('a session is labeled with its title, date and time, so repeats can be told apart', () => {
    const session = sessionWith('2026-10-12T09:00', '2026-10-12T11:00');
    assert.strictEqual(session.label, 'Beginner English A1 · 2026-10-12 09:00');
    assert.strictEqual(session.toJSON().label, session.label, 'the label must reach the interface');
});
