/**
 * Tests for sign-in rate limiting.
 *
 * Uses a small application whose sign-in handler always refuses, so the limiter
 * can be observed without a database or real accounts.
 *
 * @file    app_api/tests/rateLimit.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');
const express = require('express');

const { createLoginLimiter, LOGIN_ATTEMPT_LIMIT } = require('../middleware/rateLimit');
const { request } = require('./helpers/httpClient');

/** An application with a limited sign-in route that succeeds only when told to. */
const buildApp = (limiterOptions) => {
    const app = express();
    app.use(express.json());
    app.post('/login', createLoginLimiter(limiterOptions), (req, res) => {
        if (req.body && req.body.correct) {
            return res.status(200).json({ token: 'signed' });
        }
        return res.status(401).json({ message: 'Email or password is incorrect.' });
    });
    return app;
};

test('the default allows ten failed attempts per fifteen minutes', () => {
    assert.strictEqual(LOGIN_ATTEMPT_LIMIT, 10);
});

test('failed attempts beyond the limit are refused with 429', async () => {
    const app = buildApp({ limit: 3, windowMs: 60000 });

    for (let attempt = 1; attempt <= 3; attempt += 1) {
        assert.strictEqual((await request(app, { method: 'POST', path: '/login', body: {} })).status, 401);
    }

    const blocked = await request(app, { method: 'POST', path: '/login', body: {} });
    assert.strictEqual(blocked.status, 429);
    assert.match(blocked.body.message, /Too many sign-in attempts/);
});

test('successful sign-ins do not count toward the limit', async () => {
    const app = buildApp({ limit: 2, windowMs: 60000 });

    for (let attempt = 1; attempt <= 5; attempt += 1) {
        const res = await request(app, { method: 'POST', path: '/login', body: { correct: true } });
        assert.strictEqual(res.status, 200, 'a person signing in correctly is never held up');
    }
});

test('the response tells the client how long to wait', async () => {
    const app = buildApp({ limit: 1, windowMs: 60000 });
    await request(app, { method: 'POST', path: '/login', body: {} });
    const blocked = await request(app, { method: 'POST', path: '/login', body: {} });
    assert.strictEqual(blocked.status, 429);
    assert.ok(blocked.headers['ratelimit'] || blocked.headers['ratelimit-policy'],
        'standard rate-limit headers should be present');
});
