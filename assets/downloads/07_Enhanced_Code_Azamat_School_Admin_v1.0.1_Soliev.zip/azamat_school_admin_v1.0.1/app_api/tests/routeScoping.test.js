/**
 * Tests that each route is public or protected exactly as intended.
 *
 * Regression test for a defect introduced in Enhancement One. The entity router
 * applied its authentication check with router.use(), and because the router is
 * mounted at the API root, the check ran for every API request, including the
 * public routes mounted beside it. Visitors who were not signed in received 401
 * from routes that were meant to be open.
 *
 * Changed for the final release: the public trip listing that first exposed the
 * defect has been removed with the rest of the travel website. The same
 * guarantee is now checked against the real API, whose only public routes are
 * the health check and sign-in. Every other route must still demand a token,
 * and the removed routes must no longer exist.
 *
 * @file    app_api/tests/routeScoping.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-unit-tests-0123456789';

const app = require('../../app');
const { request } = require('./helpers/httpClient');

test('the health check is reachable without a token', async () => {
    const res = await request(app, { path: '/api/health' });
    assert.notStrictEqual(res.status, 401);
    assert.ok(['ok', 'degraded'].includes(res.body.status));
});

test('sign-in is reachable without a token', async () => {
    // An empty body is refused as a bad request, not as unauthenticated.
    const res = await request(app, { method: 'POST', path: '/api/login', body: {} });
    assert.strictEqual(res.status, 400);
});

test('every entity route requires a token', async () => {
    for (const path of ['/api/students', '/api/teachers', '/api/classsessions/abc', '/api/payments', '/api/attendance']) {
        const res = await request(app, { path });
        assert.strictEqual(res.status, 401, `${path} must require a token`);
    }
});

test('report and account routes require a token', async () => {
    assert.strictEqual((await request(app, { path: '/api/reports/balances' })).status, 401);
    assert.strictEqual((await request(app, { path: '/api/users' })).status, 401);
    assert.strictEqual((await request(app, { method: 'POST', path: '/api/users', body: {} })).status, 401);
});

test('public self-registration no longer exists', async () => {
    const res = await request(app, {
        method: 'POST',
        path: '/api/register',
        body: { name: 'Anyone', email: 'anyone@example.com', password: 'password123' }
    });
    assert.strictEqual(res.status, 404);
});

test('the travel endpoints inherited from the original application are gone', async () => {
    assert.strictEqual((await request(app, { path: '/api/trips' })).status, 404);
    assert.strictEqual((await request(app, { path: '/travel' })).status, 404);
});
