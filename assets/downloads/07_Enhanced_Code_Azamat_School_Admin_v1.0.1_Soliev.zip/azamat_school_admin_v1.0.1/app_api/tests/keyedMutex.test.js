/**
 * Tests for the keyed mutex.
 *
 * @file    app_api/tests/keyedMutex.test.js
 * @author  Azamat Soliev
 * @version 2.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const KeyedMutex = require('../utils/keyedMutex');

/** Resolves after the current turn of the event loop, letting others run. */
const yieldTurn = () => new Promise((resolve) => setImmediate(resolve));

test('tasks under the same key never run at the same time', async () => {
    const mutex = new KeyedMutex();
    let running = 0;
    let maxConcurrent = 0;

    const task = async () => {
        running += 1;
        maxConcurrent = Math.max(maxConcurrent, running);
        await yieldTurn();
        await yieldTurn();
        running -= 1;
    };

    await Promise.all(Array.from({ length: 10 }, () => mutex.runExclusive('teacher:1', task)));

    assert.strictEqual(maxConcurrent, 1);
});

test('tasks under the same key run in arrival order', async () => {
    const mutex = new KeyedMutex();
    const order = [];

    await Promise.all([1, 2, 3, 4, 5].map((n) => mutex.runExclusive('k', async () => {
        await yieldTurn();
        order.push(n);
    })));

    assert.deepStrictEqual(order, [1, 2, 3, 4, 5]);
});

test('tasks under different keys run concurrently', async () => {
    const mutex = new KeyedMutex();
    let running = 0;
    let maxConcurrent = 0;

    const task = async () => {
        running += 1;
        maxConcurrent = Math.max(maxConcurrent, running);
        await yieldTurn();
        running -= 1;
    };

    await Promise.all(['a', 'b', 'c'].map((key) => mutex.runExclusive(key, task)));

    assert.strictEqual(maxConcurrent, 3, 'unrelated teachers must not wait for each other');
});

test('a failing task releases the lock for the next one', async () => {
    const mutex = new KeyedMutex();

    await assert.rejects(mutex.runExclusive('k', async () => { throw new Error('boom'); }), /boom/);

    const result = await mutex.runExclusive('k', async () => 'next task ran');
    assert.strictEqual(result, 'next task ran');
});

test('a task\'s return value is passed through', async () => {
    const mutex = new KeyedMutex();
    assert.strictEqual(await mutex.runExclusive('k', async () => 42), 42);
});

test('keys are released once idle, so memory does not grow with use', async () => {
    const mutex = new KeyedMutex();

    await Promise.all(Array.from({ length: 100 }, (_, i) =>
        mutex.runExclusive(`teacher:${i}`, async () => { await yieldTurn(); })));

    assert.strictEqual(mutex.size, 0);
});

test('identifiers of different types for the same key share one lock', async () => {
    const mutex = new KeyedMutex();
    let running = 0;
    let maxConcurrent = 0;

    const task = async () => {
        running += 1;
        maxConcurrent = Math.max(maxConcurrent, running);
        await yieldTurn();
        running -= 1;
    };

    // An ObjectId-like object and its string form must serialize together.
    const idObject = { toString: () => '65f1a2b3c4d5e6f701000001' };
    await Promise.all([
        mutex.runExclusive(idObject, task),
        mutex.runExclusive('65f1a2b3c4d5e6f701000001', task)
    ]);

    assert.strictEqual(maxConcurrent, 1);
});
