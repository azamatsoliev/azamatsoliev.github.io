/**
 * Tests for the reporting pipelines and service.
 *
 * The real aggregation pipelines run here, unchanged, in mingo, an in-memory
 * implementation of MongoDB's aggregation language, against a fixture whose
 * every figure was calculated by hand (app_api/tools/reports/reportFixture.js).
 * The same fixture and figures are checked against a real MongoDB database by
 * app_api/tools/reports/verifyReports.js.
 *
 * One deliberate difference from MongoDB: MongoDB silently returns no matches
 * when a $lookup names a collection that does not exist, so a misspelt
 * collection name produces a report full of zeros and no error at all. The
 * engine here throws instead, so such a mistake fails a test loudly.
 *
 * @file    app_api/tests/reports.test.js
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { Aggregator } = require('mingo');

const { createReportService } = require('../reports/reportService');
const { buildFixture, EXPECTED, FIXED_NOW, PERIOD, ID } = require('../tools/reports/reportFixture');

/** Builds stub models whose aggregate() runs the pipeline in mingo. */
const createModels = (data) => {
    const store = {
        students: data.students,
        classsessions: data.classSessions,
        payments: data.payments,
        attendances: data.attendance
    };

    const resolve = (name) => {
        if (!Object.prototype.hasOwnProperty.call(store, name)) {
            throw new Error(`$lookup named a collection that does not exist: "${name}"`);
        }
        return structuredClone(store[name]);
    };

    const model = (collectionName) => ({
        collection: { collectionName },
        aggregate: async (pipeline) =>
            new Aggregator(pipeline, { collectionResolver: resolve }).run(resolve(collectionName))
    });

    return {
        Student: model('students'),
        ClassSession: model('classsessions'),
        Payment: model('payments'),
        Attendance: model('attendances')
    };
};

const service = () => createReportService({ models: createModels(buildFixture()), now: () => FIXED_NOW });

/** Picks the listed fields from each row, for comparison with hand-made expectations. */
const pick = (rows, fields) => rows.map((row) =>
    Object.fromEntries(fields.map((field) => [field, row[field]])));

// ---------------------------------------------------------------------------
// Balances
// ---------------------------------------------------------------------------

test('balances match the hand-calculated figures, row by row and in order', async () => {
    const report = await service().studentBalances();
    const fields = ['firstName', 'lastName', 'withdrawn', 'classesAttended', 'billed', 'paid', 'outstanding'];

    assert.deepStrictEqual(pick(report.rows, fields), EXPECTED.balances.rows);
    assert.deepStrictEqual(report.totals, EXPECTED.balances.totals);
});

test('a reversed payment is not counted as money received', async () => {
    const { rows } = await service().studentBalances();
    const aziza = rows.find((row) => row.lastName === 'Rahimova');
    assert.strictEqual(aziza.paid, 50, 'the reversed 20.00 must be excluded');
});

test('attendance at a canceled session is not billed', async () => {
    const { rows } = await service().studentBalances();
    const dilshod = rows.find((row) => row.lastName === 'Nazarov');
    assert.strictEqual(dilshod.billed, 0);
    assert.strictEqual(dilshod.classesAttended, 0);
});

test('a withdrawn attendance record is not billed', async () => {
    const { rows } = await service().studentBalances();
    const sevara = rows.find((row) => row.lastName === 'Yusupova');
    assert.strictEqual(sevara.billed, 25, 'only the active record at C2 may count');
    assert.strictEqual(sevara.outstanding, -15, 'an overpayment appears as a credit');
});

test('a withdrawn student who still owes money remains visible', async () => {
    const { rows } = await service().studentBalances();
    const malika = rows.find((row) => row.lastName === 'Ergasheva');
    assert.ok(malika, 'withdrawal must never hide a debt');
    assert.strictEqual(malika.withdrawn, true);
    assert.strictEqual(malika.outstanding, 30);
});

test('a withdrawn student settled to exactly zero is hidden, which floating point would get wrong', async () => {
    // Bekzod was billed 10.05 + 16.85 and paid 26.90. Summed as floating point
    // the balance is 3.5e-15, not zero, and he would wrongly appear as owing.
    // Scaled to cents but not rounded, it is still 0.0000000000005 cents out.
    // Only rounding each amount to whole cents before summing gives exactly zero.
    assert.notStrictEqual(10.05 + 16.85 - 26.90, 0, 'precondition: raw floating point misses zero');
    assert.notStrictEqual(10.05 * 100 + 16.85 * 100, 2690, 'precondition: unrounded cents miss too');

    const { rows } = await service().studentBalances();
    assert.strictEqual(rows.find((row) => row.lastName === 'Tursunov'), undefined);
});

// ---------------------------------------------------------------------------
// Revenue
// ---------------------------------------------------------------------------

test('monthly revenue lists each paying student once, with exact totals', async () => {
    const report = await service().revenueByStudent(PERIOD);

    assert.strictEqual(report.month, '2026-10');
    assert.deepStrictEqual(pick(report.rows, ['lastName', 'payments', 'collected']), EXPECTED.revenue.rows);
    assert.deepStrictEqual(report.totals, EXPECTED.revenue.totals);
});

test('revenue by month places each payment in its calendar month and shows all twelve', async () => {
    const report = await service().revenueByMonth(2026);

    assert.strictEqual(report.months.length, 12);
    assert.strictEqual(report.months[0].month, '2026-01');
    assert.deepStrictEqual(
        { payments: report.months[8].payments, collected: report.months[8].collected },
        EXPECTED.revenueByMonth.september
    );
    assert.deepStrictEqual(
        { payments: report.months[9].payments, collected: report.months[9].collected },
        EXPECTED.revenueByMonth.october
    );
    assert.strictEqual(report.months[0].collected, 0, 'a month with no payments reads zero, not missing');
    assert.deepStrictEqual(report.totals, EXPECTED.revenueByMonth.totals);
});

test('a payment on the 1st stays in its month whatever the server time zone', () => {
    // Runs the same report in separate processes set to time zones well behind
    // and well ahead of UTC. A payment dated 1 October is stored as midnight UTC,
    // which in New York is still 30 September; grouping in local time would move
    // it into September.
    const script = `
        const { Aggregator } = require('mingo');
        const { createReportService } = require(${JSON.stringify(path.join(__dirname, '..', 'reports', 'reportService'))});
        const { buildFixture } = require(${JSON.stringify(path.join(__dirname, '..', 'tools', 'reports', 'reportFixture'))});
        const data = buildFixture();
        const store = { students: data.students, classsessions: data.classSessions, payments: data.payments, attendances: data.attendance };
        const model = (name) => ({ collection: { collectionName: name },
            aggregate: async (p) => new Aggregator(p, { collectionResolver: (n) => store[n] }).run(store[name]) });
        createReportService({ models: { Student: model('students'), ClassSession: model('classsessions'),
            Payment: model('payments'), Attendance: model('attendances') } })
            .revenueByMonth(2026).then((r) => process.stdout.write(JSON.stringify([r.months[8], r.months[9]])));
    `;

    for (const zone of ['America/New_York', 'Pacific/Honolulu', 'Asia/Dubai', 'Pacific/Kiritimati']) {
        const result = spawnSync(process.execPath, ['-e', script], {
            env: { ...process.env, TZ: zone },
            cwd: path.join(__dirname, '..', '..'),
            encoding: 'utf8'
        });
        assert.strictEqual(result.status, 0, `${zone}: ${result.stderr}`);
        const [september, october] = JSON.parse(result.stdout);
        assert.strictEqual(september.collected, 26.9, `${zone}: September`);
        assert.strictEqual(october.collected, 90, `${zone}: October`);
    }
});

// ---------------------------------------------------------------------------
// Class summary
// ---------------------------------------------------------------------------

test('the class summary matches the hand-calculated figures', async () => {
    const report = await service().classSummary(PERIOD);
    const fields = ['title', 'sessions', 'recorded', 'present', 'attendanceRate', 'billed'];

    assert.deepStrictEqual(pick(report.rows, fields), EXPECTED.classSummary.rows);
    assert.deepStrictEqual(report.totals, EXPECTED.classSummary.totals);
});

test('a class whose attendance was never taken has no rate, rather than a rate of zero', async () => {
    const { rows } = await service().classSummary(PERIOD);
    const business = rows.find((row) => row.title === 'Business English');
    assert.strictEqual(business.recorded, 0);
    assert.strictEqual(business.attendanceRate, null, 'zero would claim nobody came; nobody was counted');
});

test('the class summary\'s billed total equals October billing summed by student', async () => {
    // Two independent routes to the same figure must agree.
    const { totals } = await service().classSummary(PERIOD);
    const byStudentCents = 8000 + 2690 + 3000 + 2500;
    assert.strictEqual(Math.round(totals.billed * 100), byStudentCents);
});

// ---------------------------------------------------------------------------
// Attendance sheet
// ---------------------------------------------------------------------------

test('a teacher\'s sheet labels each session correctly', async () => {
    const report = await service().attendanceSheet({ teacherId: ID.T_DILNOZA, period: PERIOD });

    assert.deepStrictEqual(report.sessions.map((s) => s.status), EXPECTED.attendanceSheet.statuses);
    assert.deepStrictEqual(report.summary, EXPECTED.attendanceSheet.summary);
});

test('a teacher\'s sheet contains only that teacher\'s sessions', async () => {
    const report = await service().attendanceSheet({ teacherId: ID.T_DILNOZA, period: PERIOD });
    assert.ok(report.sessions.every((s) => s.title === 'Beginner English A1'),
        'no session belonging to another teacher may appear');
});

test('a roster carries names and presence only, and excludes withdrawn records', async () => {
    const report = await service().attendanceSheet({ teacherId: ID.T_DILNOZA, period: PERIOD });
    const roster = report.sessions[0].roster;

    assert.deepStrictEqual(pick(roster, ['lastName', 'present']), EXPECTED.attendanceSheet.firstRoster);
    roster.forEach((entry) => {
        assert.deepStrictEqual(Object.keys(entry).sort(), ['firstName', 'lastName', 'present'],
            'no email, phone or financial field may reach a teacher');
    });
});
