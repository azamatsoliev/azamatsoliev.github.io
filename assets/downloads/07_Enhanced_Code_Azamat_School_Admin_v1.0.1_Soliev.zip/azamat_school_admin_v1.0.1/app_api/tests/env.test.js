/**
 * Tests for the startup environment checks.
 *
 * @file    app_api/tests/env.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const { validateEnvironment, MIN_SECRET_LENGTH } = require('../config/env');

const LONG_SECRET = 'a'.repeat(MIN_SECRET_LENGTH);

test('a missing signing secret is reported, with the command to create one', () => {
    const problems = validateEnvironment({});
    assert.strictEqual(problems.length, 1);
    assert.match(problems[0], /JWT_SECRET is not set/);
    assert.match(problems[0], /randomBytes/);
});

test('a blank signing secret counts as missing', () => {
    assert.match(validateEnvironment({ JWT_SECRET: '   ' })[0], /not set/);
});

test('a short signing secret is refused and its length is stated', () => {
    const problems = validateEnvironment({ JWT_SECRET: 'secret' });
    assert.strictEqual(problems.length, 1);
    assert.match(problems[0], /too short \(6 characters/);
});

test('a secret of the minimum length is accepted', () => {
    assert.deepStrictEqual(validateEnvironment({ JWT_SECRET: LONG_SECRET }), []);
});

test('a port that is not a number is reported', () => {
    const problems = validateEnvironment({ JWT_SECRET: LONG_SECRET, PORT: 'three thousand' });
    assert.strictEqual(problems.length, 1);
    assert.match(problems[0], /PORT must be a number/);
});

test('every problem is reported at once', () => {
    assert.strictEqual(validateEnvironment({ PORT: 'x' }).length, 2);
});
