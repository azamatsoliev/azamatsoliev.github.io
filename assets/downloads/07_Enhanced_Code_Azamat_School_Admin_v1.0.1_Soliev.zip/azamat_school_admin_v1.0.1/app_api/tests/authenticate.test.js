/**
 * Tests for bearer token extraction.
 *
 * These exist because of a specific defect found during the code review. The
 * original middleware split the Authorization header and then tested whether
 * the result had fewer than one element, a condition String.prototype.split
 * cannot produce, so the branch was unreachable and the malformed-header case
 * it was reaching for went unhandled.
 *
 * Each malformed header below would have passed through that original check.
 *
 * @file    app_api/tests/authenticate.test.js
 * @author  Azamat Soliev
 * @version 1.0
 * @date    September 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const { extractBearerToken } = require('../middleware/authenticate');

test('a well-formed bearer header yields the token', () => {
    assert.strictEqual(extractBearerToken('Bearer abc.def.ghi'), 'abc.def.ghi');
});

test('the scheme is matched case-insensitively, as the HTTP specification requires', () => {
    assert.strictEqual(extractBearerToken('bearer abc.def.ghi'), 'abc.def.ghi');
    assert.strictEqual(extractBearerToken('BEARER abc.def.ghi'), 'abc.def.ghi');
});

test('surrounding and repeated whitespace is tolerated', () => {
    assert.strictEqual(extractBearerToken('  Bearer   abc.def.ghi  '), 'abc.def.ghi');
});

test('an absent header yields no token', () => {
    assert.strictEqual(extractBearerToken(undefined), null);
    assert.strictEqual(extractBearerToken(null), null);
    assert.strictEqual(extractBearerToken(''), null);
    assert.strictEqual(extractBearerToken('   '), null);
});

test('a header with no scheme yields no token', () => {
    // The original implementation would have split this into one element,
    // passed its own check, and then read index 1, which is undefined.
    assert.strictEqual(extractBearerToken('abc.def.ghi'), null);
});

test('an unsupported authentication scheme yields no token', () => {
    assert.strictEqual(extractBearerToken('Basic dXNlcjpwYXNz'), null);
    assert.strictEqual(extractBearerToken('Token abc.def.ghi'), null);
});

test('a scheme with no credential yields no token', () => {
    assert.strictEqual(extractBearerToken('Bearer'), null);
    assert.strictEqual(extractBearerToken('Bearer '), null);
});

test('extra tokens after the credential are rejected rather than ignored', () => {
    assert.strictEqual(extractBearerToken('Bearer abc.def.ghi extra'), null);
});

test('a non-string header yields no token', () => {
    assert.strictEqual(extractBearerToken({}), null);
    assert.strictEqual(extractBearerToken(12345), null);
});
