/**
 * Tests for account administration: creating staff accounts and changing roles.
 *
 * Database calls are replaced with stubs, so these run without MongoDB.
 *
 * @file    app_api/tests/accounts.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-unit-tests-0123456789';

const mongoose = require('mongoose');
require('../models/db');
const User = mongoose.model('users');
const Teacher = mongoose.model('teachers');
const { createUser, setUserRole, resolveTeacherLink, MIN_PASSWORD_LENGTH } = require('../controllers/users');
const { ROLES } = require('../config/roles');

const TEACHER_ID = new mongoose.Types.ObjectId().toString();
const OWNER_AUTH = { id: 'owner-1', role: ROLES.OWNER };

/** Captures the status and body a handler responds with. */
const createResponse = () => {
    const response = { statusCode: null, body: null };
    response.status = (code) => { response.statusCode = code; return response; };
    response.json = (payload) => { response.body = payload; return response; };
    return response;
};

/** Replaces a method for the duration of one test. */
const stub = async (target, method, replacement, run) => {
    const original = target[method];
    target[method] = replacement;
    try {
        await run();
    } finally {
        target[method] = original;
    }
};

const validBody = (overrides = {}) => ({
    name: 'Jasur Aliev',
    email: 'jasur@school.example',
    password: 'TeacherPass123',
    role: ROLES.TEACHER,
    teacherId: TEACHER_ID,
    ...overrides
});

// ---------------------------------------------------------------------------
// Creating an account
// ---------------------------------------------------------------------------

test('name, email and password are all required, as text', async () => {
    for (const body of [{}, validBody({ name: '' }), validBody({ email: { $gt: '' } }), validBody({ password: 12345678 })]) {
        const res = createResponse();
        await createUser({ auth: OWNER_AUTH, body }, res);
        assert.strictEqual(res.statusCode, 400);
    }
});

test('a password shorter than the minimum is refused', async () => {
    const res = createResponse();
    await createUser({ auth: OWNER_AUTH, body: validBody({ password: 'a'.repeat(MIN_PASSWORD_LENGTH - 1) }) }, res);
    assert.strictEqual(res.statusCode, 400);
    assert.match(res.body.message, new RegExp(`${MIN_PASSWORD_LENGTH} characters`));
});

test('an unknown role is refused', async () => {
    const res = createResponse();
    await createUser({ auth: OWNER_AUTH, body: validBody({ role: 'superuser' }) }, res);
    assert.strictEqual(res.statusCode, 400);
});

test('an account is created with its role and teacher link, and no credential material is returned', async () => {
    let saved = null;

    await stub(Teacher, 'exists', async () => ({ _id: TEACHER_ID }), async () => {
        await stub(User.prototype, 'save', async function () { saved = this; return this; }, async () => {
            const res = createResponse();
            await createUser({ auth: OWNER_AUTH, body: validBody() }, res);

            assert.strictEqual(res.statusCode, 201);
            assert.strictEqual(res.body.role, ROLES.TEACHER);
            assert.strictEqual(String(res.body.teacherId), TEACHER_ID);
            assert.strictEqual(res.body.hash, undefined);
            assert.strictEqual(res.body.salt, undefined);
            assert.strictEqual(res.body.token, undefined, 'the owner must not receive a token for someone else');
            assert.ok(saved.validPassword('TeacherPass123'), 'the password is stored as a verifiable hash');
        });
    });
});

test('an address already in use answers 409', async () => {
    await stub(Teacher, 'exists', async () => ({ _id: TEACHER_ID }), async () => {
        await stub(User.prototype, 'save', async () => { const error = new Error('dup'); error.code = 11000; throw error; }, async () => {
            const res = createResponse();
            await createUser({ auth: OWNER_AUTH, body: validBody() }, res);
            assert.strictEqual(res.statusCode, 409);
        });
    });
});

// ---------------------------------------------------------------------------
// The teacher link
// ---------------------------------------------------------------------------

test('a teacher link must be a valid identifier', async () => {
    const result = await resolveTeacherLink(ROLES.TEACHER, 'not-an-id');
    assert.strictEqual(result.error.status, 400);
});

test('a teacher link supplied as a query operator is refused before any lookup', async () => {
    let looked = false;
    await stub(Teacher, 'exists', async () => { looked = true; return null; }, async () => {
        const result = await resolveTeacherLink(ROLES.TEACHER, { $ne: null });
        assert.strictEqual(result.error.status, 400);
    });
    assert.strictEqual(looked, false);
});

test('a teacher link must point at an existing, active teacher', async () => {
    await stub(Teacher, 'exists', async () => null, async () => {
        const result = await resolveTeacherLink(ROLES.TEACHER, TEACHER_ID);
        assert.strictEqual(result.error.status, 400);
        assert.match(result.error.message, /does not exist or is inactive/);
    });
});

test('roles other than teacher never carry a teacher link', async () => {
    assert.deepStrictEqual(await resolveTeacherLink(ROLES.ACCOUNTANT, TEACHER_ID), { teacherId: null });
});

// ---------------------------------------------------------------------------
// Changing a role
// ---------------------------------------------------------------------------

test('an owner cannot change their own role', async () => {
    const res = createResponse();
    await setUserRole({ auth: OWNER_AUTH, params: { id: 'owner-1' }, body: { role: ROLES.TEACHER } }, res);
    assert.strictEqual(res.statusCode, 400);
});

test('an account identifier that cannot exist answers 404 rather than a server error', async () => {
    const res = createResponse();
    await setUserRole({ auth: OWNER_AUTH, params: { id: 'not-an-id' }, body: { role: ROLES.ACCOUNTANT } }, res);
    assert.strictEqual(res.statusCode, 404);
});
