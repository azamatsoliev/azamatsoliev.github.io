/**
 * Tests for application-wide behavior: error answers, headers and CORS.
 *
 * These exercise the real Express application. None of them needs a database,
 * because each request is answered before any query would run.
 *
 * @file    app_api/tests/app.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-unit-tests-0123456789';

const app = require('../../app');
const { request } = require('./helpers/httpClient');

test('an unknown path answers 404 as JSON, never an HTML page', async () => {
    const res = await request(app, { path: '/no/such/page' });
    assert.strictEqual(res.status, 404);
    assert.match(res.headers['content-type'], /application\/json/);
    assert.deepStrictEqual(res.body, { message: 'Not found.' });
});

test('a malformed JSON body answers 400 without echoing parser details', async () => {
    const res = await request(app, { method: 'POST', path: '/api/login', body: '{"email": ' });
    assert.strictEqual(res.status, 400);
    assert.deepStrictEqual(res.body, { message: 'The request body is not valid JSON.' });
});

test('an oversized body is refused with 413', async () => {
    const res = await request(app, {
        method: 'POST',
        path: '/api/login',
        body: { email: 'a@example.com', password: 'x'.repeat(200 * 1024) }
    });
    assert.strictEqual(res.status, 413);
});

test('the framework is not advertised and protective headers are present', async () => {
    const res = await request(app, { path: '/api/health' });
    assert.strictEqual(res.headers['x-powered-by'], undefined);
    assert.strictEqual(res.headers['x-content-type-options'], 'nosniff');
    assert.ok(res.headers['content-security-policy'], 'a content security policy should be sent');
});

test('a browser preflight is answered with 204 and the CORS headers', async () => {
    const res = await request(app, { method: 'OPTIONS', path: '/api/students' });
    assert.strictEqual(res.status, 204);
    assert.strictEqual(res.headers['access-control-allow-origin'], 'http://localhost:4200');
    assert.match(res.headers['access-control-allow-headers'], /Authorization/);
    assert.match(res.headers['access-control-allow-methods'], /DELETE/);
});

test('the health check reports the database state and nothing more', async () => {
    const res = await request(app, { path: '/api/health' });
    // No database is connected while the unit tests run.
    assert.strictEqual(res.status, 503);
    assert.deepStrictEqual(res.body, { status: 'degraded', database: 'disconnected' });
});
