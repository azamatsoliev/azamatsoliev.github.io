/**
 * Tests for database connection settings.
 *
 * @file    app_api/tests/database.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');

const {
    DEFAULT_DB_NAME,
    TOOL_DATABASES,
    resolveDbUri,
    toolDatabaseName,
    toolDbUri,
    redactUri
} = require('../config/database');

test('the application database is named for the application', () => {
    assert.strictEqual(DEFAULT_DB_NAME, 'azamat_school');
});

test('with no settings, the local development database is used', () => {
    assert.strictEqual(resolveDbUri({}), 'mongodb://127.0.0.1/azamat_school');
});

test('DB_HOST is honored', () => {
    assert.strictEqual(resolveDbUri({ DB_HOST: 'db.internal' }), 'mongodb://db.internal/azamat_school');
});

test('a full MONGODB_URI takes precedence, allowing an authenticated connection', () => {
    const uri = 'mongodb://app:secret@127.0.0.1:27017/azamat_school?authSource=azamat_school';
    assert.strictEqual(resolveDbUri({ MONGODB_URI: uri, DB_HOST: 'ignored' }), uri);
});

test('each development tool works in its own database, never the application one', () => {
    const names = Object.values(TOOL_DATABASES).map(toolDatabaseName);
    assert.deepStrictEqual(names, ['azamat_school_demo', 'azamat_school_reportcheck', 'azamat_school_benchmark']);
    assert.ok(!names.includes(DEFAULT_DB_NAME));
});

test('a tool ignores MONGODB_URI, which points at the real database', () => {
    const uri = toolDbUri(TOOL_DATABASES.DEMO, { MONGODB_URI: 'mongodb://real-server/azamat_school', DB_HOST: 'localhost' });
    assert.strictEqual(uri, 'mongodb://localhost/azamat_school_demo');
});

test('a password is hidden before a connection string is logged', () => {
    const redacted = redactUri('mongodb://app:Sup3r$ecret@127.0.0.1:27017/azamat_school');
    assert.strictEqual(redacted, 'mongodb://app:****@127.0.0.1:27017/azamat_school');
    assert.ok(!redacted.includes('Sup3r'), 'the password must not survive redaction');
});

test('the SRV connection form is redacted too', () => {
    assert.strictEqual(
        redactUri('mongodb+srv://admin:p%40ss@cluster0.example.net/azamat_school'),
        'mongodb+srv://admin:****@cluster0.example.net/azamat_school'
    );
});

test('a connection string without credentials is unchanged', () => {
    assert.strictEqual(redactUri('mongodb://127.0.0.1/azamat_school'), 'mongodb://127.0.0.1/azamat_school');
});
