/**
 * Tests for sign-in.
 *
 * The account lookup is replaced with a stub, so these run without a database.
 * The most important case is the last group: before the final release, an
 * error during the lookup escaped as an unhandled promise rejection, which
 * stops a Node process. One sign-in attempt while MongoDB was unreachable shut
 * the whole API down.
 *
 * @file    app_api/tests/authentication.test.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

const test = require('node:test');
const assert = require('node:assert');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-for-unit-tests-0123456789';

const mongoose = require('mongoose');
require('../models/db');
const User = mongoose.model('users');
const { verifyCredentials } = require('../config/passport');
const { login, credentialsAreWellFormed, MAX_EMAIL_LENGTH } = require('../controllers/authentication');
const { ROLES } = require('../config/roles');

/** Captures the status and body a handler responds with, and resolves once it has. */
const createResponse = () => {
    let settle;
    const done = new Promise((resolve) => { settle = resolve; });
    const response = { statusCode: null, body: null, done };
    response.status = (code) => { response.statusCode = code; return response; };
    response.json = (payload) => { response.body = payload; settle(); return response; };
    return response;
};

/** Replaces the account lookup for the duration of one test. */
const withLookup = async (lookup, run) => {
    const original = User.findOne;
    User.findOne = () => ({ exec: lookup });
    try {
        await run();
    } finally {
        User.findOne = original;
    }
};

/** An account whose password is known. */
const knownAccount = () => {
    const user = new User({ email: 'owner@school.example', name: 'School Owner', role: ROLES.OWNER });
    user.setPassword('CorrectHorse123');
    return user;
};

// ---------------------------------------------------------------------------
// Input checks
// ---------------------------------------------------------------------------

test('well-formed credentials are text of a sensible length', () => {
    assert.strictEqual(credentialsAreWellFormed('owner@school.example', 'secret-pass'), true);
    assert.strictEqual(credentialsAreWellFormed({ $gt: '' }, 'secret-pass'), false);
    assert.strictEqual(credentialsAreWellFormed('owner@school.example', ['secret']), false);
    assert.strictEqual(credentialsAreWellFormed('   ', 'secret-pass'), false);
    assert.strictEqual(credentialsAreWellFormed('owner@school.example', ''), false);
    assert.strictEqual(credentialsAreWellFormed(`${'a'.repeat(MAX_EMAIL_LENGTH)}@x.example`, 'secret-pass'), false);
});

test('a query operator in place of an email address is refused with 400', async () => {
    const res = createResponse();
    login({ body: { email: { $gt: '' }, password: 'CorrectHorse123' } }, res);
    await res.done;
    assert.strictEqual(res.statusCode, 400);
});

// ---------------------------------------------------------------------------
// Credential checks
// ---------------------------------------------------------------------------

test('the correct password signs in and returns a token carrying the role', async () => {
    await withLookup(async () => knownAccount(), async () => {
        const res = createResponse();
        login({ body: { email: 'owner@school.example', password: 'CorrectHorse123' } }, res);
        await res.done;

        assert.strictEqual(res.statusCode, 200);
        const payload = jwt.verify(res.body.token, process.env.JWT_SECRET);
        assert.strictEqual(payload.role, ROLES.OWNER);
    });
});

test('a wrong password and an unknown address get the same answer', async () => {
    let wrongPassword;
    let unknownAddress;

    await withLookup(async () => knownAccount(), async () => {
        wrongPassword = createResponse();
        login({ body: { email: 'owner@school.example', password: 'wrong-password' } }, wrongPassword);
        await wrongPassword.done;
    });

    await withLookup(async () => null, async () => {
        unknownAddress = createResponse();
        login({ body: { email: 'nobody@school.example', password: 'wrong-password' } }, unknownAddress);
        await unknownAddress.done;
    });

    assert.strictEqual(wrongPassword.statusCode, 401);
    assert.strictEqual(unknownAddress.statusCode, 401);
    assert.deepStrictEqual(wrongPassword.body, unknownAddress.body,
        'the answers must not reveal which addresses are registered');
});

// ---------------------------------------------------------------------------
// Database failure during sign-in
// ---------------------------------------------------------------------------

test('a failed account lookup is handed to Passport instead of escaping', async () => {
    const failure = new Error('Operation users.findOne() buffering timed out');

    await withLookup(async () => { throw failure; }, async () => {
        let received;
        await verifyCredentials('owner@school.example', 'CorrectHorse123', (error) => { received = error; });
        assert.strictEqual(received, failure);
    });
});

test('sign-in while the database is unreachable answers 503 and the server keeps running', async () => {
    const rejections = [];
    const onRejection = (reason) => rejections.push(reason);
    process.on('unhandledRejection', onRejection);

    try {
        await withLookup(async () => { throw new Error('connection refused'); }, async () => {
            const res = createResponse();
            login({ body: { email: 'owner@school.example', password: 'CorrectHorse123' } }, res);
            await res.done;

            assert.strictEqual(res.statusCode, 503);
            assert.match(res.body.message, /temporarily unavailable/);
        });

        // Give any stray rejection a chance to surface before checking.
        await new Promise((resolve) => setImmediate(resolve));
        assert.deepStrictEqual(rejections, [], 'no promise rejection may go unhandled');
    } finally {
        process.removeListener('unhandledRejection', onRejection);
    }
});
