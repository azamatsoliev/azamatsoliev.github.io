# Project figures

The figures quoted in the README, the narratives, the professional
self-assessment and the ePortfolio come from this page. Each figure was
produced by running the command shown against version 1.0.0; none is an
estimate.

## Size and scope

| Figure | Value | Source |
|---|---|---|
| Roles | 3 (owner, accountant, teacher) | `app_api/config/roles.js` |
| Managed entities | 5 (students, teachers, class sessions, payments, attendance) | `app_api/config/entities.js` |
| Reports | 6 endpoints, built on 5 aggregation pipelines | `app_api/routes/reports.js`, `app_api/reports/pipelines.js` |
| Password hashing | PBKDF2-HMAC-SHA512, 210,000 iterations | `app_api/models/user.js` |

## Automated tests

| Suite | Count | Command |
|---|---|---|
| Backend unit and integration tests | 214 passing | `npm test` |
| Angular unit tests (specs) | 69 passing | `cd app_admin && npm run test:ci` |
| Report verification on real MongoDB | recorded from the GitHub Actions run | `npm run verify:reports` |
| End-to-end browser tests on the running system | 5 tests; results recorded from the GitHub Actions run | `cd e2e && npm test` |

## Scheduling conflict detection (Enhancement Two)

In-memory benchmark, `npm run bench` (seed 20260921, 200 forward-booking
checks per size). "Examined" is the number of existing sessions each strategy
compares against the proposed one.

| Sessions in history (n) | Naive scan examined | Bounded search examined | Naive time per check | Bounded time per check |
|---|---|---|---|---|
| 1,000 | 1,000 | 11.8 | 0.3275 ms | 0.0040 ms |
| 10,000 | 10,000 | 14.3 | 2.02 ms | 0.0027 ms |
| 100,000 | 100,000 | 18.1 | 17.85 ms | 0.0008 ms |
| 1,000,000 | 1,000,000 | 21.9 | 155.79 ms | 0.0013 ms |

- Proven upper bound on candidates per check: k ≤ 32. Largest seen: 3.
- All three strategies (naive, indexed but unbounded, bounded) agreed on every
  verdict.
- Times depend on the machine; the examined counts do not.

## Dependency audit

| Package set | Result (`npm audit`) |
|---|---|
| API (`package.json`) | 0 known vulnerabilities |
| Admin interface, production dependencies | Advisories in the Angular 17 framework packages; fixed only in Angular 20 and later. See "Known limitations" in the README. |
