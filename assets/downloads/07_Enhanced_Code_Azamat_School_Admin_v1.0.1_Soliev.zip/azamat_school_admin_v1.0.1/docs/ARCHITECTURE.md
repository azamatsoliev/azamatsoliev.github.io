# Architecture

## Components

```mermaid
flowchart TB
    subgraph Browser
        UI["Angular admin app<br/>standalone components"]
        Int["Token interceptor<br/>attaches token to API calls only"]
        Guards["Route guards<br/>(convenience, not security)"]
    end

    subgraph API["Express API (Node.js)"]
        MW["helmet · flat query parser · JSON body limit · CORS"]
        Auth["Sign-in: Passport local strategy<br/>rate limited · issues JWT"]
        Verify["authenticate: verify JWT on every request"]
        Factory["Generic CRUD controller factory<br/>role → scope → fields → projection"]
        Checks["Pre-save checks<br/>edit policy · reference checks · conflict detection"]
        Lock["Per-teacher lock<br/>(KeyedMutex)"]
        Reports["Report service<br/>5 aggregation pipelines"]
    end

    DB[("MongoDB<br/>azamat_school")]

    UI --> Int --> MW
    MW --> Auth
    MW --> Verify --> Factory --> Checks --> Lock --> DB
    Verify --> Reports --> DB
    Auth --> DB
```

Two design choices carry most of the weight:

- **Configuration, not copies.** The five entities are described in
  `app_api/config/entities.js` (server) and
  `app_admin/src/app/config/entity-definitions.ts` (interface). One controller
  factory and one Angular screen serve all five. Adding a sixth entity means
  adding a schema and two descriptions. In the original application, the trip,
  its only record type, had twenty-one files of its own.
- **The server decides.** The interface hides what a role cannot do, but every
  request is authorized again on the server. A request made around the
  interface is refused just the same.

## How one request is handled

A teacher saving a change to a class session:

```mermaid
sequenceDiagram
    participant UI as Admin app
    participant API as Express API
    participant DB as MongoDB
    UI->>API: PUT /api/classsessions/:id + Bearer token
    API->>API: verify token signature and expiry
    API->>API: role check (teacher may update sessions)
    API->>DB: findOne({ _id, teacherId: own, active: true })
    alt not found or someone else's
        API-->>UI: 403 (never 404, so existence is not revealed)
    else found
        API->>API: keep only writable fields; refuse $ operators
        API->>API: edit policy: teacher may not change teacher or rate
        API->>API: acquire this teacher's lock
        API->>DB: candidates in window (start − 4h, end) via index
        alt overlap found
            API-->>UI: 409, naming the session already booked
        else no overlap
            API->>DB: save
            API-->>UI: 200 with the updated session
        end
        API->>API: release lock
    end
```

## Data model

```mermaid
erDiagram
    USER }o--o| TEACHER : "teacherId (teacher accounts)"
    TEACHER ||--o{ CLASSSESSION : teaches
    CLASSSESSION ||--o{ ATTENDANCE : "attendance at"
    STUDENT ||--o{ ATTENDANCE : attends
    STUDENT ||--o{ PAYMENT : pays

    USER {
        string email UK
        string name
        string role "owner | accountant | teacher"
        ObjectId teacherId
        string hash
        string salt
        number iterations
    }
    TEACHER {
        string firstName
        string lastName
        string email UK
        string_array subjects
        date hiredOn
        bool active
    }
    STUDENT {
        string firstName
        string lastName
        string email UK
        string phone
        date enrolledOn
        bool active
    }
    CLASSSESSION {
        string title
        ObjectId teacherId FK
        date startTime
        date endTime
        number ratePerClass "whole cents"
        string room
        bool active
    }
    ATTENDANCE {
        ObjectId studentId FK
        ObjectId classSessionId FK
        bool present
        date recordedOn
        string note
        bool active
    }
    PAYMENT {
        ObjectId studentId FK
        number amount "whole cents"
        date paidOn
        string method "cash | card | transfer"
        string reference
        bool active
    }
```

Records are never erased: deletion sets `active` to false, so attendance and
payment history survive. Every query and every report filters on it.

**Indexes and the queries they serve**

| Index | Serves |
|---|---|
| `classsessions { teacherId, active, startTime }` | The conflict check: equality on teacher and active, then a range on start time |
| `classsessions { active, startTime }` | Whole-school monthly reports |
| `attendances { studentId, classSessionId }` unique | One attendance record per student per lesson |
| Single-field indexes on references, `paidOn` and `active` | Lookups and report filters |

## Scheduling conflict detection

Sessions are half-open intervals `[start, end)`, so back-to-back lessons do
not clash. Sessions last 15 minutes to 4 hours. Any session that could overlap
a proposed one must therefore start inside the window
`(proposed start − 4 hours, proposed end)`, which the compound index can seek
to directly: O(log n) to find the window, then k candidates to test. Because no
two of a teacher's active sessions overlap, and each lasts at least 15 minutes,
at most 32 can start inside an 8-hour window, so k ≤ 32 whatever the history
size. The full proof is in the header of
`app_api/scheduling/conflictDetection.js`; measurements are in
[metrics.md](metrics.md).

## Reports

| Report | Endpoint | Roles | Pipeline joins |
|---|---|---|---|
| Balances | `GET /api/reports/balances` | Accountant, owner | students → attendances → class sessions; payments |
| Monthly revenue | `GET /api/reports/revenue?month=YYYY-MM` | Accountant, owner | payments → students |
| Revenue export | `GET /api/reports/revenue.csv?month=YYYY-MM` | Accountant, owner | as above, as CSV |
| Revenue by month | `GET /api/reports/revenue-by-month?year=YYYY` | Accountant, owner | payments, grouped by month |
| Class summary | `GET /api/reports/classes?month=YYYY-MM` | Owner | class sessions → attendances |
| Attendance sheet | `GET /api/reports/attendance-sheet?month=YYYY-MM` | Teacher (own), owner | class sessions → attendances → students |

Billing is per lesson attended, at that lesson's rate; a balance is the rates
of active lessons attended minus active payments. Every amount is converted to
integer cents inside the pipeline before it is summed, so totals are exact.
Payment dates are grouped by month in UTC, because they are entered as
calendar dates; lesson times are grouped in the server's local time, because
they are moments.

## API surface

| Method and path | Access |
|---|---|
| `GET /api/health` | Public |
| `POST /api/login` | Public, rate limited |
| `GET, POST /api/users` · `PUT /api/users/:id/role` | Owner |
| `GET, POST /api/students` · `GET, PUT, DELETE /api/students/:id` | Read: owner, accountant, teacher (names only). Write: owner |
| `.../teachers` | Owner |
| `.../classsessions` | Owner; teachers read and edit their own |
| `.../payments` | Owner, accountant; removal owner only |
| `.../attendance` | Owner; teachers for their own lessons |
| `GET /api/reports/...` | See the reports table |
