# Testing

Four layers of automated tests, each catching a different kind of defect. All
of them run in GitHub Actions on every push, against a real MongoDB server
where one is needed.

| Layer | What it proves | Command | Count |
|---|---|---|---|
| Backend unit and integration | Each rule in the API behaves as specified, including what it refuses | `npm test` | 214 |
| Angular unit | Each screen offers the right actions for each role and handles failures | `cd app_admin && npm run test:ci` | 69 |
| Report verification | The reporting pipelines produce the hand-calculated figures inside MongoDB itself, using the intended indexes | `npm run verify:reports` | 14 checks |
| End-to-end | The whole system works together in a real browser, for each role | `cd e2e && npm test` | 5 |

## Backend tests

Run with Node's built-in test runner; no database is needed. Database calls
are replaced with stubs that record what the code asked for, so a test can
assert the query that would have run, not only the answer.

- **Authorization:** role checks, record scoping, the 403-not-404 rule,
  field whitelisting and projections (`crudControllerFactory.test.js`,
  `roles.test.js`, `routeScoping.test.js`, `reportsAccess.test.js`).
- **Scheduling:** conflict detection against thousands of randomly generated
  schedules, compared with a deliberately simple reference implementation
  (`conflictDetection.test.js`, `conflictStrategies.test.js`), and
  simultaneous bookings (`schedulingConcurrency.test.js`).
- **Reports:** the production pipelines run unchanged in mingo, an in-memory
  implementation of MongoDB's aggregation language, against a fixture whose
  figures were calculated by hand (`reports.test.js`). The month-grouping test
  runs in four separate processes set to New York, Honolulu, Dubai and
  Kiritimati time.
- **Sign-in and accounts:** credentials, the database-failure case that
  previously stopped the API, account creation and teacher links
  (`authentication.test.js`, `accounts.test.js`, `user.test.js`).
- **Application:** JSON errors, headers, CORS preflight, rate limiting, start-up
  checks (`app.test.js`, `rateLimit.test.js`, `env.test.js`).

## Proving a test can fail

A test that cannot fail proves nothing. For the most important rules, the code
was deliberately broken and the tests were run to confirm they caught it:

| Defect introduced on purpose | Tests that failed |
|---|---|
| Reversed payments counted as received | 2 |
| Money summed as raw floating point | 5 |
| Money scaled to cents but not rounded | 2 |
| Sign-in lookup errors allowed to escape again | 2 |

One weakness was found this way. A rounding test passed even with the
rounding step removed, because its prices happened to produce exact results.
Its data was changed to prices (10.05 and 16.85) that expose both failure
modes.

A test can also pass because it builds its input differently from
production. A review after version 1.0.0 found that the tests for passwords
stored at the original work factor created the account in memory and cleared
the stored iteration count by hand. A real account is loaded by a query, and
Mongoose fills in schema defaults as it loads, so the real account was checked
at the new work factor and refused. Since version 1.0.1 the tests load the
account with `User.hydrate()`, the same step a query takes, and they fail if
the defect returns.

## Report verification on MongoDB

mingo is not MongoDB, so a pipeline could pass in the unit tests and behave
differently in the database. `npm run verify:reports` loads the same fixture
into a temporary database, runs the real pipelines inside MongoDB, compares
every figure, reports which index each query used, and deletes the database.
It exits with an error if any check fails.

## End-to-end tests

Playwright drives a real browser through the running system: the API on a
real MongoDB server, the demo school, and the production build of the
interface. Each role signs in and checks what it is offered, and the tests
save the screenshots used in the ePortfolio.

## Continuous integration

`.github/workflows/ci.yml` runs on every push:

1. **API:** install, then `npm test`.
2. **Interface:** install, `npm run test:ci`, then the production build.
3. **Database checks:** a MongoDB 8 service, then `npm run verify:reports` and
   `npm run bench:mongo`.
4. **End-to-end:** MongoDB, the demo school, the API and the built interface,
   then the Playwright tests. Screenshots are kept as a downloadable artifact.
