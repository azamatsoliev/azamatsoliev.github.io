# Security

How the application defends itself, threat by threat, and what is known not
to be covered yet. Each defense is enforced on the server; the interface only
mirrors it so people are not offered actions that would be refused.

## Threats and defenses

### Accounts and sign-in

| Threat | Defense | Where |
|---|---|---|
| Stolen password database cracked offline | PBKDF2-HMAC-SHA512 at 210,000 iterations with a per-account salt; older 1,000-iteration hashes are upgraded at the next sign-in | `app_api/models/user.js`, `app_api/controllers/authentication.js` |
| Timing attack on password comparison | `crypto.timingSafeEqual` | `app_api/models/user.js` |
| Learning which addresses are registered | One identical answer for an unknown address and a wrong password | `app_api/config/passport.js` |
| Password guessing at speed | Rate limit: 10 failed attempts per address per 15 minutes | `app_api/middleware/rateLimit.js` |
| Anyone creating an account | No public sign-up; accounts are created by an owner, the first owner from the server's command line | `app_api/controllers/users.js`, `app_api/models/seedOwner.js` |
| Raising one's own role | Roles are set only through owner-only endpoints; an owner cannot change their own role | `app_api/controllers/users.js` |
| Forged tokens | Tokens are signed and verified on every request; the API refuses to start without a secret of at least 32 characters | `app_api/middleware/authenticate.js`, `app_api/config/env.js` |
| One bad sign-in stopping the API | A failed database lookup during sign-in is handled and answered 503 | `app_api/config/passport.js` |

### Authorization

| Threat | Defense | Where |
|---|---|---|
| Doing something a role may not do | Role check on every action, with inheritance resolved in one place | `app_api/config/roles.js`, `crudControllerFactory.js` |
| Reaching another teacher's records (horizontal escalation) | Scope rules narrow every query to the caller's own records | `app_api/config/entities.js` |
| Learning whether a record exists | Out-of-scope records answer 403, the same as missing ones, never 404 | `crudControllerFactory.js` |
| Writing fields that control state, such as the soft-delete flag | Writable-field whitelist per entity | `app_api/config/entities.js` |
| Reading more than a role needs | Per-role projection: teachers receive student names only | `app_api/config/entities.js` |
| A teacher changing their own pay rate or reassigning a lesson | Edit policy refuses those two changes for teachers | `app_api/scheduling/sessionEditPolicy.js` |
| A teacher adding charges through a colleague's lesson | Attendance may be written only for one's own lessons | `app_api/scheduling/attendancePolicy.js` |

### Injection and input

| Threat | Defense | Where |
|---|---|---|
| MongoDB operator injection in a body, e.g. `"teacherId": { "$ne": null }` | Bodies with `$`-prefixed or dotted keys are refused | `crudControllerFactory.js` |
| Operator injection in a query string, e.g. `?month[$gt]=` | Query strings parsed flatly; report parameters validated as exact strings | `app.js`, `app_api/reports/periods.js` |
| Non-text credentials | Sign-in accepts text only; Passport treats objects as missing | `app_api/controllers/authentication.js` |
| Spreadsheet formula injection through an exported name | CSV cells starting with `=`, `+`, `-` or `@` are neutralized | `app_api/reports/csv.js` |
| Oversized or malformed bodies | 100 KB limit; malformed JSON answered 400 without parser details | `app.js` |
| Stored cross-site scripting | Angular escapes all bound values; the original's unescaped template was fixed in Enhancement One and later removed | `app_admin` |

### Data in transit, at rest and in logs

| Threat | Defense | Where |
|---|---|---|
| Unauthenticated database access | `MONGODB_URI` supports an authenticated, least-privilege database user | `app_api/config/database.js`, README |
| Database password written to logs | Connection strings are redacted before logging | `app_api/config/database.js` |
| Reports left in browser or proxy caches | Report responses are sent with `Cache-Control: no-store` | `app_api/controllers/reports.js` |
| Token sent to another site | The interface attaches the token to API requests only | `app_admin/src/app/utils/jwt.interceptor.ts` |
| Secrets committed to the repository | `.env` is ignored; only `.env.example` is committed | `.gitignore` |
| Clickjacking, MIME sniffing, framework disclosure | Standard headers from `helmet`; no `X-Powered-By` | `app.js` |

### Concurrency

| Threat | Defense | Where |
|---|---|---|
| Two simultaneous bookings both passing the conflict check | Check and write run under a per-teacher lock | `app_api/utils/keyedMutex.js` |

## Not yet covered

| Gap | Risk | Recommended fix |
|---|---|---|
| Booking lock and rate limiter are per process | Several API copies would each keep their own | Database-level lock; shared rate-limit store |
| Token kept in `localStorage` | Readable by any script injected into the page | httpOnly cookie with CSRF protection |
| MongoDB authentication is documented but not enabled by default | Any program on the machine can reach a local database | Enable authorization with the least-privilege user before deployment |
| Angular 17 is past its support period | Framework advisories listed by `npm audit`; none affect a feature this app uses (internationalization, server-side rendering and its transfer cache, or binding untrusted values into SVG or MathML), but an unsupported framework receives no further fixes | Upgrade to a supported Angular version |
| No password reset or account lockout | Staff depend on the owner to recover access | Reset by owner, with expiring links |
