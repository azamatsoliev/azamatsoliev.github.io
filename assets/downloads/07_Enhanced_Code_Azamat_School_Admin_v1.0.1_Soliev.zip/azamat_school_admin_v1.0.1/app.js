/**
 * Express application.
 *
 * The REST API behind Azamat School Admin. The browser interface is the
 * separate Angular application in app_admin, so this server answers JSON only.
 *
 * Request handling, in order:
 *   1. Security headers on every response (helmet).
 *   2. Flat query-string parsing, so a query can never carry a MongoDB operator.
 *   3. JSON bodies only, capped in size.
 *   4. CORS for the admin interface, with browser preflight answered here.
 *   5. The API routes under /api.
 *   6. JSON answers for unknown paths and for errors; nothing internal leaks.
 *
 * Changed for the final release: the server-rendered travel website inherited
 * from the original application (Handlebars views, static pages and images, the
 * cookie parser and three page routers) was removed. It served the travel
 * business the project began as, not the school, and every route it exposed was
 * attack surface the school platform did not need.
 *
 * Loading this module does not connect to the database or start listening;
 * bin/www does both. Tests can therefore load the application on its own.
 *
 * @file    app.js
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

require('dotenv').config({ quiet: true });

const express = require('express');
const helmet = require('helmet');
const logger = require('morgan');
const passport = require('passport');

// Registers every schema before the sign-in strategy looks up the user model.
require('./app_api/models/db');
require('./app_api/config/passport');

const apiRouter = require('./app_api/routes/index');

/** Largest request body accepted. Every legitimate request is far smaller. */
const BODY_LIMIT = '100kb';

/** Origin of the admin interface during development. */
const DEFAULT_ADMIN_ORIGIN = 'http://localhost:4200';

const app = express();

// Standard protective headers, and no X-Powered-By banner naming the framework.
app.use(helmet());

// Parse query strings flatly. Express 4's default parser turns ?month[$gt]=x
// into a nested object, { month: { $gt: 'x' } }, which is exactly the shape of a
// MongoDB query operator. The flat parser leaves it as a plain string key, so a
// query string can never smuggle an operator into a database filter.
app.set('query parser', 'simple');

if (process.env.NODE_ENV !== 'test') {
    app.use(logger('dev'));
}

app.use(express.json({ limit: BODY_LIMIT }));
app.use(passport.initialize());

// Enable CORS so the Angular admin app can call the API from its own origin.
//
// Before sending a PUT or DELETE, a browser first sends an OPTIONS request to
// ask whether the call is permitted. It deliberately omits the Authorization
// header from that request. If the OPTIONS request is allowed to reach the
// authentication middleware it is refused with 401, and the browser then
// blocks the real request, so editing and deleting fail from the interface
// while working correctly from a tool such as Postman.
//
// The preflight is therefore answered here and goes no further.
app.use('/api', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', process.env.ADMIN_ORIGIN || DEFAULT_ADMIN_ORIGIN);
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Vary', 'Origin');

    if (req.method === 'OPTIONS') {
        return res.sendStatus(204);
    }

    return next();
});

app.use('/api', apiRouter);

// Anything not matched above.
app.use((req, res) => {
    res.status(404).json({ message: 'Not found.' });
});

// Errors raised before a route handler could answer, such as an unreadable body.
// The four-argument signature is what marks this as Express error middleware.
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
    if (error && error.type === 'entity.parse.failed') {
        return res.status(400).json({ message: 'The request body is not valid JSON.' });
    }

    if (error && error.type === 'entity.too.large') {
        return res.status(413).json({ message: 'The request body is too large.' });
    }

    console.error('[app]', error);
    return res.status(500).json({ message: 'An unexpected error occurred.' });
});

module.exports = app;
