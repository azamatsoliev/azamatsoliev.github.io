/**
 * Environment settings for the admin interface.
 *
 * The one place the address of the API is defined. Every service builds its
 * URLs from apiBaseUrl, and the token interceptor only attaches credentials to
 * requests for this address. To point the interface at an API deployed
 * elsewhere, change this value and rebuild.
 *
 * @file    app_admin/src/environments/environment.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

export const environment = {
  /** Base address of the REST API, without a trailing slash. */
  apiBaseUrl: 'http://localhost:3000/api'
};
