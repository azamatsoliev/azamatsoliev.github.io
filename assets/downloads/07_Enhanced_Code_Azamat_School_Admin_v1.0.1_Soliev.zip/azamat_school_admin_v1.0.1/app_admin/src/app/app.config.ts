/**
 * Application configuration.
 *
 * Registers the router and the HTTP client, with the token interceptor that
 * attaches credentials to API requests and handles an expired session.
 *
 * @file    app_admin/src/app/app.config.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

import { routes } from './app.routes';
import { jwtInterceptor } from './utils/jwt.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([jwtInterceptor]))
  ]
};
