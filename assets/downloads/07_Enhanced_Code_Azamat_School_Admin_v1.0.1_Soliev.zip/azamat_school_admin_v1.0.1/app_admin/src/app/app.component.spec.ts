/**
 * Tests for the application layout.
 *
 * @file    app_admin/src/app/app.component.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { AppComponent } from './app.component';
import { APP_INFO } from './config/app-info';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppComponent],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()]
    }).compileComponents();
  });

  it('creates the application', () => {
    expect(TestBed.createComponent(AppComponent).componentInstance).toBeTruthy();
  });

  it('takes the product name from the single application definition', () => {
    expect(APP_INFO.name).toBe('Azamat School Admin');
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelector('.navbar-brand')?.textContent).toContain(APP_INFO.name);
    expect(element.querySelector('footer')?.textContent).toContain(`Built by ${APP_INFO.author}`);
  });

  it('offers keyboard users a way to skip straight to the content', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const main = element.querySelector('#main') as HTMLElement;

    fixture.componentInstance.skipToMain(new Event('click'));

    expect(element.querySelector('.skip-link')).not.toBeNull();
    expect(document.activeElement).toBe(main);
  });
});
