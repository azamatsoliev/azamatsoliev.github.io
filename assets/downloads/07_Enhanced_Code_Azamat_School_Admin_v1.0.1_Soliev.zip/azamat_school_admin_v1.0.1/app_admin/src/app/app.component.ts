/**
 * Root application component.
 *
 * Lays out every page: a skip link for keyboard users, the navigation bar,
 * the routed page, and a footer naming the product and its author.
 *
 * Changed for the final release: the product name is read from
 * config/app-info.ts, the single place it is defined, and the layout gained the
 * skip link and footer.
 *
 * @file    app_admin/src/app/app.component.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { NavbarComponent } from './navbar/navbar.component';
import { APP_INFO } from './config/app-info';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  public readonly appInfo = APP_INFO;
  public readonly year = new Date().getFullYear();

  /**
   * Moves keyboard focus to the main content.
   *
   * A plain "#main" link would make the browser load a new address under this
   * application's base path, so the jump is made here instead.
   */
  public skipToMain(event: Event): void {
    event.preventDefault();
    document.getElementById('main')?.focus();
  }
}
