/**
 * Report types.
 *
 * Shapes of the responses returned by /api/reports. Amounts are in currency
 * units, already exact to two decimal places; the server calculates them in
 * whole cents. Attendance rates are fractions between 0 and 1, or null when
 * attendance was never taken.
 *
 * @file    app_admin/src/app/models/reports.ts
 * @author  Azamat Soliev
 * @version 3.0
 * @date    October 2026
 */

export interface BalanceRow {
  studentId: string;
  firstName: string;
  lastName: string;
  email: string;
  withdrawn: boolean;
  classesAttended: number;
  billed: number;
  paid: number;
  outstanding: number;
}

export interface BalanceReport {
  rows: BalanceRow[];
  totals: { billed: number; paid: number; outstanding: number };
}

export interface RevenueRow {
  studentId: string;
  firstName: string;
  lastName: string;
  email: string;
  payments: number;
  collected: number;
}

export interface RevenueReport {
  month: string;
  rows: RevenueRow[];
  totals: { payments: number; collected: number };
}

export interface RevenueMonth {
  month: string;
  payments: number;
  collected: number;
}

export interface RevenueByMonthReport {
  year: number;
  months: RevenueMonth[];
  totals: { payments: number; collected: number };
}

export interface ClassRow {
  title: string;
  sessions: number;
  recorded: number;
  present: number;
  attendanceRate: number | null;
  billed: number;
}

export interface ClassSummaryReport {
  month: string;
  rows: ClassRow[];
  totals: { sessions: number; recorded: number; present: number; attendanceRate: number | null; billed: number };
}

export interface RosterEntry {
  firstName: string;
  lastName: string;
  present: boolean;
}

export interface SheetSession {
  sessionId: string;
  title: string;
  startTime: string;
  endTime: string;
  room?: string;
  recorded: number;
  present: number;
  status: 'Taken' | 'Not taken' | 'Upcoming';
  roster: RosterEntry[];
}

export interface AttendanceSheetReport {
  month: string;
  sessions: SheetSession[];
  summary: { sessions: number; taken: number; notTaken: number; upcoming: number; completionRate: number | null };
}
