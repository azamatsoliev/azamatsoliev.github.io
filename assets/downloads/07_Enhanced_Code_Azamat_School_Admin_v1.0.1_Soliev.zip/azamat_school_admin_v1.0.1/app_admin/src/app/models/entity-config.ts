/**
 * Entity configuration types for the administrative interface.
 *
 * Describes an entity to the generic entity manager component: which API path
 * serves it, what its fields are called and how each should be edited, and
 * which roles may act on it.
 *
 * This is the frontend counterpart to the entity configuration on the server.
 * Both sides describe the same five entities declaratively, so adding a sixth
 * means adding a description rather than writing another component.
 *
 * Changed for the final release: each entity carries a one-line description,
 * shown on the home page.
 *
 * @file    app_admin/src/app/models/entity-config.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

/** Editor control used for a field. */
export type FieldType = 'text' | 'email' | 'number' | 'date' | 'datetime' | 'checkbox' | 'select';

/** Roles recognized by the interface. Mirrors app_api/config/roles.js. */
export type Role = 'owner' | 'accountant' | 'teacher';

/** Describes one property of an entity. */
export interface FieldConfig {
  /** Property name as stored on the record and sent to the API. */
  key: string;

  /** Label shown in the table header and beside the form control. */
  label: string;

  /** Editor control to render. */
  type: FieldType;

  /** Whether the form requires a value. */
  required?: boolean;

  /** Whether the field appears as a column in the list view. */
  listed?: boolean;

  /** How a number is shown in the list: 'money' shows two decimal places. */
  format?: 'money';

  /** Options for a select control, or the entity whose records populate it. */
  options?: string[];

  /** API path whose records populate a select control, for reference fields. */
  optionsFrom?: string;

  /** Property of the referenced record shown to the user. */
  optionsLabel?: string;

  /**
   * Roles that may see but not change this field when editing.
   * Mirrors a server-side rule so the form does not invite a change the API
   * will refuse; the server still enforces the rule independently.
   */
  lockedFor?: Role[];
}

/** Describes one manageable entity. */
export interface EntityConfig {
  /** Path segment used in both the API URL and the admin route. */
  key: string;

  /** Singular name, used in headings and buttons. */
  singular: string;

  /** Plural name, used in list headings and navigation. */
  plural: string;

  /** One-line summary shown on the home page. */
  description: string;

  /** Fields making up the entity. */
  fields: FieldConfig[];

  /** Roles permitted to open this entity's management screen. */
  visibleTo: Role[];

  /** Roles permitted to create a record. */
  canCreate: Role[];

  /** Roles permitted to edit a record. */
  canEdit: Role[];

  /** Roles permitted to withdraw a record. */
  canDelete: Role[];
}
