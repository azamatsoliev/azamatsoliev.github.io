/**
 * Sign-in response.
 *
 * The body the API returns from a successful POST /api/login.
 *
 * @file    app_admin/src/app/models/auth-response.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

export interface AuthResponse {
  /** Signed token to send with every later request. */
  token: string;
}
