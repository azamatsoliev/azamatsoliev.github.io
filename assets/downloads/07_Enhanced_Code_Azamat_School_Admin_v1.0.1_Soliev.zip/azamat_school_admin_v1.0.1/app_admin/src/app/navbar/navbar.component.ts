/**
 * Navigation bar component.
 *
 * Builds the management links from the entity definitions and filters them by
 * the role held by the signed-in account, so each user is offered only the
 * sections their role can open. Shows who is signed in, and in which role.
 *
 * Changed for the final release:
 *   - The product name comes from config/app-info.ts. It was previously typed
 *     here as well as in the root component, despite a comment there saying it
 *     was held in one place.
 *   - The trip link was removed, and the signed-in name and role are shown.
 *   - On narrow screens the links fold behind a menu button. The open state is
 *     kept by Angular, so no script library is needed, and the menu closes
 *     after a link is chosen.
 *
 * @file    app_admin/src/app/navbar/navbar.component.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

import { AuthenticationService } from '../services/authentication.service';
import { ENTITY_DEFINITIONS } from '../config/entity-definitions';
import { APP_INFO, ROLE_LABELS } from '../config/app-info';
import { EntityConfig } from '../models/entity-config';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent {

  /** Name shown as the brand in the navigation bar. */
  public readonly appTitle = APP_INFO.name;

  /** Whether the collapsed menu is open on a narrow screen. */
  public menuOpen = false;

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router
  ) { }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /** Name and role of the signed-in person, for example "Madina Yusupova (Accountant)". */
  public signedInAs(): string {
    const user = this.authenticationService.getCurrentUser();
    if (!user) {
      return '';
    }
    return user.role ? `${user.name} (${ROLE_LABELS[user.role]})` : user.name;
  }

  /** Signs out and returns to the sign-in screen. */
  public onLogout(): void {
    this.authenticationService.logout();
    this.menuOpen = false;
    this.router.navigate(['/login']);
  }

  public toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  public closeMenu(): void {
    this.menuOpen = false;
  }

  /**
   * Management sections the signed-in role may open.
   *
   * Returns nothing when signed out, so the menu does not advertise screens
   * that would immediately refuse the request.
   */
  public visibleEntities(): EntityConfig[] {
    const role = this.authenticationService.currentRole();
    return role ? ENTITY_DEFINITIONS.filter((entity) => entity.visibleTo.includes(role)) : [];
  }
}
