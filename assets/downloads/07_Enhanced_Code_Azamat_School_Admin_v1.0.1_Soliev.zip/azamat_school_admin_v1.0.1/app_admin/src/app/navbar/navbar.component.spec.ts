/**
 * Tests for the navigation bar.
 *
 * @file    app_admin/src/app/navbar/navbar.component.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { NavbarComponent } from './navbar.component';
import { TOKEN_STORAGE_KEY } from '../services/authentication.service';
import { makeRoleToken } from '../testing/tokens';

describe('NavbarComponent', () => {

  const render = async (token: string | null) => {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    }
    await TestBed.configureTestingModule({
      imports: [NavbarComponent],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()]
    }).compileComponents();

    const fixture: ComponentFixture<NavbarComponent> = TestBed.createComponent(NavbarComponent);
    fixture.detectChanges();
    return fixture;
  };

  const linkTexts = (fixture: ComponentFixture<NavbarComponent>) =>
    Array.from((fixture.nativeElement as HTMLElement).querySelectorAll('.nav-link'))
      .map((link) => (link.textContent || '').trim());

  afterEach(() => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    TestBed.resetTestingModule();
  });

  it('shows the product name', async () => {
    const fixture = await render(null);
    expect((fixture.nativeElement as HTMLElement).querySelector('.navbar-brand')?.textContent)
      .toContain('Azamat School Admin');
  });

  it('offers no sections when signed out', async () => {
    const fixture = await render(null);
    expect(linkTexts(fixture)).toEqual([]);
  });

  it('offers a teacher their lessons, attendance and reports only', async () => {
    const fixture = await render(makeRoleToken('teacher', 'Jasur Aliev'));
    expect(linkTexts(fixture)).toEqual(['Home', 'Class Sessions', 'Attendance', 'Reports']);
  });

  it('shows who is signed in, and in which role', async () => {
    const fixture = await render(makeRoleToken('accountant', 'Madina Yusupova'));
    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Madina Yusupova (Accountant)');
  });

  it('signs out, discarding the token, and returns to sign-in', async () => {
    const fixture = await render(makeRoleToken('owner'));
    const router = TestBed.inject(Router);
    spyOn(router, 'navigate').and.resolveTo(true);

    fixture.componentInstance.onLogout();

    expect(localStorage.getItem(TOKEN_STORAGE_KEY)).toBeNull();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('opens and closes the menu on narrow screens', async () => {
    const fixture = await render(makeRoleToken('owner'));
    const navbar = fixture.componentInstance;
    navbar.toggleMenu();
    expect(navbar.menuOpen).toBeTrue();
    navbar.closeMenu();
    expect(navbar.menuOpen).toBeFalse();
  });
});
