/**
 * Browser storage injection token.
 *
 * Supplies localStorage through Angular's dependency injection, so services
 * read and write the sign-in token through an interface tests can replace.
 *
 * @file    app_admin/src/app/storage.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { InjectionToken } from '@angular/core';

export const BROWSER_STORAGE = new InjectionToken<Storage>('Browser Storage', {
  providedIn: 'root',
  factory: () => localStorage
});
