/**
 * Reports component.
 *
 * One screen that presents each role with the reports that support its own
 * decisions, each in the format that suits that decision:
 *
 *   Owner       Class summary: attendance and earnings side by side, because the
 *               owner's question is whether a class is worth continuing to run.
 *               The owner also inherits every accountant and teacher report.
 *   Accountant  Balances, a line-by-line monthly revenue table that exports to
 *               CSV for bookkeeping, and a monthly trend across the year.
 *   Teacher     Their own attendance sheet: which lessons still need attendance
 *               taken, and who attended. No financial figure appears anywhere.
 *
 * Presenting the same underlying data differently for each reader is the
 * communication decision this enhancement is built around. Hiding a tab is a
 * courtesy, not the security boundary: the server refuses every report a role
 * is not entitled to, whatever this screen displays.
 *
 * Changed for the final release: the signed-in role is read from
 * AuthenticationService, which now owns everything to do with the token.
 *
 * @file    app_admin/src/app/reports/reports.component.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';

import { ReportService } from '../services/report.service';
import { EntityDataService, EntityRecord } from '../services/entity-data.service';
import { AuthenticationService } from '../services/authentication.service';
import { Role } from '../models/entity-config';
import {
  AttendanceSheetReport,
  BalanceReport,
  ClassSummaryReport,
  RevenueByMonthReport,
  RevenueReport
} from '../models/reports';

/** The reports the screen can show. */
export type ReportTab = 'classes' | 'balances' | 'revenue' | 'trend' | 'sheet';

/** Tab labels, in display order. */
export const TAB_LABELS: Record<ReportTab, string> = {
  classes: 'Class Summary',
  balances: 'Balances',
  revenue: 'Monthly Revenue',
  trend: 'Revenue by Month',
  sheet: 'Attendance Sheet'
};

/** Which reports each role is offered. Mirrors the server's route permissions. */
export const TABS_BY_ROLE: Record<Role, ReportTab[]> = {
  owner: ['classes', 'balances', 'revenue', 'trend', 'sheet'],
  accountant: ['balances', 'revenue', 'trend'],
  teacher: ['sheet']
};

/** Formats today's month as YYYY-MM in local time. */
const currentMonth = (): string => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
};

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {

  public role: Role | null = null;
  public tabs: ReportTab[] = [];
  public active: ReportTab | null = null;
  public readonly labels = TAB_LABELS;

  public month = currentMonth();
  public year = new Date().getFullYear();

  /** Teachers the owner can choose between on the attendance sheet. */
  public teachers: EntityRecord[] = [];
  public teacherId = '';

  public loading = false;
  public errorMessage = '';

  public classes: ClassSummaryReport | null = null;
  public balances: BalanceReport | null = null;
  public revenue: RevenueReport | null = null;
  public trend: RevenueByMonthReport | null = null;
  public sheet: AttendanceSheetReport | null = null;

  /** Session whose roster is expanded on the attendance sheet. */
  public expanded: string | null = null;

  constructor(
    private reports: ReportService,
    private entityData: EntityDataService,
    private authenticationService: AuthenticationService
  ) { }

  public ngOnInit(): void {
    this.role = this.authenticationService.currentRole();
    this.tabs = this.role ? TABS_BY_ROLE[this.role] || [] : [];

    if (this.role === 'owner') {
      this.entityData.list('teachers').subscribe({
        next: (teachers) => {
          this.teachers = teachers;
          this.teacherId = teachers.length > 0 ? teachers[0]['_id'] : '';
        },
        error: () => { this.teachers = []; }
      });
    }

    if (this.tabs.length > 0) {
      this.select(this.tabs[0]);
    }
  }

  /** Switches to a report and loads it. */
  public select(tab: ReportTab): void {
    this.active = tab;
    this.load();
  }

  /** Loads the active report for the chosen month or year. */
  public load(): void {
    if (!this.active) {
      return;
    }

    this.errorMessage = '';
    this.loading = true;

    const done = <T>(request: Observable<T>, store: (value: T) => void) => request.subscribe({
      next: (value) => { store(value); this.loading = false; },
      error: (error) => { this.errorMessage = this.describeError(error); this.loading = false; }
    });

    switch (this.active) {
      case 'classes':
        done(this.reports.classes(this.month), (value) => { this.classes = value; });
        break;
      case 'balances':
        done(this.reports.balances(), (value) => { this.balances = value; });
        break;
      case 'revenue':
        done(this.reports.revenue(this.month), (value) => { this.revenue = value; });
        break;
      case 'trend':
        done(this.reports.revenueByMonth(this.year), (value) => { this.trend = value; });
        break;
      case 'sheet':
        if (this.role === 'owner' && !this.teacherId) {
          this.loading = false;
          this.errorMessage = 'Add a teacher to view an attendance sheet.';
          return;
        }
        done(
          this.reports.attendanceSheet(this.month, this.role === 'owner' ? this.teacherId : undefined),
          (value) => { this.sheet = value; }
        );
        break;
    }
  }

  /** Downloads the monthly revenue report as a CSV file. */
  public exportCsv(): void {
    this.reports.revenueCsv(this.month).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `revenue-${this.month}.csv`;
        link.click();
        URL.revokeObjectURL(url);
      },
      error: (error) => { this.errorMessage = this.describeError(error); }
    });
  }

  /** Width of a bar, as a percentage of the largest value in its set. */
  public barWidth(value: number, values: number[]): number {
    const largest = Math.max(...values, 0);
    return largest > 0 ? Math.round((value / largest) * 100) : 0;
  }

  /** Values used to scale the revenue trend bars. */
  public trendValues(): number[] {
    return this.trend ? this.trend.months.map((m) => m.collected) : [];
  }

  public toggleRoster(sessionId: string): void {
    this.expanded = this.expanded === sessionId ? null : sessionId;
  }

  /** Turns a failed request into a message the user can act on. */
  private describeError(error: any): string {
    if (error?.status === 401) {
      return 'Your session has expired. Please sign in again.';
    }
    if (error?.status === 403) {
      return error?.error?.message || 'You do not have permission to view this report.';
    }
    if (error?.status === 400) {
      return error?.error?.message || 'Please check the month or year and try again.';
    }
    return 'The report could not be loaded. Please try again.';
  }
}
