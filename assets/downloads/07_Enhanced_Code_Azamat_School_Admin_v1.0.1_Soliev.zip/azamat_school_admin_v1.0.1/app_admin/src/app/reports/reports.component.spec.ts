/**
 * Tests for the reports component.
 *
 * Confirms that each role is offered the reports that support its decisions,
 * and nothing else.
 *
 * @file    app_admin/src/app/reports/reports.component.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { of } from 'rxjs';

import { ReportsComponent, TABS_BY_ROLE } from './reports.component';
import { ReportService } from '../services/report.service';
import { EntityDataService } from '../services/entity-data.service';
import { AuthenticationService } from '../services/authentication.service';
import { Role } from '../models/entity-config';

describe('ReportsComponent', () => {

  const configure = async (role: Role | null) => {
    await TestBed.configureTestingModule({
      imports: [ReportsComponent],
      providers: [provideHttpClient(), provideHttpClientTesting()]
    }).compileComponents();

    const entityData = TestBed.inject(EntityDataService);
    spyOn(TestBed.inject(AuthenticationService), 'currentRole').and.returnValue(role);
    spyOn(entityData, 'list').and.returnValue(of([]));

    const reports = TestBed.inject(ReportService);
    spyOn(reports, 'classes').and.returnValue(of({ month: '2026-10', rows: [], totals: { sessions: 0, recorded: 0, present: 0, attendanceRate: null, billed: 0 } }));
    spyOn(reports, 'balances').and.returnValue(of({ rows: [], totals: { billed: 0, paid: 0, outstanding: 0 } }));
    spyOn(reports, 'attendanceSheet').and.returnValue(of({ month: '2026-10', sessions: [], summary: { sessions: 0, taken: 0, notTaken: 0, upcoming: 0, completionRate: null } }));

    const fixture = TestBed.createComponent(ReportsComponent);
    fixture.detectChanges();
    return { component: fixture.componentInstance, reports };
  };

  afterEach(() => TestBed.resetTestingModule());

  it('offers a teacher only the attendance sheet', async () => {
    const { component } = await configure('teacher');
    expect(component.tabs).toEqual(['sheet']);
  });

  it('never offers a teacher a financial report', async () => {
    const { component } = await configure('teacher');
    ['balances', 'revenue', 'trend', 'classes'].forEach((tab) => {
      expect(component.tabs).not.toContain(tab as any);
    });
  });

  it('offers an accountant the financial reports but not the class summary', async () => {
    const { component } = await configure('accountant');
    expect(component.tabs).toEqual(TABS_BY_ROLE.accountant);
    expect(component.tabs).not.toContain('classes');
    expect(component.tabs).not.toContain('sheet');
  });

  it('opens the owner on the class summary', async () => {
    const { component, reports } = await configure('owner');
    expect(component.active).toBe('classes');
    expect(reports.classes).toHaveBeenCalled();
  });

  it('offers nothing when no role is known', async () => {
    const { component } = await configure(null);
    expect(component.tabs).toEqual([]);
    expect(component.active).toBeNull();
  });

  it('scales bars against the largest value and never divides by zero', async () => {
    const { component } = await configure('owner');
    expect(component.barWidth(50, [50, 100])).toBe(50);
    expect(component.barWidth(0, [0, 0])).toBe(0);
  });
});
