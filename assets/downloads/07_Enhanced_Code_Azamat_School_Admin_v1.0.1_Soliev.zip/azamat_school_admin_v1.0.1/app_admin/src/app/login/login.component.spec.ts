/**
 * Tests for the sign-in screen.
 *
 * The API is replaced by Angular's HTTP testing controller, so each test
 * decides exactly how the server answers.
 *
 * @file    app_admin/src/app/login/login.component.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router, convertToParamMap, provideRouter } from '@angular/router';
import { HttpErrorResponse, provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import { LoginComponent } from './login.component';
import { TOKEN_STORAGE_KEY } from '../services/authentication.service';
import { environment } from '../../environments/environment';
import { makeRoleToken } from '../testing/tokens';

describe('LoginComponent', () => {
  let fixture: ComponentFixture<LoginComponent>;
  let component: LoginComponent;
  let httpMock: HttpTestingController | null = null;
  let router: Router;

  const configure = async (queryParams: Record<string, string> = {}) => {
    await TestBed.configureTestingModule({
      imports: [LoginComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: ActivatedRoute, useValue: { snapshot: { queryParamMap: convertToParamMap(queryParams) } } }
      ]
    }).compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
    spyOn(router, 'navigateByUrl').and.resolveTo(true);

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  afterEach(() => {
    // Tests that never configure the module have no HTTP controller to check.
    httpMock?.verify();
    httpMock = null;
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    TestBed.resetTestingModule();
  });

  it('asks only for an email address and a password', async () => {
    await configure();
    const inputs = (fixture.nativeElement as HTMLElement).querySelectorAll('input');
    expect(inputs.length).toBe(2);
  });

  it('links every label to its input', async () => {
    await configure();
    const element = fixture.nativeElement as HTMLElement;
    element.querySelectorAll('label').forEach((label) => {
      expect(element.querySelector(`#${label.getAttribute('for')}`)).not.toBeNull();
    });
  });

  it('does not call the server when a field is empty', async () => {
    await configure();
    component.email = '';
    component.password = '';
    component.onSubmit();
    expect(component.formError).toBe('Enter your email address and password.');
    httpMock!.expectNone(`${environment.apiBaseUrl}/login`);
  });

  it('waits for the server, stores the token and opens the home page', async () => {
    await configure();
    component.email = 'owner@school.example';
    component.password = 'DemoOwner123';
    component.onSubmit();
    expect(component.submitting).toBeTrue();

    const request = httpMock!.expectOne(`${environment.apiBaseUrl}/login`);
    expect(request.request.body).toEqual({ email: 'owner@school.example', password: 'DemoOwner123' });
    const token = makeRoleToken('owner');
    request.flush({ token });

    expect(localStorage.getItem(TOKEN_STORAGE_KEY)).toBe(token);
    expect(component.submitting).toBeFalse();
    expect(router.navigateByUrl).toHaveBeenCalledWith('/');
  });

  it('explains a wrong password and clears the password field', async () => {
    await configure();
    component.email = 'owner@school.example';
    component.password = 'wrong-password';
    component.onSubmit();

    httpMock!.expectOne(`${environment.apiBaseUrl}/login`)
      .flush({ message: 'Email or password is incorrect.' }, { status: 401, statusText: 'Unauthorized' });

    expect(component.formError).toBe('Email or password is incorrect.');
    expect(component.password).toBe('');
    expect(router.navigateByUrl).not.toHaveBeenCalled();
  });

  it('returns to the page first requested after signing in', async () => {
    await configure({ returnUrl: '/reports' });
    component.email = 'owner@school.example';
    component.password = 'DemoOwner123';
    component.onSubmit();
    httpMock!.expectOne(`${environment.apiBaseUrl}/login`).flush({ token: makeRoleToken('owner') });
    expect(router.navigateByUrl).toHaveBeenCalledWith('/reports');
  });

  it('never follows a return address that leads to another site', async () => {
    await configure({ returnUrl: '//attacker.example/phish' });
    component.email = 'owner@school.example';
    component.password = 'DemoOwner123';
    component.onSubmit();
    httpMock!.expectOne(`${environment.apiBaseUrl}/login`).flush({ token: makeRoleToken('owner') });
    expect(router.navigateByUrl).toHaveBeenCalledWith('/');
  });

  it('explains an expired session when sent back to sign in', async () => {
    await configure({ reason: 'expired' });
    expect(component.notice).toContain('expired');
  });

  it('describes each kind of failure in plain words', () => {
    const failure = (status: number) => new HttpErrorResponse({ status });
    expect(LoginComponent.describe(failure(0))).toContain('Cannot reach the server');
    expect(LoginComponent.describe(failure(429))).toContain('Too many sign-in attempts');
    expect(LoginComponent.describe(failure(503))).toContain('database');
    expect(LoginComponent.describe(failure(500))).toBe('Something went wrong. Please try again.');
  });
});
