/**
 * Sign-in component.
 *
 * Collects an email address and password, waits for the API's answer, and
 * explains any failure in terms the person can act on.
 *
 * Changed for the final release. The original form, carried over from the
 * travel application, had four problems, all corrected here:
 *   1. It required a Name field that the server never reads.
 *   2. It did not wait for the server. It started the request, then checked
 *      for a token at once and again after a fixed three-second timer, so a
 *      slow answer looked like a failure and a fast one still waited.
 *   3. A wrong password produced no message at all.
 *   4. The token was printed to the browser console.
 *
 * After signing in, the user returns to the page they first asked for, if it
 * was a page within this application.
 *
 * @file    app_admin/src/app/login/login.component.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthenticationService } from '../services/authentication.service';
import { APP_INFO } from '../config/app-info';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  public readonly appInfo = APP_INFO;

  public email = '';
  public password = '';

  /** True while waiting for the server, so the button cannot be pressed twice. */
  public submitting = false;

  /** Why the last attempt failed, shown above the form. */
  public formError = '';

  /** Information carried in from elsewhere, such as an expired session. */
  public notice = '';

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  public ngOnInit(): void {
    if (this.route.snapshot.queryParamMap.get('reason') === 'expired') {
      this.notice = 'Your session has expired. Please sign in again.';
    }
  }

  /** Validates the form, signs in, and moves on or explains the failure. */
  public onSubmit(): void {
    this.formError = '';

    if (this.email.trim() === '' || this.password === '') {
      this.formError = 'Enter your email address and password.';
      return;
    }

    this.submitting = true;

    this.authenticationService.login(this.email.trim(), this.password).subscribe({
      next: () => {
        this.submitting = false;
        this.router.navigateByUrl(this.returnUrl());
      },
      error: (error: unknown) => {
        this.submitting = false;
        this.password = '';
        this.formError = LoginComponent.describe(error);
      }
    });
  }

  /**
   * Turns a failed sign-in into a message the person can act on.
   *
   * @param error The error from the sign-in request.
   */
  public static describe(error: unknown): string {
    const status = error instanceof HttpErrorResponse ? error.status : -1;

    switch (status) {
      case 401:
        return 'Email or password is incorrect.';
      case 400:
        return 'Enter your email address and password.';
      case 429:
        return 'Too many sign-in attempts. Please wait a few minutes and try again.';
      case 503:
        return 'The server cannot reach its database right now. Please try again shortly.';
      case 0:
        return 'Cannot reach the server. Check that the API is running, then try again.';
      default:
        return 'Something went wrong. Please try again.';
    }
  }

  /**
   * The page to open after signing in.
   *
   * Only a path within this application is accepted. A full address, or one
   * beginning with two slashes, could send a person who followed a crafted
   * sign-in link to another site after they entered their password.
   */
  private returnUrl(): string {
    const requested = this.route.snapshot.queryParamMap.get('returnUrl');
    return requested && requested.startsWith('/') && !requested.startsWith('//') ? requested : '/';
  }
}
