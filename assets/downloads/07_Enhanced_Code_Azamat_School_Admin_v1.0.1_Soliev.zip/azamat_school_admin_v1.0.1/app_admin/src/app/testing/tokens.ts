/**
 * Test helpers for building sign-in tokens.
 *
 * Builds unsigned tokens in the same format the API issues: base64url-encoded
 * UTF-8 JSON. The interface never checks signatures (the server does), so an
 * unsigned token is enough to exercise every interface behavior.
 *
 * Used by specs only; nothing in the application imports this file.
 *
 * @file    app_admin/src/app/testing/tokens.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

/** Encodes text as base64url, the encoding used inside a token. */
export const toBase64Url = (text: string): string => {
  let binary = '';
  new TextEncoder().encode(text).forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};

/** Builds an unsigned token around a payload. */
export const makeToken = (payload: object): string =>
  `${toBase64Url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))}.${toBase64Url(JSON.stringify(payload))}.signature`;

/** Builds a token for a role that expires an hour from now. */
export const makeRoleToken = (role: string, name = 'Test User'): string => makeToken({
  id: 'user-1',
  email: 'user@school.example',
  name,
  role,
  teacherId: role === 'teacher' ? 'teacher-1' : null,
  exp: Math.floor(Date.now() / 1000) + 3600
});

/** Builds a token that expired a minute ago. */
export const makeExpiredToken = (): string => makeToken({
  id: 'user-1', email: 'user@school.example', name: 'Test User', role: 'owner',
  exp: Math.floor(Date.now() / 1000) - 60
});
