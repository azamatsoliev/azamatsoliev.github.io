/**
 * Route guards.
 *
 * Keep people from opening screens they cannot use: a signed-out visitor is
 * taken to the sign-in screen, and a signed-in user who opens a management
 * screen their role cannot see is taken to the home page.
 *
 * Guards are a convenience, not the security boundary. They decide what the
 * browser shows; the API authorizes every request regardless, so a request
 * made around the interface is still refused.
 *
 * @file    app_admin/src/app/utils/auth.guard.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { AuthenticationService } from '../services/authentication.service';
import { findEntityConfig } from '../config/entity-definitions';

/** Allows the route only when someone is signed in. */
export const authGuard: CanActivateFn = (route, state) => {
  const authenticationService = inject(AuthenticationService);
  const router = inject(Router);

  return authenticationService.isLoggedIn()
    ? true
    : router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } });
};

/** Allows a management screen only for roles that can open it. */
export const entityGuard: CanActivateFn = (route) => {
  const authenticationService = inject(AuthenticationService);
  const router = inject(Router);

  const config = findEntityConfig(route.paramMap.get('entity') ?? '');
  const role = authenticationService.currentRole();

  return config && role && config.visibleTo.includes(role)
    ? true
    : router.createUrlTree(['/']);
};
