/**
 * Sign-in token helpers.
 *
 * Reads the payload of the signed token the API issues at sign-in. The payload
 * is only read here, never trusted: the server verifies the signature on every
 * request, and these values decide nothing more than what the interface shows.
 *
 * A token's payload is encoded as base64url, not plain base64, and its text is
 * UTF-8. The original interface decoded it with atob() alone, which understands
 * neither: atob() throws on the "-" and "_" characters base64url uses, and it
 * returns the raw bytes of any character outside basic Latin. For an account
 * named in Cyrillic, such as "Дилноза Каримова", the payload could not be
 * decoded at all, so the signed-in check made on every screen threw an error
 * instead of answering; other non-English names decoded into garbled text.
 * This decoder handles both, and answers null for anything it cannot read.
 *
 * @file    app_admin/src/app/utils/token.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

/** Fields the API places in a token's payload. */
export interface TokenPayload {
  id?: string;
  email?: string;
  name?: string;
  role?: string;
  teacherId?: string | null;
  exp?: number;
}

/**
 * Decodes the payload of a token.
 *
 * @param token A token as issued by the API, or anything else.
 * @returns The payload, or null when the value is not a readable token.
 */
export const decodeTokenPayload = (token: string | null | undefined): TokenPayload | null => {
  if (typeof token !== 'string') {
    return null;
  }

  const parts = token.split('.');
  if (parts.length !== 3 || parts[1] === '') {
    return null;
  }

  try {
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
    const binary = atob(padded);
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    const payload = JSON.parse(new TextDecoder().decode(bytes));
    return payload !== null && typeof payload === 'object' ? payload as TokenPayload : null;
  } catch {
    return null;
  }
};

/**
 * Reports whether a payload has an expiry time that has not yet passed.
 *
 * @param payload A decoded payload, or null.
 * @param nowSeconds The current time in seconds; supplied by tests.
 */
export const isTokenCurrent = (
  payload: TokenPayload | null,
  nowSeconds: number = Date.now() / 1000
): boolean => !!payload && typeof payload.exp === 'number' && payload.exp > nowSeconds;
