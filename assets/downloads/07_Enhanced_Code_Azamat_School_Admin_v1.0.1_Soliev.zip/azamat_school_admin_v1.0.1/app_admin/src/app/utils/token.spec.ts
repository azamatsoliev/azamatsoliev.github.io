/**
 * Tests for the sign-in token helpers.
 *
 * @file    app_admin/src/app/utils/token.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { decodeTokenPayload, isTokenCurrent } from './token';
import { makeToken, toBase64Url } from '../testing/tokens';

describe('token helpers', () => {

  /** A payload shaped exactly like the one the API issues. */
  const payloadFor = (name: string) => ({
    id: '6710aa0b2c1d4e5f60718293',
    email: 'teacher@school.example',
    name,
    role: 'teacher',
    teacherId: '6710aa0b2c1d4e5f60718294',
    iat: 1760300000,
    exp: 1760303600
  });

  it('decodes a token carrying a name written in Cyrillic', () => {
    const token = makeToken(payloadFor('Дилноза Каримова'));
    expect(decodeTokenPayload(token)?.name).toBe('Дилноза Каримова');
  });

  it('documents why atob() alone was not enough for that token', () => {
    const segment = toBase64Url(JSON.stringify(payloadFor('Дилноза Каримова')));
    // The base64url text contains characters plain base64 does not use.
    expect(/[-_]/.test(segment)).toBeTrue();
    expect(() => atob(segment)).toThrow();
  });

  it('decodes accented Latin names without garbling them', () => {
    const token = makeToken(payloadFor('José Müller'));
    expect(decodeTokenPayload(token)?.name).toBe('José Müller');
  });

  it('answers null for values that are not tokens', () => {
    expect(decodeTokenPayload(null)).toBeNull();
    expect(decodeTokenPayload('')).toBeNull();
    expect(decodeTokenPayload('not-a-token')).toBeNull();
    expect(decodeTokenPayload('a.@@@.c')).toBeNull();
    expect(decodeTokenPayload(`a.${toBase64Url('"just text"')}.c`)).toBeNull();
  });

  it('treats a token as current only before its expiry time', () => {
    expect(isTokenCurrent({ exp: 2000 }, 1999)).toBeTrue();
    expect(isTokenCurrent({ exp: 2000 }, 2000)).toBeFalse();
    expect(isTokenCurrent({}, 1)).toBeFalse();
    expect(isTokenCurrent(null)).toBeFalse();
  });
});
