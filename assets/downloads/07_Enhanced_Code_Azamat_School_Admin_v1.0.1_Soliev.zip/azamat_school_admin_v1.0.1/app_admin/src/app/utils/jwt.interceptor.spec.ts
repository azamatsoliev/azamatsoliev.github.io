/**
 * Tests for the token interceptor.
 *
 * @file    app_admin/src/app/utils/jwt.interceptor.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';

import { jwtInterceptor } from './jwt.interceptor';
import { AuthenticationService, TOKEN_STORAGE_KEY } from '../services/authentication.service';
import { environment } from '../../environments/environment';
import { makeRoleToken } from '../testing/tokens';

describe('jwtInterceptor', () => {
  let http: HttpClient;
  let httpMock: HttpTestingController;
  let auth: AuthenticationService;
  let router: Router;

  const api = (path: string) => `${environment.apiBaseUrl}${path}`;

  beforeEach(() => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        provideHttpClient(withInterceptors([jwtInterceptor])),
        provideHttpClientTesting()
      ]
    });
    http = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    auth = TestBed.inject(AuthenticationService);
    router = TestBed.inject(Router);
    spyOn(router, 'navigate').and.resolveTo(true);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  });

  it('sends no token when nobody is signed in', () => {
    http.get(api('/students')).subscribe();
    const request = httpMock.expectOne(api('/students'));
    expect(request.request.headers.has('Authorization')).toBeFalse();
    request.flush([]);
  });

  it('attaches the token to API requests when signed in', () => {
    const token = makeRoleToken('owner');
    auth.saveToken(token);

    http.get(api('/students')).subscribe();
    const request = httpMock.expectOne(api('/students'));
    expect(request.request.headers.get('Authorization')).toBe(`Bearer ${token}`);
    request.flush([]);
  });

  it('never sends the token to another site', () => {
    auth.saveToken(makeRoleToken('owner'));

    http.get('https://other-site.example/api/students').subscribe();
    const request = httpMock.expectOne('https://other-site.example/api/students');
    expect(request.request.headers.has('Authorization')).toBeFalse();
    request.flush([]);
  });

  it('does not attach a token to the sign-in request', () => {
    auth.saveToken(makeRoleToken('owner'));

    http.post(api('/login'), {}).subscribe();
    const request = httpMock.expectOne(api('/login'));
    expect(request.request.headers.has('Authorization')).toBeFalse();
    request.flush({});
  });

  it('signs out and opens sign-in when the API stops accepting the token', () => {
    auth.saveToken(makeRoleToken('owner'));

    http.get(api('/students')).subscribe({ error: () => undefined });
    httpMock.expectOne(api('/students')).flush({ message: 'Authentication required.' }, { status: 401, statusText: 'Unauthorized' });

    expect(auth.getToken()).toBe('');
    expect(router.navigate).toHaveBeenCalledWith(['/login'], { queryParams: { reason: 'expired' } });
  });

  it('leaves a wrong password at sign-in to the sign-in screen', () => {
    http.post(api('/login'), {}).subscribe({ error: () => undefined });
    httpMock.expectOne(api('/login')).flush({}, { status: 401, statusText: 'Unauthorized' });

    expect(router.navigate).not.toHaveBeenCalled();
  });
});
