/**
 * Tests for the route guards.
 *
 * @file    app_admin/src/app/utils/auth.guard.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { TestBed } from '@angular/core/testing';
import {
  ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree, convertToParamMap, provideRouter
} from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { authGuard, entityGuard } from './auth.guard';
import { TOKEN_STORAGE_KEY } from '../services/authentication.service';
import { makeRoleToken } from '../testing/tokens';

describe('route guards', () => {
  let router: Router;

  const routeFor = (entity: string) => ({ paramMap: convertToParamMap({ entity }) } as ActivatedRouteSnapshot);
  const stateFor = (url: string) => ({ url } as RouterStateSnapshot);

  const run = (guard: typeof authGuard, route: ActivatedRouteSnapshot, state: RouterStateSnapshot) =>
    TestBed.runInInjectionContext(() => guard(route, state));

  beforeEach(() => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    TestBed.configureTestingModule({ providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()] });
    router = TestBed.inject(Router);
  });

  afterEach(() => localStorage.removeItem(TOKEN_STORAGE_KEY));

  it('sends a signed-out visitor to sign in, remembering where they were going', () => {
    const result = run(authGuard, routeFor(''), stateFor('/reports')) as UrlTree;
    expect(router.serializeUrl(result)).toBe('/login?returnUrl=%2Freports');
  });

  it('lets a signed-in user through', () => {
    localStorage.setItem(TOKEN_STORAGE_KEY, makeRoleToken('teacher'));
    expect(run(authGuard, routeFor(''), stateFor('/reports'))).toBeTrue();
  });

  it('opens a management screen for a role that can see it', () => {
    localStorage.setItem(TOKEN_STORAGE_KEY, makeRoleToken('accountant'));
    expect(run(entityGuard, routeFor('payments'), stateFor('/manage/payments'))).toBeTrue();
  });

  it('turns a teacher away from the student records screen', () => {
    localStorage.setItem(TOKEN_STORAGE_KEY, makeRoleToken('teacher'));
    const result = run(entityGuard, routeFor('students'), stateFor('/manage/students')) as UrlTree;
    expect(router.serializeUrl(result)).toBe('/');
  });

  it('turns everyone away from a screen that does not exist', () => {
    localStorage.setItem(TOKEN_STORAGE_KEY, makeRoleToken('owner'));
    const result = run(entityGuard, routeFor('not-a-section'), stateFor('/manage/not-a-section')) as UrlTree;
    expect(router.serializeUrl(result)).toBe('/');
  });
});
