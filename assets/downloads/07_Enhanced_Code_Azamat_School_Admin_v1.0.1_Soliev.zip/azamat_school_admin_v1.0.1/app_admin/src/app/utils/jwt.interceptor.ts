/**
 * Token interceptor.
 *
 * Attaches the sign-in token to requests for the API, and signs the user out
 * when the API reports that the token is no longer accepted.
 *
 * Changed for the final release:
 *   - The token is attached only to requests addressed to the API. The
 *     original attached it to every outgoing request, so any call to another
 *     site would have handed that site a working credential.
 *   - The sign-in request is recognized by its exact address rather than by
 *     the text "/login" appearing anywhere in a URL.
 *   - A 401 from the API, other than at sign-in, means the token has expired or
 *     was rejected. The token is discarded and the sign-in screen opens with an
 *     explanation, instead of every screen failing on its own.
 *
 * @file    app_admin/src/app/utils/jwt.interceptor.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { AuthenticationService } from '../services/authentication.service';
import { environment } from '../../environments/environment';

/** Reports whether a URL is addressed to the API. */
const isApiRequest = (url: string): boolean =>
  url === environment.apiBaseUrl || url.startsWith(`${environment.apiBaseUrl}/`);

/** Reports whether a URL is the sign-in endpoint. */
const isSignInRequest = (url: string): boolean => url === `${environment.apiBaseUrl}/login`;

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authenticationService = inject(AuthenticationService);
  const router = inject(Router);

  const forApi = isApiRequest(req.url);
  const signingIn = isSignInRequest(req.url);

  const outgoing = forApi && !signingIn && authenticationService.isLoggedIn()
    ? req.clone({ setHeaders: { Authorization: `Bearer ${authenticationService.getToken()}` } })
    : req;

  return next(outgoing).pipe(
    catchError((error: unknown) => {
      if (error instanceof HttpErrorResponse && error.status === 401 && forApi && !signingIn) {
        authenticationService.logout();
        router.navigate(['/login'], { queryParams: { reason: 'expired' } });
      }
      return throwError(() => error);
    })
  );
};
