/**
 * Authentication service.
 *
 * Signs in, keeps the sign-in token, and answers who is signed in and with
 * which role. Every screen asks this service rather than reading the token
 * itself, so the token format is understood in exactly one place.
 *
 * What this service reports decides only what the interface offers. The server
 * verifies the token's signature and authorizes every request on its own.
 *
 * Changed for the final release:
 *   - Sign-in calls the API directly and returns an Observable, so the sign-in
 *     screen can wait for the real answer. It previously borrowed the trip
 *     service, subscribed internally, and the screen guessed at the outcome
 *     with a three-second timer.
 *   - The token is no longer written to the browser console.
 *   - The token is decoded safely (see utils/token.ts), and the signed-in role
 *     is read here instead of in the data service.
 *   - The unused registration method was removed; accounts are created by an
 *     owner.
 *
 * @file    app_admin/src/app/services/authentication.service.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

import { BROWSER_STORAGE } from '../storage';
import { AuthResponse } from '../models/auth-response';
import { Role } from '../models/entity-config';
import { decodeTokenPayload, isTokenCurrent, TokenPayload } from '../utils/token';
import { environment } from '../../environments/environment';

/** Storage key under which the sign-in token is kept. */
export const TOKEN_STORAGE_KEY = 'azamat-school-admin.token';

/** The signed-in person, as far as the interface needs to know. */
export interface CurrentUser {
  name: string;
  email: string;
  role: Role | null;
  teacherId: string | null;
}

const KNOWN_ROLES: readonly string[] = ['owner', 'accountant', 'teacher'];

@Injectable({ providedIn: 'root' })
export class AuthenticationService {

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) { }

  /** The stored token, or an empty string when there is none. */
  public getToken(): string {
    return this.storage.getItem(TOKEN_STORAGE_KEY) || '';
  }

  /** Stores a token returned by the API. */
  public saveToken(token: string): void {
    this.storage.setItem(TOKEN_STORAGE_KEY, token);
  }

  /** Signs out by discarding the token. */
  public logout(): void {
    this.storage.removeItem(TOKEN_STORAGE_KEY);
  }

  /** Reports whether a readable, unexpired token is stored. */
  public isLoggedIn(): boolean {
    return isTokenCurrent(this.payload());
  }

  /** The signed-in person, or null when nobody is signed in. */
  public getCurrentUser(): CurrentUser | null {
    const payload = this.payload();

    if (!isTokenCurrent(payload) || !payload) {
      return null;
    }

    return {
      name: payload.name ?? '',
      email: payload.email ?? '',
      role: KNOWN_ROLES.includes(payload.role ?? '') ? payload.role as Role : null,
      teacherId: payload.teacherId ?? null
    };
  }

  /** The signed-in role, or null when nobody is signed in. */
  public currentRole(): Role | null {
    return this.getCurrentUser()?.role ?? null;
  }

  /**
   * Signs in and stores the token the API returns.
   *
   * Completes when the token is stored. Fails with the HTTP error when the API
   * refuses, so the caller can tell a wrong password from an unreachable server.
   */
  public login(email: string, password: string): Observable<void> {
    return this.http
      .post<AuthResponse>(`${environment.apiBaseUrl}/login`, { email, password })
      .pipe(map((response) => {
        if (!response || typeof response.token !== 'string' || response.token === '') {
          throw new Error('The server did not return a sign-in token.');
        }
        this.saveToken(response.token);
      }));
  }

  /** Decodes the stored token's payload, or null when there is none. */
  private payload(): TokenPayload | null {
    return decodeTokenPayload(this.getToken());
  }
}
