/**
 * Tests for the authentication service.
 *
 * @file    app_admin/src/app/services/authentication.service.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import { AuthenticationService, TOKEN_STORAGE_KEY } from './authentication.service';
import { environment } from '../../environments/environment';
import { makeExpiredToken, makeRoleToken, makeToken } from '../testing/tokens';

describe('AuthenticationService', () => {
  let service: AuthenticationService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(AuthenticationService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  });

  it('reports signed out when no token is stored', () => {
    expect(service.isLoggedIn()).toBeFalse();
    expect(service.getCurrentUser()).toBeNull();
    expect(service.currentRole()).toBeNull();
  });

  it('reads the name and role from a current token', () => {
    service.saveToken(makeRoleToken('teacher', 'Jasur Aliev'));
    expect(service.isLoggedIn()).toBeTrue();
    expect(service.getCurrentUser()?.name).toBe('Jasur Aliev');
    expect(service.currentRole()).toBe('teacher');
  });

  it('treats an expired token as signed out', () => {
    service.saveToken(makeExpiredToken());
    expect(service.isLoggedIn()).toBeFalse();
    expect(service.currentRole()).toBeNull();
  });

  it('treats an unreadable token as signed out rather than failing', () => {
    service.saveToken('irrelevant.mock.token');
    expect(() => service.isLoggedIn()).not.toThrow();
    expect(service.isLoggedIn()).toBeFalse();
  });

  it('does not accept a role the system does not define', () => {
    service.saveToken(makeToken({ name: 'Someone', role: 'superuser', exp: Math.floor(Date.now() / 1000) + 60 }));
    expect(service.currentRole()).toBeNull();
  });

  it('signs out by discarding the token', () => {
    service.saveToken(makeRoleToken('owner'));
    service.logout();
    expect(service.getToken()).toBe('');
    expect(service.isLoggedIn()).toBeFalse();
  });

  it('stores the token only once the server has answered', () => {
    let completed = false;
    service.login('owner@school.example', 'DemoOwner123').subscribe(() => { completed = true; });

    expect(service.getToken()).toBe('');
    const token = makeRoleToken('owner');
    httpMock.expectOne(`${environment.apiBaseUrl}/login`).flush({ token });

    expect(completed).toBeTrue();
    expect(service.getToken()).toBe(token);
  });

  it('passes a refusal on to the caller and stores nothing', () => {
    let status = 0;
    service.login('owner@school.example', 'wrong').subscribe({ error: (error) => { status = error.status; } });

    httpMock.expectOne(`${environment.apiBaseUrl}/login`)
      .flush({ message: 'Email or password is incorrect.' }, { status: 401, statusText: 'Unauthorized' });

    expect(status).toBe(401);
    expect(service.getToken()).toBe('');
  });
});
