/**
 * Report service.
 *
 * Fetches the reports from /api/reports. The authorization header is added by
 * the token interceptor, and the server decides what each role may see; this
 * service only asks.
 *
 * Changed for the final release: the API address comes from the environment
 * file instead of being written into this service.
 *
 * @file    app_admin/src/app/services/report.service.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  AttendanceSheetReport,
  BalanceReport,
  ClassSummaryReport,
  RevenueByMonthReport,
  RevenueReport
} from '../models/reports';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ReportService {

  private readonly baseUrl = `${environment.apiBaseUrl}/reports`;

  constructor(private http: HttpClient) { }

  public balances(): Observable<BalanceReport> {
    return this.http.get<BalanceReport>(`${this.baseUrl}/balances`);
  }

  public revenue(month: string): Observable<RevenueReport> {
    return this.http.get<RevenueReport>(`${this.baseUrl}/revenue`, { params: { month } });
  }

  public revenueByMonth(year: number): Observable<RevenueByMonthReport> {
    return this.http.get<RevenueByMonthReport>(`${this.baseUrl}/revenue-by-month`, { params: { year: String(year) } });
  }

  public classes(month: string): Observable<ClassSummaryReport> {
    return this.http.get<ClassSummaryReport>(`${this.baseUrl}/classes`, { params: { month } });
  }

  /** A teacher's own sheet; an owner passes the teacher to view. */
  public attendanceSheet(month: string, teacherId?: string): Observable<AttendanceSheetReport> {
    const params: Record<string, string> = teacherId ? { month, teacherId } : { month };
    return this.http.get<AttendanceSheetReport>(`${this.baseUrl}/attendance-sheet`, { params });
  }

  /** The monthly revenue report as a CSV file. */
  public revenueCsv(month: string): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/revenue.csv`, { params: { month }, responseType: 'blob' });
  }
}
