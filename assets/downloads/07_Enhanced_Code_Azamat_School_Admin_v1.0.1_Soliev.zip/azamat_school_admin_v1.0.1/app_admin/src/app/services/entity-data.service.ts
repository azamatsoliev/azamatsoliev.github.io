/**
 * Generic entity data service.
 *
 * Provides create, read, update and delete operations for any managed entity.
 * The entity's path segment is supplied per call, so one service covers all
 * five entities instead of each needing its own.
 *
 * The authorization header is added by the token interceptor rather than here,
 * so this service is not concerned with credentials at all.
 *
 * Changed for the final release: the API address comes from the environment
 * file, and reading the signed-in role moved to AuthenticationService, which
 * now owns everything to do with the token.
 *
 * @file    app_admin/src/app/services/entity-data.service.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';

/** A record of any managed entity. Shape is defined by its configuration. */
export type EntityRecord = Record<string, any>;

@Injectable({ providedIn: 'root' })
export class EntityDataService {

  constructor(private http: HttpClient) { }

  /** Builds the collection URL for an entity. */
  private collectionUrl(entityKey: string): string {
    return `${environment.apiBaseUrl}/${entityKey}`;
  }

  /** Builds the URL of a single record. */
  private recordUrl(entityKey: string, id: string): string {
    return `${environment.apiBaseUrl}/${entityKey}/${encodeURIComponent(id)}`;
  }

  /**
   * Lists the records of an entity that the signed-in account may see.
   * The server narrows the result; no filtering happens here.
   */
  public list(entityKey: string): Observable<EntityRecord[]> {
    return this.http.get<EntityRecord[]>(this.collectionUrl(entityKey));
  }

  /** Retrieves one record. */
  public getOne(entityKey: string, id: string): Observable<EntityRecord> {
    return this.http.get<EntityRecord>(this.recordUrl(entityKey, id));
  }

  /** Creates a record. */
  public create(entityKey: string, record: EntityRecord): Observable<EntityRecord> {
    return this.http.post<EntityRecord>(this.collectionUrl(entityKey), record);
  }

  /** Updates a record. */
  public update(entityKey: string, id: string, record: EntityRecord): Observable<EntityRecord> {
    return this.http.put<EntityRecord>(this.recordUrl(entityKey, id), record);
  }

  /** Withdraws a record. Most entities deactivate rather than erase. */
  public remove(entityKey: string, id: string): Observable<EntityRecord> {
    return this.http.delete<EntityRecord>(this.recordUrl(entityKey, id));
  }
}
