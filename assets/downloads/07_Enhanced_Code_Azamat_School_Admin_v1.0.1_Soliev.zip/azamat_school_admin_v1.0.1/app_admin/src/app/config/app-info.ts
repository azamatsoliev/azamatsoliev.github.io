/**
 * Application identity.
 *
 * The product name and related text, held once so the navigation bar, page
 * titles, sign-in screen and footer can never disagree.
 *
 * @file    app_admin/src/app/config/app-info.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Role } from '../models/entity-config';

export const APP_INFO = {
  name: 'Azamat School Admin',
  tagline: 'Management platform for small language schools',
  author: 'Azamat Soliev'
} as const;

/** Builds a page title such as "Reports · Azamat School Admin". */
export const pageTitle = (page: string): string => `${page} · ${APP_INFO.name}`;

/** Display names for the three roles. */
export const ROLE_LABELS: Record<Role, string> = {
  owner: 'Owner',
  accountant: 'Accountant',
  teacher: 'Teacher'
};
