/**
 * Entity definitions for the administrative interface.
 *
 * The five managed entities, described declaratively. The entity manager
 * component reads these to build its table and its form, so none of the five
 * needs a component, template or service of its own.
 *
 * Role lists here control what the interface offers. They mirror the server's
 * permissions so that a user is not shown a button that would be refused, but
 * they are not the security boundary. Hiding a control is a courtesy; the
 * server decides what is actually permitted, and a request that bypasses this
 * interface is still refused there.
 *
 * Changed for the final release: each entity has a one-line description for
 * the home page. Teachers are still not offered the Students screen; the
 * server now lets them read student names, which the attendance form needs to
 * offer a choice of student.
 *
 * @file    app_admin/src/app/config/entity-definitions.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { EntityConfig } from '../models/entity-config';

export const ENTITY_DEFINITIONS: EntityConfig[] = [
  {
    key: 'students',
    singular: 'Student',
    plural: 'Students',
    description: 'Student records and contact details.',
    visibleTo: ['owner', 'accountant'],
    canCreate: ['owner'],
    canEdit: ['owner'],
    canDelete: ['owner'],
    fields: [
      { key: 'firstName', label: 'First Name', type: 'text', required: true, listed: true },
      { key: 'lastName', label: 'Last Name', type: 'text', required: true, listed: true },
      { key: 'email', label: 'Email', type: 'email', required: true, listed: true },
      { key: 'phone', label: 'Phone', type: 'text', listed: true },
      { key: 'enrolledOn', label: 'Enrolled On', type: 'date', required: true, listed: true }
    ]
  },
  {
    key: 'teachers',
    singular: 'Teacher',
    plural: 'Teachers',
    description: 'Teaching staff and their hiring dates.',
    visibleTo: ['owner'],
    canCreate: ['owner'],
    canEdit: ['owner'],
    canDelete: ['owner'],
    fields: [
      { key: 'firstName', label: 'First Name', type: 'text', required: true, listed: true },
      { key: 'lastName', label: 'Last Name', type: 'text', required: true, listed: true },
      { key: 'email', label: 'Email', type: 'email', required: true, listed: true },
      { key: 'hiredOn', label: 'Hired On', type: 'date', required: true, listed: true }
    ]
  },
  {
    key: 'classsessions',
    singular: 'Class Session',
    plural: 'Class Sessions',
    description: 'Lessons, times, rooms and rates. Double bookings are refused.',
    visibleTo: ['owner', 'teacher'],
    canCreate: ['owner'],
    canEdit: ['owner', 'teacher'],
    canDelete: ['owner'],
    fields: [
      { key: 'title', label: 'Title', type: 'text', required: true, listed: true },
      {
        key: 'teacherId', label: 'Teacher', type: 'select', required: true, listed: true,
        optionsFrom: 'teachers', optionsLabel: 'fullName', lockedFor: ['teacher']
      },
      { key: 'startTime', label: 'Starts', type: 'datetime', required: true, listed: true },
      { key: 'endTime', label: 'Ends', type: 'datetime', required: true, listed: true },
      { key: 'ratePerClass', label: 'Rate', type: 'number', format: 'money', required: true, listed: true, lockedFor: ['teacher'] },
      { key: 'room', label: 'Room', type: 'text', listed: true }
    ]
  },
  {
    key: 'payments',
    singular: 'Payment',
    plural: 'Payments',
    description: 'Tuition payments received, by student.',
    visibleTo: ['owner', 'accountant'],
    canCreate: ['owner', 'accountant'],
    canEdit: ['owner', 'accountant'],
    canDelete: ['owner'],
    fields: [
      {
        key: 'studentId', label: 'Student', type: 'select', required: true, listed: true,
        optionsFrom: 'students', optionsLabel: 'fullName'
      },
      { key: 'amount', label: 'Amount', type: 'number', format: 'money', required: true, listed: true },
      { key: 'paidOn', label: 'Paid On', type: 'date', required: true, listed: true },
      {
        key: 'method', label: 'Method', type: 'select', required: true, listed: true,
        options: ['cash', 'card', 'transfer']
      },
      { key: 'reference', label: 'Reference', type: 'text', listed: true }
    ]
  },
  {
    key: 'attendance',
    singular: 'Attendance Record',
    plural: 'Attendance',
    description: 'Who attended each lesson.',
    visibleTo: ['owner', 'teacher'],
    canCreate: ['owner', 'teacher'],
    canEdit: ['owner', 'teacher'],
    canDelete: ['owner'],
    fields: [
      {
        key: 'studentId', label: 'Student', type: 'select', required: true, listed: true,
        optionsFrom: 'students', optionsLabel: 'fullName'
      },
      {
        key: 'classSessionId', label: 'Class Session', type: 'select', required: true, listed: true,
        optionsFrom: 'classsessions', optionsLabel: 'label'
      },
      { key: 'present', label: 'Present', type: 'checkbox', listed: true },
      { key: 'recordedOn', label: 'Recorded On', type: 'date', required: true, listed: true },
      { key: 'note', label: 'Note', type: 'text', listed: false }
    ]
  }
];

/**
 * Finds a definition by its path segment.
 *
 * @param key Path segment from the route.
 * @returns The matching definition, or undefined when the route is unknown.
 */
export const findEntityConfig = (key: string): EntityConfig | undefined =>
  ENTITY_DEFINITIONS.find((definition) => definition.key === key);
