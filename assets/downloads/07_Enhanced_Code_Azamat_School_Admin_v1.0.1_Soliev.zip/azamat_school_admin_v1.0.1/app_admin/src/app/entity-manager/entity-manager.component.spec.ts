/**
 * Tests for the entity manager component.
 *
 * Verifies that the screen is genuinely driven by configuration: that the
 * correct entity is resolved from the route, that only listed fields become
 * columns, and that action controls appear according to the signed-in role.
 *
 * HttpClientTestingModule intercepts the outgoing requests, so these run
 * without the API or the database being available.
 *
 * Run with: npm test (from app_admin). Requires a browser, as Karma launches
 * one to execute the suite.
 *
 * @file    app_admin/src/app/entity-manager/entity-manager.component.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { of } from 'rxjs';

import { EntityManagerComponent } from './entity-manager.component';
import { EntityDataService } from '../services/entity-data.service';
import { AuthenticationService } from '../services/authentication.service';
import { Role } from '../models/entity-config';

/** Builds a stub route supplying a fixed entity parameter. */
const routeStub = (entity: string) => ({
  paramMap: of(convertToParamMap({ entity }))
});

describe('EntityManagerComponent', () => {

  const configure = async (entity: string, role: Role | null) => {
    await TestBed.configureTestingModule({
      imports: [EntityManagerComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: ActivatedRoute, useValue: routeStub(entity) }
      ]
    }).compileComponents();

    const service = TestBed.inject(EntityDataService);
    spyOn(TestBed.inject(AuthenticationService), 'currentRole').and.returnValue(role);
    spyOn(service, 'list').and.returnValue(of([]));

    const fixture: ComponentFixture<EntityManagerComponent> =
      TestBed.createComponent(EntityManagerComponent);
    fixture.detectChanges();
    return fixture;
  };

  afterEach(() => TestBed.resetTestingModule());

  it('resolves the entity named in the route', async () => {
    const fixture = await configure('students', 'owner');
    expect(fixture.componentInstance.config?.key).toBe('students');
    expect(fixture.componentInstance.config?.plural).toBe('Students');
  });

  it('reports an unknown entity rather than failing silently', async () => {
    const fixture = await configure('not-an-entity', 'owner');
    expect(fixture.componentInstance.config).toBeNull();
    expect(fixture.componentInstance.errorMessage).toBeTruthy();
  });

  it('builds its columns from the configuration', async () => {
    const fixture = await configure('students', 'owner');
    const columns = fixture.componentInstance.listedFields.map((field) => field.key);
    expect(columns).toContain('firstName');
    expect(columns).toContain('email');
  });

  it('excludes fields marked as not listed', async () => {
    const fixture = await configure('attendance', 'owner');
    const columns = fixture.componentInstance.listedFields.map((field) => field.key);
    expect(columns).not.toContain('note');
  });

  it('offers creation to an owner', async () => {
    const fixture = await configure('students', 'owner');
    const component = fixture.componentInstance;
    expect(component.allowed(component.config!.canCreate)).toBeTrue();
  });

  it('withholds creation from a role that may only read', async () => {
    const fixture = await configure('students', 'accountant');
    const component = fixture.componentInstance;
    expect(component.allowed(component.config!.canCreate)).toBeFalse();
  });

  it('withholds every action when no role is known', async () => {
    const fixture = await configure('students', null);
    const component = fixture.componentInstance;
    expect(component.allowed(component.config!.canCreate)).toBeFalse();
    expect(component.allowed(component.config!.canDelete)).toBeFalse();
  });

  it('opens an empty draft when adding', async () => {
    const fixture = await configure('students', 'owner');
    const component = fixture.componentInstance;
    component.startAdd();
    expect(component.draft).toBeTruthy();
    expect(component.editingId).toBeNull();
    expect(component.draftIsValid).toBeFalse();
  });

  it('treats a draft missing a required value as invalid', async () => {
    const fixture = await configure('students', 'owner');
    const component = fixture.componentInstance;
    component.startAdd();
    component.draft!['firstName'] = 'Aziza';
    expect(component.draftIsValid).toBeFalse();
  });

  it('locks the teacher and rate fields for a teacher editing a session', async () => {
    const fixture = await configure('classsessions', 'teacher');
    const component = fixture.componentInstance;
    component.editingId = 'session-1';
    const field = (key: string) => component.config!.fields.find((f) => f.key === key)!;

    expect(component.isLocked(field('teacherId'))).toBeTrue();
    expect(component.isLocked(field('ratePerClass'))).toBeTrue();
    expect(component.isLocked(field('startTime'))).toBeFalse();
    expect(component.isLocked(field('room'))).toBeFalse();
  });

  it('leaves every field editable for an owner', async () => {
    const fixture = await configure('classsessions', 'owner');
    const component = fixture.componentInstance;
    component.editingId = 'session-1';

    component.config!.fields.forEach((field) => {
      expect(component.isLocked(field)).toBeFalse();
    });
  });

  it('pre-fills a date-and-time field in local time, so saving does not move it', async () => {
    const fixture = await configure('classsessions', 'owner');
    const component = fixture.componentInstance;

    // Constructed in local time, so the expectation holds in every time zone.
    component.startEdit({ _id: 's-1', startTime: new Date(2026, 9, 12, 9, 0).toISOString() });

    expect(component.draft!['startTime']).toBe('2026-10-12T09:00');
  });

  it('pre-fills a date-only field without shifting the day', async () => {
    const fixture = await configure('students', 'owner');
    const component = fixture.componentInstance;

    component.startEdit({ _id: 'st-1', enrolledOn: '2026-09-21' });

    expect(component.draft!['enrolledOn']).toBe('2026-09-21');
  });

  it('shows a placeholder rather than blank for an absent value', async () => {
    const fixture = await configure('students', 'owner');
    const component = fixture.componentInstance;
    const field = component.config!.fields.find((f) => f.key === 'phone')!;
    expect(component.displayValue({ phone: null }, field)).toBe('—');
  });

  it('shows a date-only value on its own day, with no time, in every time zone', async () => {
    const fixture = await configure('students', 'owner');
    const component = fixture.componentInstance;
    const field = component.config!.fields.find((f) => f.key === 'enrolledOn')!;

    const shown = component.displayValue({ enrolledOn: '2026-08-01T00:00:00.000Z' }, field);
    const expected = new Date(Date.UTC(2026, 7, 1))
      .toLocaleDateString(undefined, { timeZone: 'UTC', year: 'numeric', month: 'short', day: 'numeric' });

    expect(shown).toBe(expected);
    expect(shown).not.toMatch(/\d{1,2}:\d{2}/);
  });

  it('shows money with two decimal places', async () => {
    const fixture = await configure('classsessions', 'owner');
    const component = fixture.componentInstance;
    const field = component.config!.fields.find((f) => f.key === 'ratePerClass')!;
    expect(component.displayValue({ ratePerClass: 25 }, field)).toBe('25.00');
    expect(component.displayValue({ ratePerClass: 16.85 }, field)).toBe('16.85');
  });
});
