/**
 * Entity manager component.
 *
 * A single screen that lists, creates, edits and withdraws records for any
 * managed entity. The entity is chosen by the route, its configuration is
 * looked up, and the table columns and form controls are built from that
 * configuration at runtime.
 *
 * This replaces what would otherwise be five copies of the listing, add and
 * edit components the original application used for its single entity, one
 * set per entity. The original pattern would have meant fifteen components
 * doing substantially the same work, and every future change to how a record
 * is edited would have had to be made five times.
 *
 * Changed for the final release: the signed-in role is read from
 * AuthenticationService, which now owns everything to do with the token;
 * date-only values are shown without a time and on the correct day in every
 * time zone; and money is shown with two decimal places.
 *
 * @file    app_admin/src/app/entity-manager/entity-manager.component.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';

import { EntityConfig, FieldConfig, Role } from '../models/entity-config';
import { findEntityConfig } from '../config/entity-definitions';
import { EntityDataService, EntityRecord } from '../services/entity-data.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-entity-manager',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './entity-manager.component.html',
  styleUrls: ['./entity-manager.component.css']
})
export class EntityManagerComponent implements OnInit, OnDestroy {

  /** Configuration for the entity currently being managed. */
  public config: EntityConfig | null = null;

  /** Records returned for the signed-in account. */
  public records: EntityRecord[] = [];

  /** Records used to populate select controls, keyed by source entity. */
  public optionSources: Record<string, EntityRecord[]> = {};

  /** The record being added or edited, or null when the form is closed. */
  public draft: EntityRecord | null = null;

  /** Identifier of the record being edited; null when adding. */
  public editingId: string | null = null;

  public loading = false;
  public errorMessage = '';
  public role: Role | null = null;

  private routeSubscription: Subscription | null = null;

  constructor(
    private route: ActivatedRoute,
    private entityData: EntityDataService,
    private authenticationService: AuthenticationService
  ) { }

  public ngOnInit(): void {
    this.role = this.authenticationService.currentRole();

    // Reacting to parameter changes rather than reading once means moving
    // between entities reuses this component instead of recreating it.
    this.routeSubscription = this.route.paramMap.subscribe((params) => {
      const key = params.get('entity') || '';
      this.config = findEntityConfig(key) || null;
      this.draft = null;
      this.editingId = null;
      this.errorMessage = '';

      if (this.config) {
        this.loadRecords();
        this.loadOptionSources();
      } else {
        this.errorMessage = 'That section does not exist.';
      }
    });
  }

  public ngOnDestroy(): void {
    this.routeSubscription?.unsubscribe();
  }

  /** Fields shown as columns in the list. */
  public get listedFields(): FieldConfig[] {
    return this.config ? this.config.fields.filter((field) => field.listed !== false) : [];
  }

  /**
   * Reports whether the signed-in role appears in a permission list.
   * Governs which buttons are offered, not what the server will allow.
   */
  public allowed(roles: Role[] | undefined): boolean {
    return !!this.role && !!roles && roles.includes(this.role);
  }

  /** Loads the records for the current entity. */
  private loadRecords(): void {
    if (!this.config) {
      return;
    }

    this.loading = true;

    this.entityData.list(this.config.key).subscribe({
      next: (records) => {
        this.records = records;
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = this.describeError(error);
        this.loading = false;
      }
    });
  }

  /**
   * Loads the records that populate select controls.
   *
   * A field referencing another entity, such as a class session's teacher,
   * needs that entity's records to offer a choice of names rather than asking
   * for an identifier.
   */
  private loadOptionSources(): void {
    if (!this.config) {
      return;
    }

    const sources = new Set(
      this.config.fields
        .filter((field) => !!field.optionsFrom)
        .map((field) => field.optionsFrom as string)
    );

    sources.forEach((source) => {
      this.entityData.list(source).subscribe({
        next: (records) => { this.optionSources[source] = records; },
        // A missing option list should not block the screen. The select simply
        // has nothing to offer, which is visible and recoverable.
        error: () => { this.optionSources[source] = []; }
      });
    });
  }

  /**
   * Reports whether a field is read-only for the signed-in role while editing.
   * New records are unaffected, since roles with locked fields cannot create.
   */
  public isLocked(field: FieldConfig): boolean {
    return !!this.editingId && !!this.role && !!field.lockedFor && field.lockedFor.includes(this.role);
  }

  /** Options available for a select field. */
  public optionsFor(field: FieldConfig): EntityRecord[] {
    return field.optionsFrom ? (this.optionSources[field.optionsFrom] || []) : [];
  }

  /** Label shown for one option of a reference field. */
  public optionLabel(field: FieldConfig, option: EntityRecord): string {
    const key = field.optionsLabel || 'name';
    return option[key] ?? option['title'] ?? option['_id'];
  }

  /**
   * Value displayed in a list cell, resolving references and formatting dates
   * and money.
   *
   * A date-only value, such as an enrollment date, is stored as midnight UTC,
   * so it is shown in UTC. Shown in local time, as it was before the final
   * release, it carried a meaningless time and appeared a day early for anyone
   * west of UTC. A date-and-time value is a moment, so it is shown in local time.
   */
  public displayValue(record: EntityRecord, field: FieldConfig): string {
    const value = record[field.key];

    if (value === null || value === undefined || value === '') {
      return '—';
    }

    if (field.optionsFrom) {
      const match = this.optionsFor(field)
        .find((option) => option['_id'] === value || option['id'] === value);
      return match ? this.optionLabel(field, match) : String(value);
    }

    if (field.type === 'checkbox') {
      return value ? 'Yes' : 'No';
    }

    if (field.type === 'date' || field.type === 'datetime') {
      const parsed = new Date(value);
      if (Number.isNaN(parsed.getTime())) {
        return String(value);
      }
      return field.type === 'date'
        ? parsed.toLocaleDateString(undefined, { timeZone: 'UTC', year: 'numeric', month: 'short', day: 'numeric' })
        : parsed.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
    }

    if (field.format === 'money' && typeof value === 'number') {
      return value.toFixed(2);
    }

    return String(value);
  }

  /** Opens an empty form for a new record. */
  public startAdd(): void {
    if (!this.config) {
      return;
    }

    this.editingId = null;
    this.errorMessage = '';
    this.draft = this.config.fields.reduce((draft, field) => {
      draft[field.key] = field.type === 'checkbox' ? false : '';
      return draft;
    }, {} as EntityRecord);
  }

  /** Opens the form pre-filled with an existing record. */
  public startEdit(record: EntityRecord): void {
    if (!this.config) {
      return;
    }

    this.editingId = record['_id'];
    this.errorMessage = '';
    this.draft = this.config.fields.reduce((draft, field) => {
      draft[field.key] = this.toInputValue(record[field.key], field);
      return draft;
    }, {} as EntityRecord);
  }

  /** Converts a stored value into the format its input control expects. */
  private toInputValue(value: any, field: FieldConfig): any {
    if (value === null || value === undefined) {
      return field.type === 'checkbox' ? false : '';
    }

    if (field.type === 'date' || field.type === 'datetime') {
      const parsed = new Date(value);
      if (Number.isNaN(parsed.getTime())) {
        return '';
      }

      // Each input type must be filled in the same time zone the browser uses
      // when it reads that type back, or every save would shift the value.
      // JavaScript interprets a date-only string such as "2026-10-12" as UTC,
      // so date fields are written in UTC. It interprets a date-and-time string
      // such as "2026-10-12T09:00" as local time, so datetime fields are written
      // in local time. Writing a datetime field in UTC, as toISOString does,
      // moved a session by the local UTC offset on every edit.
      if (field.type === 'date') {
        return parsed.toISOString().slice(0, 10);
      }

      const pad = (n: number): string => String(n).padStart(2, '0');
      return `${parsed.getFullYear()}-${pad(parsed.getMonth() + 1)}-${pad(parsed.getDate())}`
        + `T${pad(parsed.getHours())}:${pad(parsed.getMinutes())}`;
    }

    return value;
  }

  /** Closes the form without saving. */
  public cancel(): void {
    this.draft = null;
    this.editingId = null;
  }

  /** Reports whether every required field has a value. */
  public get draftIsValid(): boolean {
    if (!this.config || !this.draft) {
      return false;
    }

    return this.config.fields
      .filter((field) => field.required)
      .every((field) => {
        const value = this.draft ? this.draft[field.key] : null;
        return value !== null && value !== undefined && String(value).trim() !== '';
      });
  }

  /** Saves the form, creating or updating according to how it was opened. */
  public save(): void {
    if (!this.config || !this.draft || !this.draftIsValid) {
      this.errorMessage = 'Please complete every required field.';
      return;
    }

    const payload = { ...this.draft };
    const request = this.editingId
      ? this.entityData.update(this.config.key, this.editingId, payload)
      : this.entityData.create(this.config.key, payload);

    request.subscribe({
      next: () => {
        this.draft = null;
        this.editingId = null;
        this.loadRecords();
      },
      error: (error) => { this.errorMessage = this.describeError(error); }
    });
  }

  /** Withdraws a record after confirmation. */
  public remove(record: EntityRecord): void {
    if (!this.config) {
      return;
    }

    const confirmed = confirm(
      `Remove this ${this.config.singular.toLowerCase()}? Related history is preserved.`
    );

    if (!confirmed) {
      return;
    }

    this.entityData.remove(this.config.key, record['_id']).subscribe({
      next: () => this.loadRecords(),
      error: (error) => { this.errorMessage = this.describeError(error); }
    });
  }

  /**
   * Turns a failed request into a message a user can act on.
   *
   * A 403 is reported plainly rather than as a technical failure, because being
   * refused is a normal outcome for a role-limited account rather than a fault.
   */
  private describeError(error: any): string {
    if (error?.status === 401) {
      return 'Your session has expired. Please sign in again.';
    }

    if (error?.status === 403) {
      // Prefer the server's explanation when it gives one, such as which
      // change a role may not make; otherwise fall back to a general message.
      return error?.error?.message || 'You do not have permission to do that.';
    }

    return error?.error?.message || 'Something went wrong. Please try again.';
  }
}
