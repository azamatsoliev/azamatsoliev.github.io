/**
 * Application routes.
 *
 * The five management screens share one route. The entity is carried as a
 * parameter and resolved against the entity definitions, so adding a sixth
 * entity requires no route of its own.
 *
 * Changed for the final release: the trip list, add and edit routes inherited
 * from the original travel application were removed. The home page is now a
 * role-aware overview, every screen except sign-in requires a signed-in user,
 * each route sets its own page title, and an unknown address returns home.
 *
 * @file    app_admin/src/app/app.routes.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { EntityManagerComponent } from './entity-manager/entity-manager.component';
import { ReportsComponent } from './reports/reports.component';
import { authGuard, entityGuard } from './utils/auth.guard';
import { pageTitle } from './config/app-info';

export const routes: Routes = [
  { path: '', component: HomeComponent, canActivate: [authGuard], title: pageTitle('Home'), pathMatch: 'full' },
  { path: 'login', component: LoginComponent, title: pageTitle('Sign in') },

  // One route serving every managed entity.
  {
    path: 'manage/:entity',
    component: EntityManagerComponent,
    canActivate: [authGuard, entityGuard],
    title: pageTitle('Records')
  },

  // Reports, presented differently for each role.
  { path: 'reports', component: ReportsComponent, canActivate: [authGuard], title: pageTitle('Reports') },

  { path: '**', redirectTo: '' }
];
