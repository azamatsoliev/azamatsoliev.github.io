/**
 * Home component.
 *
 * The first screen after sign-in. Greets the signed-in person, shows their
 * role, and offers one card for each section that role can open, so a new
 * user can see at a glance what the system lets them do.
 *
 * The cards are built from the same entity definitions as the navigation bar,
 * so the two always agree.
 *
 * @file    app_admin/src/app/home/home.component.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { AuthenticationService, CurrentUser } from '../services/authentication.service';
import { ENTITY_DEFINITIONS } from '../config/entity-definitions';
import { APP_INFO, ROLE_LABELS } from '../config/app-info';
import { Role } from '../models/entity-config';

/** One card on the home page. */
export interface HomeSection {
  title: string;
  description: string;
  link: string[];
}

/** What the Reports card says for each role. */
export const REPORT_DESCRIPTIONS: Record<Role, string> = {
  owner: 'Class performance, revenue and outstanding balances.',
  accountant: 'Balances, monthly revenue with CSV export, and the yearly trend.',
  teacher: 'Your monthly attendance sheet: lessons still to mark, and who came.'
};

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  public readonly appInfo = APP_INFO;
  public readonly user: CurrentUser | null;
  public readonly roleLabel: string;
  public readonly sections: HomeSection[];

  constructor(authenticationService: AuthenticationService) {
    this.user = authenticationService.getCurrentUser();
    const role = this.user?.role ?? null;

    this.roleLabel = role ? ROLE_LABELS[role] : '';
    this.sections = role ? HomeComponent.sectionsFor(role) : [];
  }

  /** The cards a role is offered, in navigation order. */
  public static sectionsFor(role: Role): HomeSection[] {
    const entities = ENTITY_DEFINITIONS
      .filter((entity) => entity.visibleTo.includes(role))
      .map((entity) => ({ title: entity.plural, description: entity.description, link: ['/manage', entity.key] }));

    return [...entities, { title: 'Reports', description: REPORT_DESCRIPTIONS[role], link: ['/reports'] }];
  }
}
