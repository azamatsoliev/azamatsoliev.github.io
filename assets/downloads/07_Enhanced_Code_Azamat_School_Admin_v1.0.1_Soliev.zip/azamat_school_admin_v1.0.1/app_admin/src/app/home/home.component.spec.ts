/**
 * Tests for the home page.
 *
 * @file    app_admin/src/app/home/home.component.spec.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { HomeComponent } from './home.component';
import { AuthenticationService, TOKEN_STORAGE_KEY } from '../services/authentication.service';
import { makeRoleToken } from '../testing/tokens';

describe('HomeComponent', () => {

  const render = async (role: string, name: string) => {
    localStorage.setItem(TOKEN_STORAGE_KEY, makeRoleToken(role, name));
    await TestBed.configureTestingModule({
      imports: [HomeComponent],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()]
    }).compileComponents();
    TestBed.inject(AuthenticationService);
    const fixture = TestBed.createComponent(HomeComponent);
    fixture.detectChanges();
    return fixture;
  };

  afterEach(() => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    TestBed.resetTestingModule();
  });

  it('greets the signed-in person by name and shows their role', async () => {
    const fixture = await render('accountant', 'Madina Yusupova');
    const text = (fixture.nativeElement as HTMLElement).textContent || '';
    expect(text).toContain('Welcome, Madina Yusupova');
    expect(text).toContain('Accountant');
  });

  it('offers an owner every section', () => {
    const titles = HomeComponent.sectionsFor('owner').map((section) => section.title);
    expect(titles).toEqual(['Students', 'Teachers', 'Class Sessions', 'Payments', 'Attendance', 'Reports']);
  });

  it('offers a teacher only their lessons, attendance and reports', () => {
    const titles = HomeComponent.sectionsFor('teacher').map((section) => section.title);
    expect(titles).toEqual(['Class Sessions', 'Attendance', 'Reports']);
  });

  it('never offers an accountant teaching or staff screens', () => {
    const titles = HomeComponent.sectionsFor('accountant').map((section) => section.title);
    expect(titles).toEqual(['Students', 'Payments', 'Reports']);
  });

  it('renders one link per section', async () => {
    const fixture = await render('teacher', 'Jasur Aliev');
    const links = (fixture.nativeElement as HTMLElement).querySelectorAll('a.home-card');
    expect(links.length).toBe(3);
  });
});
