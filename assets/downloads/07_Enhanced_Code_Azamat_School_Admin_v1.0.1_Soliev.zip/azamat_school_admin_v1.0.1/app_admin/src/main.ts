/**
 * Application entry point.
 *
 * Starts the Angular application with the configuration in app.config.ts.
 *
 * @file    app_admin/src/main.ts
 * @author  Azamat Soliev
 * @version 4.0
 * @date    October 2026
 */

import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
