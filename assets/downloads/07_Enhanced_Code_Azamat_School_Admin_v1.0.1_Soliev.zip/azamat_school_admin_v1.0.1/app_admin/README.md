# Azamat School Admin: web interface

The Angular application that school staff use in the browser. It talks to the
REST API in the parent folder.

Setup, demo accounts and the full project description are in the
[main README](../README.md).

```bash
npm install
npm start          # http://localhost:4200, with the API running on port 3000
npm run test:ci    # unit tests in a headless browser
npm run build      # production build in dist/
```

The API address is set in `src/environments/environment.ts`.
